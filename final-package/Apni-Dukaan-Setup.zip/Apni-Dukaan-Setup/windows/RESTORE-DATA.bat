@echo off
REM ============================================================
REM  Apni Dukaan - RESTORE-DATA (backup se hisaab wapas)
REM  Is file par DOUBLE-CLICK karein - backups ki list ayegi,
REM  number chunein, pakka karein, purana hisaab wapas aa
REM  jayega. Asal kaam 05-restore-backup.ps1 karta hai.
REM ============================================================
setlocal
title Apni Dukaan - Data Wapas Layein
cd /d "%~dp0"

REM --- Admin check: admin na ho to khud ko admin bana kar dobara kholo ---
fltmc >nul 2>&1
if %errorlevel%==0 goto :adminok
net session >nul 2>&1
if %errorlevel%==0 goto :adminok
echo.
echo  Ek chhota sa sawal ayega - wahan YES dabain...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
exit /b

:adminok
set "SCRIPT=%~dp005-restore-backup.ps1"
if not exist "%SCRIPT%" set "SCRIPT=C:\CanteenPOS\05-restore-backup.ps1"
if not exist "%SCRIPT%" (
  echo.
  echo  Restore wali file nahi mili: 05-restore-backup.ps1
  echo  Pehle INSTALL.bat chalain, phir dobara koshish karein.
  echo.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
echo.
pause
exit /b
