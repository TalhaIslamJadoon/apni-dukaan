# =====================================================================
#  Canteen POS - Phase 2 - Script 01: Install Prerequisites (Windows)
#  Node.js LTS + PostgreSQL install/check karta hai.
#  Admin PowerShell mein chalain. Re-run karna safe hai (idempotent).
#
#  ROUND 5 (18-Nov-2026) - asal NAYE PC ke Step-1 fail se seekha:
#  - Purana Node (v20.3.0) "pehle se hai" keh kar accept ho jata
#    tha. Ab VERSION FLOOR hai: Node v22 se purana ho to upgrade
#    lazmi hai (app Next.js 16 hai - use naya Node chahiye).
#  - PostgreSQL ka winget download EDB ke server se 403
#    Forbidden par fail hua - winget ki pehchan
#    wahan nahi chalti. Ab teen tareeqay hain:
#      Plan A: winget (pehle wala tareeqa, unattended switches ke
#              sath taake password wali window hi na aye).
#      Plan B: EDB installer seedha browser wali pehchan
#              (User-Agent) ke sath download karke KHAMOSHI se
#              (unattended) install.
#      Plan C: sirf program files (binaries zip) download karke
#              khud service bana dena.
#  - Database ka superuser password operator se KABHI nahi manga
#    jata aur yaad bhi nahi rakhna: script khud mazboot password
#    banata hai, unattended install mein wohi lagta hai, aur
#    step 2 ke liye woh password C:\CanteenPOS\pg-superuser.tmp
#    mein mehfooz hand-off hota hai (02 use parh kar file delete
#    kar deta hai; file na mile to 02 ki pg_hba trust-recovery
#    apna kaam karti hai - wohi purana fallback).
#  NOTE: Plan B/C ka pehla asal-PC test abhi baqi hai - fail hon
#  to install-log.txt ki tafseel bhejein.
# =====================================================================

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$failed = $false

$script:NodeFloor = [version]'22.0.0'
$script:BrowserUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
$script:PgVersions = @(
    [pscustomobject]@{ Major = 17; Ver = '17.12-1' },
    [pscustomobject]@{ Major = 16; Ver = '16.16-1' }
)
$script:HandoffDir  = 'C:\CanteenPOS'
$script:HandoffFile = 'C:\CanteenPOS\pg-superuser.tmp'
$script:PgHandoffPassword = $null

function Test-IsAdmin {
    $identity  = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Refresh-Path {
    $machine = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $user    = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = "$machine;$user"
}

function Find-Psql {
    $base = 'C:\Program Files\PostgreSQL'
    if (Test-Path $base) {
        $dirs = Get-ChildItem $base -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending
        foreach ($d in $dirs) {
            $candidate = Join-Path $d.FullName 'bin\psql.exe'
            if (Test-Path $candidate) { return $candidate }
        }
    }
    $cmd = Get-Command psql.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

function Get-NodeVersion {
    $cmd = Get-Command node.exe -ErrorAction SilentlyContinue
    if (-not $cmd) { return $null }
    $prevEAP = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $raw = & node --version 2>$null
    $ErrorActionPreference = $prevEAP
    if (-not $raw) { return $null }
    $txt = "$raw".Trim().TrimStart('v')
    try { return [version]$txt } catch { return $null }
}

function New-SafePassword {
    # Sirf letters + digits - command line, config file, har jagah
    # baghair quoting ke jhanjhat ke chal jata hai.
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789'
    $bytes = New-Object byte[] 28
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    $sb = New-Object System.Text.StringBuilder
    foreach ($b in $bytes) { [void]$sb.Append($alphabet[$b % $alphabet.Length]) }
    return $sb.ToString()
}

function Invoke-Download {
    param([string]$Url, [string]$Dest, [long]$MinBytes = 1048576)
    # Browser wali pehchan (User-Agent) ke sath download - kuch
    # servers (EDB waghera) aam download programs ko 403 de dete
    # hain, browser wali pehchan par file de dete hain.
    for ($try = 1; $try -le 3; $try++) {
        try {
            Write-Host ("Download ho raha hai (koshish {0}/3)..." -f $try)
            Invoke-WebRequest -Uri $Url -OutFile $Dest -UseBasicParsing -UserAgent $script:BrowserUA -TimeoutSec 1200
            if ((Test-Path $Dest) -and ((Get-Item $Dest).Length -ge $MinBytes)) { return $true }
            Write-Host 'Download adhoora lag raha hai - dobara koshish hogi.' -ForegroundColor Yellow
        } catch {
            Write-Host ("Download fail hua: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
        }
        Start-Sleep -Seconds 5
    }
    return $false
}

function Save-PgHandoff {
    # Step 1 ne PostgreSQL khud lagaya ho to us ka banaya hua
    # master password step 2 ke liye ek mehfooz file mein chhor
    # dein - 02 use parh kar file delete kar dega. File ki
    # permissions .env ki tarah band kar di jati hain.
    if (-not $script:PgHandoffPassword) { return }
    try {
        if (-not (Test-Path $script:HandoffDir)) { New-Item -ItemType Directory -Path $script:HandoffDir -Force | Out-Null }
        [IO.File]::WriteAllText($script:HandoffFile, $script:PgHandoffPassword)
        $me = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        & icacls $script:HandoffFile /inheritance:r /grant:r 'SYSTEM:F' 'Administrators:F' ("{0}:F" -f $me) | Out-Null
        Write-Host 'Database ka master password step 2 ke liye mehfooz kar diya hai - kisi ko yaad nahi rakhna.'
    } catch {
        Write-Host 'Note: master password ki hand-off file nahi bani - step 2 apna purana tareeqa (recovery) khud istemal kar lega.' -ForegroundColor Yellow
    }
}

function Install-NodeLts {
    # Plan A: winget. Na chale to Plan B: nodejs.org se official MSI.
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        $hadNode = [bool](Get-Command node.exe -ErrorAction SilentlyContinue)
        if ($hadNode) {
            Write-Host 'Node.js upgrade ho raha hai (winget)...' -ForegroundColor Yellow
            & winget upgrade --id OpenJS.NodeJS.LTS -e --accept-source-agreements --accept-package-agreements
            Refresh-Path
            $v = Get-NodeVersion
            if ($v -and ($v -ge $script:NodeFloor)) { return $true }
            Write-Host 'winget upgrade se kaam nahi bana - install wala tareeqa try ho raha hai...' -ForegroundColor Yellow
            & winget install --id OpenJS.NodeJS.LTS -e --force --accept-source-agreements --accept-package-agreements
        } else {
            Write-Host 'Node.js install ho raha hai (winget, LTS)...' -ForegroundColor Yellow
            & winget install --id OpenJS.NodeJS.LTS -e --accept-source-agreements --accept-package-agreements
        }
        Refresh-Path
        $v = Get-NodeVersion
        if ($v -and ($v -ge $script:NodeFloor)) { return $true }
        Write-Host 'winget wala tareeqa nahi chala - ab seedha nodejs.org se download hoga.' -ForegroundColor Yellow
    } else {
        Write-Host 'winget nahi mila - Node.js seedha nodejs.org se download hoga.' -ForegroundColor Yellow
    }

    # --- Plan B: nodejs.org se official MSI -------------------------
    $ver = $null
    try {
        $idxRaw = (Invoke-WebRequest -Uri 'https://nodejs.org/dist/index.json' -UseBasicParsing -UserAgent $script:BrowserUA -TimeoutSec 60).Content
        $idx = $idxRaw | ConvertFrom-Json
        $lts = $idx | Where-Object { $_.lts } | Select-Object -First 1
        if ($lts) { $ver = [string]$lts.version }
    } catch {
        Write-Host 'Node ki latest LTS list nahi mili - ek mehfooz LTS version istemal hoga.' -ForegroundColor Yellow
    }
    if (-not $ver) { $ver = 'v24.11.0' }
    $msiName = "node-$ver-x64.msi"
    $msiPath = Join-Path $env:TEMP $msiName
    $msiUrl  = "https://nodejs.org/dist/$ver/$msiName"
    Write-Host ("Node.js {0} download ho raha hai..." -f $ver) -ForegroundColor Yellow
    if (Invoke-Download $msiUrl $msiPath 10485760) {
        $proc = Start-Process msiexec.exe -ArgumentList "/i `"$msiPath`" /qn /norestart" -Wait -PassThru
        Refresh-Path
        $v = Get-NodeVersion
        if ($v -and ($v -ge $script:NodeFloor)) { return $true }
        Write-Host ("Node MSI ka exit code: {0}" -f $proc.ExitCode) -ForegroundColor Yellow
    }
    return $false
}

function Install-PgFromBinaries {
    param($Pg)
    # Plan C: EDB ki sirf-program-files wali zip. Installer bilkul
    # nahi chalega - files rakh kar, cluster bana kar, service
    # register kar dete hain. 02 ke liye ye bilkul aam install
    # jaisa lagta hai (usi jagah psql, usi naam ki service).
    $major = $Pg.Major
    Write-Host ("Aakhri tareeqa: PostgreSQL {0} ki program files seedha rakh kar service banayi jayegi..." -f $major) -ForegroundColor Yellow
    $zipName = "postgresql-$($Pg.Ver)-windows-x64-binaries.zip"
    $zipPath = Join-Path $env:TEMP $zipName
    if (-not (Invoke-Download "https://get.enterprisedb.com/postgresql/$zipName" $zipPath 10485760)) { return $false }
    $extractDir = Join-Path $env:TEMP ("pgbin-{0}" -f $major)
    if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force -ErrorAction SilentlyContinue }
    try {
        Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force
    } catch {
        Write-Host ("Zip kholna fail hua: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
        return $false
    }
    $srcRoot = Join-Path $extractDir 'pgsql'
    if (-not (Test-Path (Join-Path $srcRoot 'bin\postgres.exe'))) { $srcRoot = $extractDir }
    if (-not (Test-Path (Join-Path $srcRoot 'bin\postgres.exe'))) {
        Write-Host 'Zip ke andar PostgreSQL ki files nahi mili.' -ForegroundColor Yellow
        return $false
    }
    $target  = "C:\Program Files\PostgreSQL\$major"
    $binDir  = Join-Path $target 'bin'
    $dataDir = Join-Path $target 'data'
    if (-not (Test-Path $target)) { New-Item -ItemType Directory -Path $target -Force | Out-Null }
    & robocopy $srcRoot $target /E /NFL /NDL /NJH /NJS | Out-Null
    if ($LASTEXITCODE -ge 8) { Write-Host 'Program files copy nahi hui.' -ForegroundColor Yellow; return $false }
    if (-not (Test-Path (Join-Path $dataDir 'PG_VERSION'))) {
        $pwFile = Join-Path $env:TEMP ("pgpw-{0}.txt" -f [guid]::NewGuid().ToString('N'))
        try {
            [IO.File]::WriteAllText($pwFile, $script:PgHandoffPassword)
            & (Join-Path $binDir 'initdb.exe') -D $dataDir -U postgres "--pwfile=$pwFile" --auth=scram-sha-256 -E UTF8
            if ($LASTEXITCODE -ne 0) { Write-Host 'Database cluster (initdb) nahi bana.' -ForegroundColor Yellow; return $false }
        } finally {
            Remove-Item $pwFile -Force -ErrorAction SilentlyContinue
        }
    }
    # Service jis account (NetworkService) se chalegi use data
    # folder par poora haq dein - baghair is ke service start
    # nahi hogi:
    & icacls $dataDir /grant 'NT AUTHORITY\NetworkService:(OI)(CI)F' /T /Q | Out-Null
    $svcName = "postgresql-x64-$major"
    if (-not (Get-Service -Name $svcName -ErrorAction SilentlyContinue)) {
        & (Join-Path $binDir 'pg_ctl.exe') register -N $svcName -D $dataDir -U 'NT AUTHORITY\NetworkService' -S auto
        if ($LASTEXITCODE -ne 0) { Write-Host 'PostgreSQL service register nahi hui.' -ForegroundColor Yellow; return $false }
    }
    Write-Host ("PostgreSQL {0} program files se tayyar ho gaya (service: {1})." -f $major, $svcName) -ForegroundColor Green
    return [bool](Find-Psql)
}

function Install-PostgreSQL {
    # Password script KHUD banata hai - operator se kabhi nahi
    # manga jata, aur use yaad bhi nahi rakhna.
    $script:PgHandoffPassword = New-SafePassword
    $pw = $script:PgHandoffPassword

    # --- Plan A: winget (17, phir 16) -------------------------------
    # --override se installer ko unattended switches bhej dete
    # hain taake password wali window hi na aye aur wohi password
    # lage jo script ne banaya hai.
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        foreach ($pkg in @('PostgreSQL.PostgreSQL.17', 'PostgreSQL.PostgreSQL.16')) {
            Write-Host ("Try: winget package {0}" -f $pkg)
            & winget install --id $pkg -e --accept-source-agreements --accept-package-agreements --override "--mode unattended --unattendedmodeui none --serverport 5432 --superpassword $pw"
            Refresh-Path
            if (Find-Psql) { Save-PgHandoff; return $true }
        }
        Write-Host 'winget wala tareeqa nahi chala - ab seedha download wala tareeqa chalega.' -ForegroundColor Yellow
    } else {
        Write-Host 'winget nahi mila - PostgreSQL seedha download hoga.' -ForegroundColor Yellow
    }

    # --- Plan B: EDB installer seedha download + unattended ---------
    foreach ($pg in $script:PgVersions) {
        $exeName = "postgresql-$($pg.Ver)-windows-x64.exe"
        $exePath = Join-Path $env:TEMP $exeName
        Write-Host ("PostgreSQL {0} ka installer download ho raha hai..." -f $pg.Major) -ForegroundColor Yellow
        if (Invoke-Download "https://get.enterprisedb.com/postgresql/$exeName" $exePath 52428800) {
            Write-Host 'Installer chal raha hai (khamoshi se - koi window nahi ayegi)...'
            $proc = Start-Process $exePath -ArgumentList @('--mode', 'unattended', '--unattendedmodeui', 'none', '--serverport', '5432', '--superpassword', $pw) -Wait -PassThru
            Refresh-Path
            if (Find-Psql) { Save-PgHandoff; return $true }
            Write-Host ("Installer ka exit code: {0} - aage wala tareeqa try hoga." -f $proc.ExitCode) -ForegroundColor Yellow
        }
    }

    # --- Plan C: sirf program files (binaries zip) ------------------
    foreach ($pg in $script:PgVersions) {
        if (Install-PgFromBinaries $pg) { Save-PgHandoff; return $true }
    }
    return $false
}

# --- Khud ko Admin bana kar dobara chalana (agar admin nahi) ----------
if (-not (Test-IsAdmin)) {
    Write-Host 'Admin rights chahiye - UAC prompt par Yes dabain...' -ForegroundColor Yellow
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

try {
    Write-Host ''
    Write-Host '===================================================' -ForegroundColor Cyan
    Write-Host ' STEP 1/3 - Node.js + PostgreSQL install / check' -ForegroundColor Cyan
    Write-Host '===================================================' -ForegroundColor Cyan

    # --- Windows version check ---------------------------------------
    $os = Get-CimInstance Win32_OperatingSystem
    Write-Host ("Windows: {0} (Build {1})" -f $os.Caption, $os.BuildNumber)
    if ([int]$os.BuildNumber -ge 22000) {
        Write-Host 'Windows 11 detected - perfect, yehi side use karni hai.' -ForegroundColor Green
    } elseif ([int]$os.BuildNumber -ge 10240) {
        Write-Host 'Windows 10 detected - chalega, lekin Windows 11 wali side zyada behtar hai (10 ki support khatam ho chuki hai).' -ForegroundColor Yellow
    } else {
        throw 'Ye Windows bohat purana hai - Windows 10/11 chahiye.'
    }

    # --- Node.js (version floor ke sath) -------------------------------
    Refresh-Path
    $nodeVer = Get-NodeVersion
    if ($nodeVer -and ($nodeVer -ge $script:NodeFloor)) {
        Write-Host ("Node.js pehle se hai: v{0}" -f $nodeVer) -ForegroundColor Green
    } else {
        if ($nodeVer) {
            Write-Host ("Node.js purana hai (v{0}) - is system ke liye v22 ya naya chahiye. Naya LTS lag raha hai..." -f $nodeVer) -ForegroundColor Yellow
        } else {
            Write-Host 'Node.js nahi mila - LTS version lag raha hai...' -ForegroundColor Yellow
        }
        if (-not (Install-NodeLts)) {
            throw 'Node.js install/upgrade nahi hua - internet check karke script dobara chalain, ya https://nodejs.org se LTS haath se install karke dobara chalain.'
        }
        $nodeVer = Get-NodeVersion
        Write-Host ("Node.js tayyar hai: v{0}" -f $nodeVer) -ForegroundColor Green
    }

    # --- PostgreSQL ----------------------------------------------------
    $psql = Find-Psql
    if ($psql) {
        Write-Host ("PostgreSQL pehle se hai: {0}" -f $psql) -ForegroundColor Green
    } else {
        Write-Host ''
        Write-Host 'PostgreSQL install ho raha hai - ye khud bakhud hoga, aap ko koi password nahi likhna (system khud bana leta hai).' -ForegroundColor Yellow
        if (-not (Install-PostgreSQL)) {
            throw 'PostgreSQL install nahi hua - internet check karke script dobara chalain. Phir bhi na ho to https://www.postgresql.org/download/windows/ se haath se install karein (port 5432 default rakhein), phir ye script dobara chalain.'
        }
        $psql = Find-Psql
        Write-Host ("PostgreSQL install ho gaya: {0}" -f $psql) -ForegroundColor Green
    }

    # --- PostgreSQL service: Automatic + Running -----------------------
    $svc = Get-Service -Name 'postgresql*' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($svc) {
        if ($svc.StartType -ne 'Automatic') {
            Set-Service -Name $svc.Name -StartupType Automatic
            Write-Host ("Service {0} ko Automatic kar diya." -f $svc.Name)
        }
        if ($svc.Status -ne 'Running') {
            Start-Service -Name $svc.Name
            Write-Host ("Service {0} start kar diya." -f $svc.Name) -ForegroundColor Green
        } else {
            Write-Host ("PostgreSQL service chal raha hai: {0}" -f $svc.Name) -ForegroundColor Green
        }
    } else {
        Write-Host 'PostgreSQL service nahi mila - install dobara check karein.' -ForegroundColor Yellow
    }

    # --- Versions ki report --------------------------------------------
    Write-Host ''
    Write-Host '--- Installed versions ---' -ForegroundColor Cyan
    Write-Host ("node : {0}" -f (& node --version))
    Write-Host ("npm  : {0}" -f (& npm --version))
    if ($psql) { Write-Host ("psql : {0}" -f (& $psql --version)) }

    Write-Host ''
    Write-Host 'STEP 1 COMPLETE. Ab 02-setup-server.ps1 chalain.' -ForegroundColor Green
}
catch {
    $failed = $true
    Write-Host ''
    Write-Host ("ERROR: {0}" -f $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Masla hal karke script dobara chalain - dobara chalana safe hai.'
}
Write-Host ''
if ($env:CANTEENPOS_AUTO -ne '1') { Read-Host 'Band karne ke liye Enter dabain' }
if ($failed) { exit 1 }
