@echo off
REM ============================================================
REM  Apni Dukaan - Server START (staff ke liye, double-click)
REM  Server pehle se chal raha ho to sirf address dikhata hai.
REM  Asal launcher: C:\CanteenPOS\run-server.cmd
REM  (wahi jo PC on honay par khud bhi chalta hai)
REM ============================================================
setlocal
set PORT=3100
title Apni Dukaan - Server Start

echo.
echo  Apni Dukaan server check ho raha hai...

powershell -NoProfile -Command "if (Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }"
if %errorlevel%==0 (
    echo  Server pehle se CHAL raha hai.
    goto :showaddr
)

if not exist "C:\CanteenPOS\run-server.cmd" (
    echo  Server launcher nahi mila - pehle INSTALL.bat chalain.
    goto :end
)

echo  Server start ho raha hai - nayi window khulegi, use BAND na karein...
start "Apni Dukaan Server - is window ko band na karein" "C:\CanteenPOS\run-server.cmd"

echo  Server ke tayyar hone ka intezar...
set /a tries=0
:waitloop
set /a tries+=1
timeout /t 2 /nobreak >nul
powershell -NoProfile -Command "if (Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }"
if %errorlevel%==0 goto :ready
if %tries% lss 45 goto :waitloop
echo.
echo  Server 90 second mein start nahi hua.
echo  Log dekhein: C:\CanteenPOS\server-log.txt
goto :end

:ready
echo  Server TAYYAR hai.

:showaddr
echo.
echo  ============================================================
echo   Is PC par:        http://localhost:%PORT%
echo   Counter / Kitchen ki devices par ye address kholain:
powershell -NoProfile -Command "Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | ForEach-Object { '    http://' + $_.IPAddress + ':%PORT%' }"
echo  ============================================================
echo.
echo   System kholne ke liye Desktop wale "Apni Dukaan" nishan
echo   par double-click karein - system apni alag window
echo   mein khulega, aam browser mein nahi.

:end
echo.
pause
endlocal
