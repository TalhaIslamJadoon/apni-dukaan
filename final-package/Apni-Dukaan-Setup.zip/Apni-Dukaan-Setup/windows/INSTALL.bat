@echo off
REM ============================================================
REM  Canteen POS - INSTALL (sab se asaan tareeqa)
REM  Is file par DOUBLE-CLICK karein - baqi sab khud hoga.
REM  Screen par sirf asaan si batain ayengi; saari technical
REM  tafseel isi folder ki install-log.txt mein chali jati hai.
REM  Teeno .ps1 scripts alag se bhi chalaye ja sakte hain -
REM  ye sirf un ka asaan wala darwaza hai.
REM ============================================================
setlocal
title Apni Dukaan - Install
cd /d "%~dp0"
set "LOG=%~dp0install-log.txt"

REM --- Admin check: admin na ho to khud ko admin bana kar dobara kholo ---
fltmc >nul 2>&1
if %errorlevel%==0 goto :adminok
net session >nul 2>&1
if %errorlevel%==0 goto :adminok
echo.
echo  Ek chhota sa sawal ayega - wahan YES dabain...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
exit /b

:adminok
echo Canteen POS install - %date% %time% > "%LOG%"

echo.
echo  ============================================================
echo   CANTEEN POS - INSTALL HO RAHA HAI
echo   Bas intezar karein - sab kuch khud hoga.
echo  ============================================================
echo.

REM --- Database ki jagah: D drive ho to yahin ek sawal mein tay ---
REM --- (choice 02 ko bhej di jati hai, wahan dobara nahi poochta) ---
set "CANTEENPOS_AUTO=1"
if exist "C:\CanteenPOS\app\.env" echo  Purani setting pehle se hai - database ki jagah wohi rahegi jo pehle tay hui thi.
if exist "C:\CanteenPOS\app\.env" goto :dbdone
if exist D:\ (
  echo  Database kahan rakhein?
  echo    [1] D drive - behtar hai
  echo    [2] C drive
  choice /C 12 /N /M "  Number dabayein (1 ya 2): "
  if errorlevel 2 (
    set "CANTEENPOS_PGDATA=C:\CanteenPOS-Data"
  ) else (
    set "CANTEENPOS_PGDATA=D:\CanteenPOS-Data"
  )
  echo.
)
:dbdone

echo  Step 1/3: Zaroori cheezein lag rahi hain, thoda intezar karein...
echo  Beech mein koi chhota window aye to OK / Yes dabate jayein.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp001-install-prereqs.ps1" >> "%LOG%" 2>&1
if errorlevel 1 goto :fail
echo  Step 1 ho gaya.
echo.

echo  Step 2/3: Aap ka system tayyar ho raha hai...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp002-setup-server.ps1" >> "%LOG%" 2>&1
if errorlevel 1 goto :fail
echo  Step 2 ho gaya.
echo.

echo  Step 3/3: Aakhri cheezein...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp003-autostart-and-power.ps1" >> "%LOG%" 2>&1
if errorlevel 1 goto :fail
echo  Step 3 ho gaya.
echo.

echo  ============================================================
echo   System tayyar hai!
echo  ============================================================
echo   Desktop par "Apni Dukaan" ke naam ka nishan ban gaya
echo   hai - roz usi par double-click karke system kholain.
echo.
echo   Isi PC par pata: http://localhost:3100
echo   Doosri devices (counter, kitchen) par is PC ka network
echo   wala pata khulega.
echo  ============================================================
echo.
pause
exit /b 0

:fail
echo.
echo  ============================================================
echo   Kuch masla aa gaya hai. Ye file bhejein: install-log.txt
echo   (ye file isi windows folder mein bani hai)
echo  ============================================================
echo.
pause
exit /b 1
