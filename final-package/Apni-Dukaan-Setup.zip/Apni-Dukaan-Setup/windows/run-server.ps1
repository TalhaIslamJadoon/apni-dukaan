# =====================================================================
#  Canteen POS - Server launcher (run-server.ps1)
#  C:\CanteenPOS\app\.env se settings parh kar Next.js server ko
#  port 3100 par chalata hai. Ye file 02-setup-server.ps1 ke zariye
#  C:\CanteenPOS\ mein copy hoti hai; Scheduled Task aur
#  start-server.bat isi ko chalate hain.
#  Foreground mein chalta hai - is window/process ko band karna
#  matlab server band karna.
#  NOTE: Is launcher mein database ka koi rasta hardcode NAHI hai -
#  database ki jagah (PGDATA) aur backups ki jagah (BACKUP_DIR)
#  02 ne .env mein likhi thi aur wohi values neeche .env parhne
#  se khud is process mein aa jati hain. PostgreSQL ko is ki
#  Windows service chalati hai jo 02 ne usi data folder par
#  set ki thi.
# =====================================================================

$Port   = 3100
$Root   = 'C:\CanteenPOS'
$AppDir = Join-Path $Root 'app'
$LogDir = Join-Path $Root 'Logs'
$LogFile = Join-Path $LogDir 'server.log'

if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir -Force | Out-Null }

function Log-Line([string]$Text) {
    $line = '{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Text
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
    Write-Host $line
}

# --- .env parh kar process environment mein dalna --------------------
# (Next.js khud bhi .env parhta hai, lekin db scripts aur yakeen ke
#  liye yahan se set karna sab se pakka tareeqa hai.)
$envFile = Join-Path $AppDir '.env'
if (-not (Test-Path $envFile)) {
    Log-Line 'ERROR: .env nahi mila - pehle 02-setup-server.ps1 chalain.'
    exit 1
}
foreach ($raw in Get-Content $envFile) {
    $line = $raw.Trim()
    if ($line -eq '' -or $line.StartsWith('#')) { continue }
    $idx = $line.IndexOf('=')
    if ($idx -lt 1) { continue }
    $name  = $line.Substring(0, $idx).Trim()
    $value = $line.Substring($idx + 1).Trim()
    [Environment]::SetEnvironmentVariable($name, $value, 'Process')
}

$nextCmd = Join-Path $AppDir 'node_modules\.bin\next.cmd'
if (-not (Test-Path $nextCmd)) {
    Log-Line 'ERROR: node_modules nahi mila - pehle 02-setup-server.ps1 chalain (npm install baqi hai).'
    exit 1
}

Set-Location $AppDir
Log-Line ("Server start ho raha hai - port {0}" -f $Port)

# --- Server chalana (foreground) --------------------------------------
# -H 0.0.0.0 = dukaan ke local network (LAN) par bhi sunega,
# sirf is PC par nahi. Firewall rule script 03 mein sirf local
# subnet ke liye khulta hai.
& $nextCmd start -p $Port -H 0.0.0.0 2>&1 | Tee-Object -FilePath $LogFile -Append

Log-Line 'Server band ho gaya.'
