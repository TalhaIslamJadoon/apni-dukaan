# =====================================================================
#  Canteen POS - Daily Backup (04-daily-backup.ps1)
#  pg_dump se database ka backup rakhta hai - date-stamped file,
#  aakhri 14 backups mehfooz, baqi delete.
#  Backup ki JAGAH app ki .env se ati hai (BACKUP_DIR - 02 ne
#  database wali drive par CanteenPOS-Backups tay kiya tha).
#  BACKUP_DIR na mile to PGDATA wali drive par CanteenPOS-Backups,
#  aur woh bhi na mile to purana default C:\CanteenPOS\Backups
#  (console par saaf note ke sath).
#  Nateeja backup folder ki backup.log mein likhta hai.
#  Ye script Scheduled Task (roz 22:30) chalata hai; haath se bhi
#  chala sakte hain. Format app ke apne backup jaisa hai (-Fc).
#  Linux par authored - Windows par untested.
# =====================================================================

$ErrorActionPreference = 'Stop'

$Root      = 'C:\CanteenPOS'
$AppDir    = Join-Path $Root 'app'
$KeepLast  = 14

# --- Backup ki jagah .env se tay karna --------------------------------
$envFile = Join-Path $AppDir '.env'
$BackupDir = $null
$PgData = $null
if (Test-Path $envFile) {
    foreach ($raw in Get-Content $envFile) {
        if ($raw -match '^\s*BACKUP_DIR\s*=\s*(.+)$') { $BackupDir = $Matches[1].Trim() }
        if ($raw -match '^\s*PGDATA\s*=\s*(.+)$')     { $PgData    = $Matches[1].Trim() }
    }
}
$usedFallback = $false
if (-not $BackupDir -and $PgData) {
    $drive = [System.IO.Path]::GetPathRoot($PgData)
    if ($drive) { $BackupDir = Join-Path $drive 'CanteenPOS-Backups' }
}
if (-not $BackupDir) {
    $BackupDir = Join-Path $Root 'Backups'
    $usedFallback = $true
}

if (-not (Test-Path $BackupDir)) { New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null }
$LogFile = Join-Path $BackupDir 'backup.log'

function Log-Line([string]$Text) {
    $line = '{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Text
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
    Write-Host $line
}

if ($usedFallback) {
    Log-Line 'NOTE: .env mein BACKUP_DIR/PGDATA nahi mila - purana default C:\CanteenPOS\Backups istemal ho raha hai.'
}

function Find-PgDump {
    $base = 'C:\Program Files\PostgreSQL'
    if (Test-Path $base) {
        $dirs = Get-ChildItem $base -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending
        foreach ($d in $dirs) {
            $candidate = Join-Path $d.FullName 'bin\pg_dump.exe'
            if (Test-Path $candidate) { return $candidate }
        }
    }
    $cmd = Get-Command pg_dump.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

try {
    $pgDump = Find-PgDump
    if (-not $pgDump) { throw 'pg_dump.exe nahi mila - PostgreSQL install check karein.' }

    # DATABASE_URL app ki .env se parhein (koi password is file mein nahi):
    if (-not (Test-Path $envFile)) { throw '.env nahi mila - pehle 02-setup-server.ps1 chalain.' }
    $dbUrl = $null
    foreach ($raw in Get-Content $envFile) {
        if ($raw -match '^\s*DATABASE_URL\s*=\s*(.+)$') { $dbUrl = $Matches[1].Trim() }
    }
    if (-not $dbUrl) { throw '.env mein DATABASE_URL nahi mila.' }

    $stamp = Get-Date -Format 'yyyy-MM-dd_HHmm'
    $fileName = "canteen-pos-$stamp.dump"
    $filePath = Join-Path $BackupDir $fileName

    & $pgDump -Fc -f $filePath $dbUrl
    if ($LASTEXITCODE -ne 0) { throw ("pg_dump fail hua (code {0})" -f $LASTEXITCODE) }
    if (-not (Test-Path $filePath)) { throw 'pg_dump ne file nahi banai.' }
    $size = (Get-Item $filePath).Length
    if ($size -le 0) { throw 'Backup file khali hai - fail mana gaya.' }
    Log-Line ("OK  {0}  ({1:N0} bytes)" -f $fileName, $size)

    # Aakhri 14 rakhein, purane delete:
    $all = Get-ChildItem $BackupDir -Filter 'canteen-pos-*.dump' | Sort-Object Name -Descending
    if ($all.Count -gt $KeepLast) {
        $old = $all | Select-Object -Skip $KeepLast
        foreach ($f in $old) {
            Remove-Item $f.FullName -Force
            Log-Line ("Purana backup delete: {0}" -f $f.Name)
        }
    }
    exit 0
}
catch {
    Log-Line ("FAIL  {0}" -f $_.Exception.Message)
    exit 1
}
