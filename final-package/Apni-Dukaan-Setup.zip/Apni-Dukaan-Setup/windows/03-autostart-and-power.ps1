# =====================================================================
#  Canteen POS - Phase 2 - Script 03: Auto-Start + Power + Firewall
#  - Scheduled Task: PC on hote hi AUR logon par server khud start
#    (SYSTEM account; launcher C:\CanteenPOS\run-server.cmd hai
#    jisme node ka pura rasta likha hota hai - PATH par inhisaar
#    nahi - aur saari output C:\CanteenPOS\server-log.txt mein
#    jati hai, taake koi nakami khamosh na rahe)
#  - Aakhir mein server wali task abhi chala di jati hai aur port
#    check karke tasdeeq bhi - update mein 02 ne chalta server
#    band kiya hota hai, wo yahin se wapas chalta hai
#  - Scheduled Task: roz raat 22:30 backup (na ho sakay to agle boot
#    par khud chal jata hai - StartWhenAvailable)
#  - Power: bijli (AC) lagi ho to PC kabhi sleep nahi hoga;
#    screen band ho sakti hai
#  - Firewall: port 3100 sirf LOCAL SUBNET (dukaan ka LAN) ke liye
#  Admin PowerShell mein chalain. Re-run safe hai (tasks -Force se
#  update ho jate hain). Linux par authored - Windows par untested.
# =====================================================================

$ErrorActionPreference = 'Stop'
$failed = $false

$Port      = 3100
$Root      = 'C:\CanteenPOS'
$Launcher  = Join-Path $Root 'run-server.cmd'
$BackupPs1 = Join-Path $Root '04-daily-backup.ps1'
$PsExe     = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'

function Test-IsAdmin {
    $identity  = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-IsAdmin)) {
    Write-Host 'Admin rights chahiye - UAC prompt par Yes dabain...' -ForegroundColor Yellow
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

try {
    Write-Host ''
    Write-Host '===================================================' -ForegroundColor Cyan
    Write-Host ' STEP 3/3 - Auto-start + Power + Firewall' -ForegroundColor Cyan
    Write-Host '===================================================' -ForegroundColor Cyan

    # Helper files pack se C:\CanteenPOS mein le aain (agar 02 se na aye hon):
    foreach ($helper in @('run-server.ps1', '04-daily-backup.ps1')) {
        $dest = Join-Path $Root $helper
        $srcHelper = Join-Path $PSScriptRoot $helper
        if ((-not (Test-Path $dest)) -and (Test-Path $srcHelper)) {
            Copy-Item $srcHelper -Destination $dest -Force
        }
    }

    # --- Server launcher (run-server.cmd) banana -----------------------
    # Scheduled Task isi file ko chalata hai. Node.js ka PURA rasta
    # yahin andar likh diya jata hai, taake Task Scheduler ke SYSTEM
    # account ko PATH par inhisaar na karna pare. (Purane tareeqe ki
    # sab se bari kamzori yahi thi: run-server.ps1 next.cmd chalata
    # tha, aur next.cmd PATH se node dhoondta hai - SYSTEM ke PATH
    # mein node na ho to server khamoshi se band ho jata tha, task
    # phir bhi "success" dikhata tha.)
    $nodeExe = $null
    $nodeCmd = Get-Command node.exe -ErrorAction SilentlyContinue
    if ($nodeCmd) { $nodeExe = $nodeCmd.Source }
    if (-not $nodeExe) {
        foreach ($cand in @('C:\Program Files\nodejs\node.exe', 'C:\Program Files (x86)\nodejs\node.exe')) {
            if (Test-Path $cand) { $nodeExe = $cand; break }
        }
    }
    if (-not $nodeExe) { throw 'Node.js nahi mila - pehle 01-install-prereqs.ps1 chalain.' }
    $launcherTpl = Join-Path $PSScriptRoot 'run-server.cmd'
    if (-not (Test-Path $launcherTpl)) { throw 'run-server.cmd pack mein nahi mila - pack dobara copy karein.' }
    $launcherText = [IO.File]::ReadAllText($launcherTpl)
    $launcherText = $launcherText.Replace('__NODE_EXE__', $nodeExe)
    [IO.File]::WriteAllText($Launcher, $launcherText, [Text.Encoding]::ASCII)
    Write-Host ("Server launcher ban gaya: {0} (Node: {1})" -f $Launcher, $nodeExe) -ForegroundColor Green
    if (-not (Test-Path $BackupPs1)) {
        Write-Host 'NOTE: 04-daily-backup.ps1 nahi mila - backup task nahi banega (baqi sab ho jayega).' -ForegroundColor Yellow
    }

    # --- 1. Server auto-start task (boot + logon dono par) --------------
    # Do trigger is liye: boot wala kisi wajah se reh jaye to logon
    # wala pakar lega. Action ab run-server.cmd hai (PowerShell
    # launcher nahi): is ke andar node ka pura rasta likha hota
    # hai, PostgreSQL ko pehle check/chala leta hai, aur nakami
    # par hamesha exit 1 karta hai - isi liye RestartCount asal
    # mein kaam karta hai (purana ps1 launcher nakami par bhi
    # exit 0 kar deta tha, task dobara kabhi nahi chalta tha).
    $serverAction  = New-ScheduledTaskAction -Execute $Launcher -WorkingDirectory $Root
    $serverTriggers = @(
        (New-ScheduledTaskTrigger -AtStartup),
        (New-ScheduledTaskTrigger -AtLogOn)
    )
    $serverPrincipal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $serverSettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit (New-TimeSpan -Seconds 0) -MultipleInstances IgnoreNew
    Register-ScheduledTask -TaskName 'CanteenPOS Server' -Action $serverAction -Trigger $serverTriggers -Principal $serverPrincipal -Settings $serverSettings -Description 'Apni Dukaan server - PC on / logon par khud start (launcher: C:\CanteenPOS\run-server.cmd, log: C:\CanteenPOS\server-log.txt)' -Force | Out-Null
    Write-Host "Scheduled Task 'CanteenPOS Server' ban gaya (boot + logon par auto-start)." -ForegroundColor Green

    # --- 2. Daily backup task (22:30) ------------------------------------
    if (Test-Path $BackupPs1) {
        $backupAction  = New-ScheduledTaskAction -Execute $PsExe -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$BackupPs1`""
        $backupTrigger = New-ScheduledTaskTrigger -Daily -At '22:30'
        $backupSettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 10)
        Register-ScheduledTask -TaskName 'CanteenPOS Daily Backup' -Action $backupAction -Trigger $backupTrigger -Principal $serverPrincipal -Settings $backupSettings -Description 'Canteen POS database ka rozana backup (jagah .env ke BACKUP_DIR se - aam tor par database wali drive par CanteenPOS-Backups)' -Force | Out-Null
        Write-Host "Scheduled Task 'CanteenPOS Daily Backup' ban gaya (roz 22:30; PC band ho to agle boot par)." -ForegroundColor Green
    }

    # --- 3. Power: AC par sleep band, screen band ho sakti hai ------------
    Write-Host 'Power settings badal rahe hain (sirf AC / bijli par)...'
    & powercfg /change standby-timeout-ac 0    # kabhi sleep nahi (AC)
    & powercfg /change hibernate-timeout-ac 0  # kabhi hibernate nahi (AC)
    & powercfg /change disk-timeout-ac 0       # disk band nahi (AC)
    & powercfg /change monitor-timeout-ac 10   # screen 10 minute mein band - ye theek hai
    Write-Host 'Power: AC par sleep OFF, screen 10 min mein OFF (ye normal hai).' -ForegroundColor Green
    Write-Host 'NOTE: Agar ye PC laptop hai to Settings > Power mein "lid band karne par" wala'
    Write-Host '      action "Do nothing" kar dein, warna dhakkan band = sleep ho sakta hai.' -ForegroundColor Yellow

    # --- 4. Firewall: port 3100 sirf local subnet ke liye ------------------
    $ruleName = 'Apni Dukaan (3100)'
    Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
    New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Action Allow -Protocol TCP -LocalPort $Port -RemoteAddress LocalSubnet -Profile Private | Out-Null
    Write-Host ("Firewall rule ban gaya: port {0} sirf local subnet + Private profile ke liye khula hai." -f $Port) -ForegroundColor Green
    Write-Host 'NOTE: Dukaan ke router wale network ka profile Windows mein "Private" hona'
    Write-Host '      chahiye (Settings > Network > Properties). Public ho to rule kaam nahi karega.' -ForegroundColor Yellow

    # --- 5. Desktop shortcut + Print Agent auto-start ---------------------
    # Aam bande ko address type na karna pare: Desktop par 'Apni
    # Dukaan' ka nishan (sab users ke liye, Public Desktop).
    # Talha ki hidayat: system aam browser mein NAHI khulna
    # chahiye - apni alag window mein khule, jaise asal software
    # hota hai. Is liye shortcut ab Edge/Chrome ko --app mode
    # mein chalata hai (na address bar, na tabs - sirf system).
    # Dono browser na milain to purana .url wala tareeqa
    # (default browser) - icon phir bhi apna hi lagega.
    $publicDesktop = [Environment]::GetFolderPath('CommonDesktopDirectory')
    if ($publicDesktop -and (Test-Path $publicDesktop)) {
        # Branded icon: pack ke windows folder se C:\CanteenPOS mein
        # copy kar dein - shortcut usi ki taraf ishara karega, taake
        # Desktop par asal 'Apni Dukaan' wala icon nazar aye.
        $iconDest = Join-Path $Root 'apni-dukaan.ico'
        $iconSrc  = Join-Path $PSScriptRoot 'apni-dukaan.ico'
        if (Test-Path $iconSrc) { Copy-Item $iconSrc -Destination $iconDest -Force }
        $appUrl  = "http://localhost:$Port"
        $lnkFile = Join-Path $publicDesktop 'Apni Dukaan.lnk'
        $urlFile = Join-Path $publicDesktop 'Apni Dukaan.url'
        $browserExe = $null
        foreach ($cand in @('C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
                            'C:\Program Files\Microsoft\Edge\Application\msedge.exe',
                            'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
                            'C:\Program Files\Google\Chrome\Application\chrome.exe')) {
            if (Test-Path $cand) { $browserExe = $cand; break }
        }
        if ($browserExe) {
            $wsShell = New-Object -ComObject WScript.Shell
            $lnk = $wsShell.CreateShortcut($lnkFile)
            $lnk.TargetPath = $browserExe
            $lnk.Arguments = "--app=$appUrl"
            $lnk.WorkingDirectory = $Root
            if (Test-Path $iconDest) { $lnk.IconLocation = "$iconDest,0" }
            $lnk.Description = 'Apni Dukaan - apni window mein khulta hai'
            $lnk.Save()
            # Purana .url wala nishan hata dein - do nishan na hon.
            if (Test-Path $urlFile) { Remove-Item $urlFile -Force }
            Write-Host ("Desktop par 'Apni Dukaan' ka nishan ban gaya - system apni alag window mein khulega (aam browser nahi lagega).") -ForegroundColor Green
        } else {
            [IO.File]::WriteAllLines($urlFile, @('[InternetShortcut]', ("URL=http://localhost:{0}" -f $Port), ("IconFile={0}" -f $iconDest), 'IconIndex=0'))
            if (Test-Path $lnkFile) { Remove-Item $lnkFile -Force }
            Write-Host 'Edge/Chrome nahi mila - Desktop shortcut default browser mein khulega.' -ForegroundColor Yellow
        }
        # Icon cache refresh - ye fail bhi ho jaye to step fail nahi hona chahiye.
        try { & ie4uinit.exe -show 2>$null } catch { }
    }
    # Print Agent: pehle se PAIRED ho to logon par auto-start (sab
    # users ke Startup folder mein shortcut). Paired na ho to kuch
    # nahi karte - pairing ke waqt pair.js khud auto-start laga
    # deta hai, is liye koi error bhi nahi ata.
    $agentDir = Join-Path (Split-Path $PSScriptRoot -Parent) 'print-agent'
    $agentBat = Join-Path $agentDir 'start-print-agent.bat'
    $agentCfg = Join-Path $agentDir 'print-agent.config.json'
    $agentPaired = $false
    if (Test-Path $agentCfg) {
        $cfgText = Get-Content $agentCfg -Raw
        if (($cfgText -match '"agentToken"\s*:\s*"([^"]+)"') -and ($Matches[1] -ne 'PASTE_TOKEN_FROM_PAIRING') -and ($Matches[1].Length -gt 8)) { $agentPaired = $true }
    }
    if ((Test-Path $agentBat) -and $agentPaired) {
        $startupDir = [Environment]::GetFolderPath('CommonStartup')
        $shell = New-Object -ComObject WScript.Shell
        $lnk = $shell.CreateShortcut((Join-Path $startupDir 'Apni Dukaan Print Agent.lnk'))
        $lnk.TargetPath = $agentBat
        $lnk.WorkingDirectory = $agentDir
        $lnk.WindowStyle = 7   # minimized - screen par khalal nahi
        $lnk.Description = 'Apni Dukaan Print Agent - logon par khud start'
        $lnk.Save()
        Write-Host 'Print Agent pehle se paired hai - logon par auto-start set kar diya.' -ForegroundColor Green
    } elseif (Test-Path $agentBat) {
        Write-Host 'Print Agent abhi paired nahi hai - pairing hote hi wo khud auto-start mein jud jayega.' -ForegroundColor Yellow
    }

    # --- 6. Is PC ke LAN addresses ------------------------------------------
    Write-Host ''
    Write-Host 'Is PC ke LAN addresses (counter devices par yehi likhna hoga):' -ForegroundColor Cyan
    $ips = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' }
    foreach ($ip in $ips) {
        Write-Host ("  http://{0}:{1}" -f $ip.IPAddress, $Port) -ForegroundColor Green
    }
    Write-Host 'In mein se router wale network ka address note kar lein - README mein'
    Write-Host 'IP FIX karne wala step zaroor karein taake ye address roz na badle.'

    # --- 7. Server abhi chala dein ---------------------------------------
    # Update ke waqt 02 ne chalta server band kiya tha - use abhi
    # isi task se dobara chala dein, taake install ke foran baad
    # dukaan ka kaam shuru ho jaye aur restart ka intezar na karna
    # pare. Pehli install par bhi yehi task server ko pehli dafa
    # chalata hai. Server pehle se chal raha ho to Start wali
    # koshish khamoshi se guzar jati hai (MultipleInstances
    # IgnoreNew) aur neeche wala check foran pass ho jata hai.
    Write-Host ''
    Write-Host 'Server chala rahe hain...' -ForegroundColor Cyan
    $serverUp = $false
    try {
        Start-ScheduledTask -TaskName 'CanteenPOS Server' -ErrorAction Stop
        for ($i = 1; $i -le 30; $i++) {
            Start-Sleep -Seconds 2
            try {
                $resp = Invoke-WebRequest -Uri ("http://127.0.0.1:{0}/" -f $Port) -UseBasicParsing -TimeoutSec 3
                if ($resp.StatusCode -ge 200) { $serverUp = $true; break }
            } catch {
                if ($_.Exception.Response) { $serverUp = $true; break }  # koi bhi HTTP jawab = server zinda hai
            }
        }
    } catch {
        Write-Host ("Server task start nahi hua: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
    }
    if ($serverUp) {
        Write-Host ("Server CHAL RAHA hai - http://localhost:{0} tayyar hai." -f $Port) -ForegroundColor Green
    } else {
        Write-Host 'Server abhi jawab nahi de raha - PC ek dafa restart kar dein, task use khud chala dega.' -ForegroundColor Yellow
        Write-Host 'Restart ke baad bhi na chale to ye file bhejein: C:\CanteenPOS\server-log.txt' -ForegroundColor Yellow
    }

    Write-Host ''
    Write-Host 'STEP 3 COMPLETE. Test karein:' -ForegroundColor Green
    Write-Host '  1) Desktop wale "Apni Dukaan" nishan par double-click karein - system apni alag window mein khulega'
    Write-Host '  2) Ek dafa PC restart karke bhi dekh lein ke server khud start hota hai ya nahi'
    Write-Host '  3) Server na chale to log dekhein: C:\CanteenPOS\server-log.txt'
}
catch {
    $failed = $true
    Write-Host ''
    Write-Host ("ERROR: {0}" -f $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Masla hal karke script dobara chalain - dobara chalana safe hai.'
}
Write-Host ''
if ($env:CANTEENPOS_AUTO -ne '1') { Read-Host 'Band karne ke liye Enter dabain' }
if ($failed) { exit 1 }
