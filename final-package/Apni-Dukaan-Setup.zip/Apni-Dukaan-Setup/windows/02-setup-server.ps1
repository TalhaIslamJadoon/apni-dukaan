# =====================================================================
#  Canteen POS - Phase 2 - Script 02: Server Setup (Windows)
#  - C:\CanteenPOS layout banata hai, app copy karke build karta hai
#  - Database ki JAGAH operator khud chunta hai (C: par majboori
#    nahi): D drive ho to 1/2 ke sawal se, warna C par khud.
#    PostgreSQL service usi folder se chalti hai; jagah .env mein
#    PGDATA ke naam se likh jati hai, backups usi drive par
#    CanteenPOS-Backups mein bante hain (BACKUP_DIR bhi .env mein).
#  - Database ke passwords OPERATOR se NAHI mange jate - script
#    khud mazboot random passwords bana kar sirf .env mein rakhta
#    hai (woh file permissions se band hoti hai). Staff PINs hi
#    asal lock hain; DB password kisi ko yaad rakhne ki zaroorat
#    nahi.
#  - npm run db:setup (migrate + seed) chalata hai
#  - Aakhir mein server ko test ke liye chala kar port check karta hai
#  Admin PowerShell mein chalain. Re-run karna safe hai (idempotent).
#  NOTE: Linux par authored hai - Windows par abhi test nahi hui.
#
#  App source kahan se ayega?
#  Script pehle <is pack ke folder>\app-source\ dekhta hai (deployment
#  USB par app ki files wahan rakhi hongi, node_modules ke baghair).
#  Na mile to script rasta poochta hai.
# =====================================================================

param(
    [string]$SourceDir = ''
)

$ErrorActionPreference = 'Stop'

$Port     = 3100
$Root     = 'C:\CanteenPOS'
$AppDir   = Join-Path $Root 'app'
$BackupDir = Join-Path $Root 'Backups'   # sirf ibtedai default - asal jagah step 3b mein tay hoti hai
$LogDir   = Join-Path $Root 'Logs'
$DbName   = 'canteen_pos'
$DbUser   = 'canteen_pos_app'
$DbHost   = '127.0.0.1'
$DbPort   = 5432

# PostgreSQL superuser ka password: ya .env se milta hai (purani
# setting) ya script khud bana leta hai (naya cluster). Operator
# se kabhi nahi manga jata.
$script:PgSuperPassword = $null
$failed = $false

function Test-IsAdmin {
    $identity  = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Find-Psql {
    $base = 'C:\Program Files\PostgreSQL'
    if (Test-Path $base) {
        $dirs = Get-ChildItem $base -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending
        foreach ($d in $dirs) {
            $candidate = Join-Path $d.FullName 'bin\psql.exe'
            if (Test-Path $candidate) { return $candidate }
        }
    }
    $cmd = Get-Command psql.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

function Find-PgBinDir {
    $psql = Find-Psql
    if ($psql) { return Split-Path $psql -Parent }
    return $null
}

function Read-EnvValue([string]$File, [string]$Key) {
    if (-not (Test-Path $File)) { return $null }
    $pattern = '^\s*' + [regex]::Escape($Key) + '\s*=\s*(.+)$'
    foreach ($raw in Get-Content $File) {
        if ($raw -match $pattern) { return $Matches[1].Trim() }
    }
    return $null
}

function New-RandomPassword {
    $bytes = New-Object byte[] 24
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    return [Convert]::ToBase64String($bytes)
}

function Get-PgServiceInfo {
    $svc = Get-CimInstance Win32_Service -Filter "Name LIKE 'postgresql%'" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($svc) {
        return [pscustomobject]@{ Name = $svc.Name; PathName = $svc.PathName; StartName = $svc.StartName }
    }
    $gs = Get-Service -Name 'postgresql*' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($gs) {
        $reg = Get-ItemProperty ("HKLM:\SYSTEM\CurrentControlSet\Services\{0}" -f $gs.Name) -ErrorAction SilentlyContinue
        if ($reg) {
            return [pscustomobject]@{ Name = $gs.Name; PathName = $reg.ImagePath; StartName = $reg.ObjectName }
        }
    }
    return $null
}

function Get-ServiceDataDir([string]$PathName) {
    if (-not $PathName) { return $null }
    if ($PathName -match '-D\s+"([^"]+)"') { return $Matches[1] }
    if ($PathName -match '-D\s+([^\s"]+)') { return $Matches[1] }
    return $null
}

if (-not (Test-IsAdmin)) {
    Write-Host 'Admin rights chahiye - UAC prompt par Yes dabain...' -ForegroundColor Yellow
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

try {
    Write-Host ''
    Write-Host '===================================================' -ForegroundColor Cyan
    Write-Host ' STEP 2/3 - Apni Dukaan server setup' -ForegroundColor Cyan
    Write-Host '===================================================' -ForegroundColor Cyan

    # --- 1. Pehle se zaroori cheezein check ---------------------------
    if (-not (Get-Command node.exe -ErrorAction SilentlyContinue)) {
        throw 'Node.js nahi mila - pehle 01-install-prereqs.ps1 chalain.'
    }
    $psql = Find-Psql
    if (-not $psql) { throw 'PostgreSQL (psql) nahi mila - pehle 01-install-prereqs.ps1 chalain.' }

    $svc = Get-Service -Name 'postgresql*' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($svc -and $svc.Status -ne 'Running') {
        Start-Service -Name $svc.Name
        Write-Host ("PostgreSQL service start kar diya: {0}" -f $svc.Name)
    }

    # --- 2. Folder layout ----------------------------------------------
    foreach ($dir in @($Root, $AppDir, $BackupDir, $LogDir)) {
        if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    }
    Write-Host ("Folders tayar hain: {0}" -f $Root) -ForegroundColor Green

    # --- 3. App source copy ---------------------------------------------
    if ($SourceDir -eq '') {
        $defaultSource = Join-Path $PSScriptRoot 'app-source'
        if (Test-Path (Join-Path $defaultSource 'package.json')) {
            $SourceDir = $defaultSource
        } elseif (-not (Test-Path (Join-Path $AppDir 'package.json'))) {
            $SourceDir = Read-Host 'App source ka folder likhein (jahan package.json hai)'
        }
    }
    if ($SourceDir -ne '') {
        if (-not (Test-Path (Join-Path $SourceDir 'package.json'))) {
            throw ("Us folder mein package.json nahi mila: {0}" -f $SourceDir)
        }
        Write-Host ("App copy ho raha hai: {0} -> {1}" -f $SourceDir, $AppDir)
        # .env* is liye exclude hai taake purani/development settings
        # galti se production mein na aa jain; node_modules Windows
        # par fresh bane ga.
        & robocopy $SourceDir $AppDir /E /XD node_modules .next .git screenshots backups /XF '.env*' 'tsconfig.tsbuildinfo' /NFL /NDL /NJH /NJS
        if ($LASTEXITCODE -ge 8) { throw ("robocopy fail hua (code {0})" -f $LASTEXITCODE) }
        Write-Host 'App copy ho gaya.' -ForegroundColor Green
    } else {
        Write-Host 'App pehle se C:\CanteenPOS\app mein hai - copy wala step skip.' -ForegroundColor Green
    }

    # --- 3b. Database ki jagah + PostgreSQL cluster ----------------------
    # Jagah ka faisla is tarteeb se: INSTALL.bat ne pehle se tay ki ho
    # (CANTEENPOS_PGDATA) -> .env mein likhi ho (purani setting) ->
    # D drive ho to 1/2 ka sawal -> warna C drive khud bakhud.
    Write-Host ''
    Write-Host '--- Database ki jagah ---' -ForegroundColor Cyan
    $envFile = Join-Path $AppDir '.env'
    $recordedPgData = Read-EnvValue $envFile 'PGDATA'
    $recordedBackup = Read-EnvValue $envFile 'BACKUP_DIR'
    $recordedSuper  = Read-EnvValue $envFile 'PG_SUPERUSER_PASSWORD'
    if ($recordedSuper) { $script:PgSuperPassword = $recordedSuper }

    if ($env:CANTEENPOS_PGDATA) {
        $PgData = $env:CANTEENPOS_PGDATA
        Write-Host ("Database ki jagah INSTALL.bat ne tay ki: {0}" -f $PgData)
    } elseif ($recordedPgData) {
        $PgData = $recordedPgData
        Write-Host ("Database ki jagah pehle se tay hai (.env se): {0}" -f $PgData) -ForegroundColor Green
    } elseif (Test-Path 'D:\') {
        Write-Host ''
        Write-Host 'Database kahan rakhein?'
        Write-Host '  [1] D drive (behtar hai)'
        Write-Host '  [2] C drive'
        $choice = Read-Host 'Number dabayein (1 ya 2) - khali chhorein to 1'
        if ("$choice".Trim() -eq '2') { $PgData = 'C:\CanteenPOS-Data' } else { $PgData = 'D:\CanteenPOS-Data' }
    } else {
        $PgData = 'C:\CanteenPOS-Data'
        Write-Host 'D drive nahi hai - database C drive par rakha jayega.'
    }
    $PgData = $PgData.Trim().Trim('"')
    while ($PgData.Length -gt 3 -and $PgData.EndsWith('\')) { $PgData = $PgData.Substring(0, $PgData.Length - 1) }
    if (-not [System.IO.Path]::IsPathRooted($PgData)) {
        throw ("Database ki jagah theek nahi lagi: {0}" -f $PgData)
    }
    $dataDrive = [System.IO.Path]::GetPathRoot($PgData)
    if (-not (Test-Path $dataDrive)) {
        throw ("Drive maujood nahi: {0} - drive check karke script dobara chalain." -f $dataDrive)
    }
    if (-not (Test-Path $PgData)) { New-Item -ItemType Directory -Path $PgData -Force | Out-Null }

    # Backups database wali drive par hi bante hain:
    if ($recordedBackup) { $BackupDir = $recordedBackup }
    else { $BackupDir = Join-Path $dataDrive 'CanteenPOS-Backups' }
    if (-not (Test-Path $BackupDir)) { New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null }
    Write-Host ("Database folder : {0}" -f $PgData) -ForegroundColor Green
    Write-Host ("Backup folder   : {0}" -f $BackupDir) -ForegroundColor Green

    # PostgreSQL service ko is jagah ke cluster par set karna:
    $pgBin = Find-PgBinDir
    if (-not $pgBin) { throw 'PostgreSQL ke tools (bin folder) nahi mile - pehle 01-install-prereqs.ps1 chalain.' }
    $pgCtl  = Join-Path $pgBin 'pg_ctl.exe'
    $initdb = Join-Path $pgBin 'initdb.exe'
    $svcInfo = Get-PgServiceInfo
    if (-not $svcInfo) { throw 'PostgreSQL service nahi mila - pehle 01-install-prereqs.ps1 chalain.' }
    $svcName = $svcInfo.Name
    $currentData = Get-ServiceDataDir $svcInfo.PathName
    $pointsHere = $false
    if ($currentData -and ($currentData.TrimEnd('\') -ieq $PgData)) { $pointsHere = $true }
    $clusterReady = Test-Path (Join-Path $PgData 'PG_VERSION')

    if ($clusterReady -and $pointsHere) {
        Write-Host 'PostgreSQL pehle se isi jagah set hai - wohi cluster chalega.' -ForegroundColor Green
        if ((Get-Service -Name $svcName).Status -ne 'Running') { Start-Service -Name $svcName }
    } else {
        if ((Get-Service -Name $svcName).Status -ne 'Stopped') {
            Write-Host ("PostgreSQL service band ho raha hai ({0})..." -f $svcName)
            Stop-Service -Name $svcName -Force
            (Get-Service -Name $svcName).WaitForStatus([System.ServiceProcess.ServiceControllerStatus]::Stopped, [TimeSpan]::FromSeconds(60))
        }
        if (-not $clusterReady) {
            # Naya cluster: superuser password bhi script khud banata hai.
            if (-not $script:PgSuperPassword) { $script:PgSuperPassword = New-RandomPassword }
            Write-Host ("Naya database cluster ban raha hai: {0}" -f $PgData) -ForegroundColor Yellow
            $pwFile = Join-Path $env:TEMP ("pgpw-{0}.txt" -f [guid]::NewGuid().ToString('N'))
            try {
                [IO.File]::WriteAllText($pwFile, $script:PgSuperPassword)
                & $initdb -D $PgData -U postgres "--pwfile=$pwFile" --auth=scram-sha-256 -E UTF8
                if ($LASTEXITCODE -ne 0) { throw 'initdb fail hua - upar wali error dekhein.' }
            } finally {
                Remove-Item $pwFile -Force -ErrorAction SilentlyContinue
            }
            $clusterReady = $true
            Write-Host 'Database cluster ban gaya.' -ForegroundColor Green
        }
        # Service jis account se chalti hai use data folder par haq
        # dein (D: waghera par ye zaroori ho sakta hai; LocalSystem
        # ko pehle se hota hai):
        $svcAccount = $svcInfo.StartName
        if ($svcAccount -and ($svcAccount -ne 'LocalSystem')) {
            & icacls $PgData /grant ("{0}:(OI)(CI)F" -f $svcAccount) /T /Q | Out-Null
            if ($LASTEXITCODE -eq 0) {
                Write-Host ("Service account ({0}) ko database folder par access de diya." -f $svcAccount)
            } else {
                Write-Host ("WARNING: database folder par service account ({0}) ka access set nahi hua - service start na ho to folder ki permissions check karein." -f $svcAccount) -ForegroundColor Yellow
            }
        }
        if (-not $pointsHere) {
            # Service ki registry setting mein sirf -D (data folder)
            # badalte hain - service account waghera sab waisa hi
            # rehta hai jaisa installer ne rakha tha.
            $binPath = '"{0}" runservice -N "{1}" -D "{2}" -w' -f $pgCtl, $svcName, $PgData
            & sc.exe config $svcName "binPath= $binPath" | Out-Null
            if ($LASTEXITCODE -ne 0) { throw 'PostgreSQL service ki data directory change nahi hui (sc.exe fail hua).' }
            & sc.exe config $svcName 'start= auto' | Out-Null
            Write-Host ("PostgreSQL service ab is folder se chalega: {0}" -f $PgData) -ForegroundColor Green
        }
        Start-Service -Name $svcName
        (Get-Service -Name $svcName).WaitForStatus([System.ServiceProcess.ServiceControllerStatus]::Running, [TimeSpan]::FromSeconds(60))
        Write-Host 'PostgreSQL service chal raha hai.' -ForegroundColor Green
    }

    # --- 4. Database + .env ---------------------------------------------
    $dbUrl = Read-EnvValue $envFile 'DATABASE_URL'

    if ($dbUrl) {
        Write-Host '.env pehle se maujood hai - usi DATABASE_URL ko reuse karenge.' -ForegroundColor Green
        # Database sach mein jawab deta hai ya nahi, check kar lein
        # (yahan ErrorActionPreference thodi dair Continue hai - PS 5.1
        #  mein native command ki stderr redirection warna script gira
        #  sakti hai):
        $prevEAP = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        & $psql $dbUrl -t -A -c 'SELECT 1' 2>$null | Out-Null
        $psqlCheckCode = $LASTEXITCODE
        $ErrorActionPreference = $prevEAP
        if ($psqlCheckCode -ne 0) {
            throw '.env wala database connect nahi ho raha. PostgreSQL service check karein, ya .env delete karke script dobara chalain (naya password set ho jayega).'
        }
        Write-Host 'Database connection OK hai.' -ForegroundColor Green
    } else {
        Write-Host ''
        Write-Host '--- Database banana ---' -ForegroundColor Cyan
        if (-not $script:PgSuperPassword) {
            # Ye sirf tab ho sakta hai jab cluster pehle se bana ho
            # lekin .env gayab ho - script khud password nahi bana
            # sakta kyunke purana password use maloom nahi.
            throw 'Database pehle se bana hua lagta hai lekin us ki setting wali file (.env) gayab hai - aage barhne ke liye madad chahiye. Ye screen / install-log ki tafseel bhejein.'
        }
        $env:PGPASSWORD = $script:PgSuperPassword

        # App ke database user ka password bhi script KHUD banata hai -
        # operator ko kuch type nahi karna, yaad nahi rakhna. Password
        # sirf .env mein rehta hai (neeche us file ki permissions bhi
        # band kar di jati hain).
        $appPassword = New-RandomPassword

        # Role (user) - hai to password update, nahi to naya:
        $sqlPass = $appPassword.Replace("'", "''")
        $roleExists = & $psql -U postgres -h $DbHost -p $DbPort -t -A -c "SELECT 1 FROM pg_roles WHERE rolname = '$DbUser'"
        if ($LASTEXITCODE -ne 0) { throw 'postgres superuser se connect nahi hua - PostgreSQL service / cluster check karein.' }
        if ($roleExists -match '1') {
            & $psql -U postgres -h $DbHost -p $DbPort -c "ALTER USER $DbUser WITH PASSWORD '$sqlPass'" | Out-Null
            Write-Host ("DB user '{0}' pehle se tha - password naye par set kar diya." -f $DbUser) -ForegroundColor Yellow
        } else {
            & $psql -U postgres -h $DbHost -p $DbPort -c "CREATE USER $DbUser WITH PASSWORD '$sqlPass'" | Out-Null
            Write-Host ("DB user '{0}' ban gaya." -f $DbUser) -ForegroundColor Green
        }

        # Database - hai to theek, nahi to naya:
        $dbExists = & $psql -U postgres -h $DbHost -p $DbPort -t -A -c "SELECT 1 FROM pg_database WHERE datname = '$DbName'"
        if ($dbExists -match '1') {
            & $psql -U postgres -h $DbHost -p $DbPort -c "ALTER DATABASE $DbName OWNER TO $DbUser" | Out-Null
            Write-Host ("Database '{0}' pehle se hai - owner set kar diya." -f $DbName)
        } else {
            & $psql -U postgres -h $DbHost -p $DbPort -c "CREATE DATABASE $DbName OWNER $DbUser" | Out-Null
            Write-Host ("Database '{0}' ban gaya." -f $DbName) -ForegroundColor Green
        }
        Remove-Item Env:\PGPASSWORD -ErrorAction SilentlyContinue

        # Connection string ke liye password ko URL-encode karna zaroori
        # hai (special characters tootein ge warna):
        $encoded = [System.Uri]::EscapeDataString($appPassword)
        $dbUrl = "postgres://${DbUser}:${encoded}@${DbHost}:${DbPort}/${DbName}"
        $appPassword = $null

        $envLines = @(
            '# Canteen POS - production settings (02-setup-server.ps1 ne banaya)',
            '# Is file ko kisi ke sath share NA karein - is mein database ke passwords hain.',
            "DATABASE_URL=$dbUrl",
            "PGDATA=$PgData",
            "BACKUP_DIR=$BackupDir",
            "PG_SUPERUSER_PASSWORD=$($script:PgSuperPassword)",
            '# COOKIE_SECURE=1          # sirf tab on karein jab HTTPS (Cloudflare Tunnel) live ho',
            '# PUBLIC_ORDER_BASE_URL=https://order.example.com   # table-QR cards ke liye, tunnel ke baad'
        )
        [IO.File]::WriteAllLines($envFile, $envLines)

        # .env ki hifazat: sirf SYSTEM, Administrators aur ye account:
        $me = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        & icacls $envFile /inheritance:r /grant:r 'SYSTEM:F' 'Administrators:F' ("{0}:F" -f $me) | Out-Null
        Write-Host '.env ban gaya aur us ki permissions band kar di hain.' -ForegroundColor Green
        Write-Host 'Database ke passwords script ne khud bana kar .env mein mehfooz kar diye hain - kisi ko yaad rakhne ki zaroorat nahi.' -ForegroundColor Green
    }

    # --- 5. Dependencies + build ----------------------------------------
    Set-Location $AppDir
    $env:DATABASE_URL = $dbUrl
    Write-Host ''
    Write-Host '--- npm install (pehli dafa waqt lagega) ---' -ForegroundColor Cyan
    if (Test-Path (Join-Path $AppDir 'package-lock.json')) {
        & npm.cmd ci
    } else {
        & npm.cmd install
    }
    if ($LASTEXITCODE -ne 0) { throw 'npm install fail hua.' }

    Write-Host '--- npm run build ---' -ForegroundColor Cyan
    & npm.cmd run build
    if ($LASTEXITCODE -ne 0) { throw 'npm run build fail hua.' }

    # --- 6. Database schema + seed (app ke apne scripts) -----------------
    Write-Host '--- npm run db:setup (migrate + seed) ---' -ForegroundColor Cyan
    & npm.cmd run db:setup
    if ($LASTEXITCODE -ne 0) { throw 'db:setup fail hua - upar wali error dekhein.' }
    Write-Host 'Database schema + seed complete.' -ForegroundColor Green

    # --- 7. Helper files C:\CanteenPOS mein copy --------------------------
    foreach ($helper in @('run-server.ps1', '04-daily-backup.ps1', 'start-server.bat', 'stop-server.bat')) {
        $srcHelper = Join-Path $PSScriptRoot $helper
        if (Test-Path $srcHelper) { Copy-Item $srcHelper -Destination (Join-Path $Root $helper) -Force }
    }
    Write-Host 'Helper files (run-server / start / stop / backup) C:\CanteenPOS mein aa gaye.'

    # --- 8. Smoke test: server chala kar port check -----------------------
    Write-Host ''
    Write-Host ("--- Smoke test: server port {0} par ---" -f $Port) -ForegroundColor Cyan
    $launcher = Join-Path $Root 'run-server.ps1'
    $proc = Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$launcher`"" -PassThru -WindowStyle Hidden
    $ok = $false
    for ($i = 1; $i -le 45; $i++) {
        Start-Sleep -Seconds 2
        try {
            $resp = Invoke-WebRequest -Uri ("http://127.0.0.1:{0}/" -f $Port) -UseBasicParsing -TimeoutSec 3
            if ($resp.StatusCode -ge 200) { $ok = $true; break }
        } catch {
            if ($_.Exception.Response) { $ok = $true; break }  # koi bhi HTTP jawab = server zinda hai
        }
        if ($proc.HasExited) { break }
    }
    # Test server band karna (cleanup fail ho to bhi result na giraye):
    $prevEAP = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $listener = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($listener) { & taskkill /PID $listener.OwningProcess /T /F 2>$null | Out-Null }
    if (-not $proc.HasExited) { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue }
    $ErrorActionPreference = $prevEAP

    if ($ok) {
        Write-Host ("SMOKE TEST PASS - server http://127.0.0.1:{0} par jawab de raha hai." -f $Port) -ForegroundColor Green
    } else {
        throw ("Smoke test fail - server port {0} par nahi aya. Log dekhein: {1}" -f $Port, (Join-Path $LogDir 'server.log'))
    }

    Write-Host ''
    Write-Host 'STEP 2 COMPLETE. Ab 03-autostart-and-power.ps1 chalain.' -ForegroundColor Green
    Write-Host 'Phir PC restart karke dekhein ke server khud start hota hai ya nahi.'
}
catch {
    $failed = $true
    Write-Host ''
    Write-Host ("ERROR: {0}" -f $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Masla hal karke script dobara chalain - dobara chalana safe hai.'
}
Write-Host ''
if ($env:CANTEENPOS_AUTO -ne '1') { Read-Host 'Band karne ke liye Enter dabain' }
if ($failed) { exit 1 }
