@echo off
REM ============================================================
REM  Apni Dukaan - Server Launcher (run-server.cmd)
REM  Scheduled Task (PC on / logon par) aur start-server.bat
REM  isi ko chalate hain. Ye file 03-autostart-and-power.ps1
REM  ke zariye C:\CanteenPOS\run-server.cmd mein banti hai -
REM  wahan __NODE_EXE__ ki jagah node ka pura rasta likh diya
REM  jata hai. Agar wo rasta kabhi na mile to launcher khud
REM  bhi node dhoondhne ki koshish karta hai.
REM  Kaam ka tareeqa:
REM    1) PostgreSQL service band ho to chala deta hai
REM    2) .env ki settings parh leta hai
REM    3) Node se seedha server chalata hai - koi .cmd shim
REM       nahi, PATH par inhisaar khatam
REM    4) Port 3100 tayyar honay ka intezar karta hai, aur
REM       jab tak server chalta rahe nazar rakhta hai;
REM       server band ho to exit 1 - taake Scheduled Task
REM       use dobara chala sake.
REM  Saari output is file mein: C:\CanteenPOS\server-log.txt
REM ============================================================
if "%~1"=="__serve" goto serve

setlocal EnableExtensions
set "ROOT=C:\CanteenPOS"
set "APPDIR=%ROOT%\app"
set "LOG=%ROOT%\server-log.txt"
set "NODE=__NODE_EXE__"
set "PORT=3100"

echo. >> "%LOG%"
echo [%date% %time%] ===== Launcher start ===== >> "%LOG%"

REM --- Node ka rasta pakka karein ------------------------------
if exist "%NODE%" goto nodeok
set "NODE="
for /f "delims=" %%i in ('where node 2^>nul') do if not defined NODE set "NODE=%%i"
if not defined NODE if exist "C:\Program Files\nodejs\node.exe" set "NODE=C:\Program Files\nodejs\node.exe"
if not defined NODE if exist "C:\Program Files (x86)\nodejs\node.exe" set "NODE=C:\Program Files (x86)\nodejs\node.exe"
if not defined NODE (
  echo [%date% %time%] ERROR: node.exe nahi mila - server start nahi ho sakta >> "%LOG%"
  echo Node.js nahi mila. Tafseel: %LOG%
  exit /b 1
)
:nodeok
echo [%date% %time%] Node: %NODE% >> "%LOG%"

REM --- .env lazmi hai -------------------------------------------
if exist "%APPDIR%\.env" goto envok
echo [%date% %time%] ERROR: .env nahi mila - %APPDIR%\.env - pehle INSTALL.bat chalain >> "%LOG%"
echo .env nahi mila. Tafseel: %LOG%
exit /b 1
:envok
for /f "usebackq eol=# tokens=1,* delims==" %%a in ("%APPDIR%\.env") do if not "%%a"=="" set "%%a=%%b"

REM --- FIXED-12: data folder ghayab ho to log mein saaf entry -----
if defined PGDATA if not exist "%PGDATA%\PG_VERSION" (
  echo [%date% %time%] ================================================== >> "%LOG%"
  echo [%date% %time%] DATA FOLDER NAHI MILA: %PGDATA% >> "%LOG%"
  echo [%date% %time%] DATA FOLDER NAHI MILA - database folder delete ya move ho gaya lagta hai. Backup se bahaali ke liye rabta karein - RESTORE-DATA chala kar hisaab wapas aa sakta hai. >> "%LOG%"
  echo [%date% %time%] ================================================== >> "%LOG%"
)

REM --- PostgreSQL service: band ho to chalayein -----------------
echo [%date% %time%] PostgreSQL service check ho raha hai... >> "%LOG%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-Service | Where-Object { $_.Name -like 'postgresql*' } | ForEach-Object { if ($_.Status -ne 'Running') { Start-Service -Name $_.Name -ErrorAction SilentlyContinue } }" >> "%LOG%" 2>&1
set /a pgtries=0
:pgwait
powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Get-Service | Where-Object { $_.Name -like 'postgresql*' -and $_.Status -eq 'Running' }) { exit 0 } else { exit 1 }"
if not errorlevel 1 goto pgok
set /a pgtries+=1
if %pgtries% geq 15 goto pgskip
ping -n 3 127.0.0.1 >nul
goto pgwait
:pgskip
echo [%date% %time%] WARNING: PostgreSQL service Running nahi hua - phir bhi server start kar rahe hain >> "%LOG%"
:pgok

REM --- Server pehle se chal raha ho to dobara start nahi --------
powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }"
if errorlevel 1 goto startserver
echo [%date% %time%] Server pehle se chal raha hai - port %PORT% - dobara start nahi kiya >> "%LOG%"
echo Server pehle se chal raha hai: http://localhost:%PORT%
exit /b 0
:startserver

REM --- Server chalana - asal process alag hisay mein ------------
echo [%date% %time%] Server start ho raha hai - port %PORT% >> "%LOG%"
echo Server start ho raha hai - intezar karein...
start "" /b "%~f0" __serve

REM --- Port tayyar honay ka intezar - takreeban 60 second -------
set /a tries=0
:waitport
powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }"
if not errorlevel 1 goto portup
set /a tries+=1
if %tries% geq 30 goto portfail
ping -n 3 127.0.0.1 >nul
goto waitport
:portfail
echo [%date% %time%] ERROR: Server 60 second mein port %PORT% par nahi aya >> "%LOG%"
echo Server start nahi hua. Tafseel is file mein hai: %LOG%
exit /b 1
:portup
echo [%date% %time%] Server TAYYAR hai - port %PORT% >> "%LOG%"
echo Server TAYYAR hai: http://localhost:%PORT%
echo Is amal ko band karne se server band ho jayega - auto-start wali task dobara chala degi.

REM --- Nazar rakhna: server band ho to exit 1 --------------------
REM --- taake Scheduled Task 1 minute baad dobara chala sake ------
:monitor
ping -n 11 127.0.0.1 >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }"
if errorlevel 1 (
  echo [%date% %time%] Server band ho gaya - launcher band ho raha hai >> "%LOG%"
  exit /b 1
)
goto monitor

REM ============================================================
:serve
if not defined APPDIR set "APPDIR=C:\CanteenPOS\app"
if not defined LOG set "LOG=C:\CanteenPOS\server-log.txt"
if not defined PORT set "PORT=3100"
if not defined NODE set "NODE=node"
cd /d "%APPDIR%"
"%NODE%" "%APPDIR%\node_modules\next\dist\bin\next" start -p %PORT% -H 0.0.0.0 >> "%LOG%" 2>&1
echo [%date% %time%] Server process band ho gaya - exit code %errorlevel% >> "%LOG%"
exit /b
