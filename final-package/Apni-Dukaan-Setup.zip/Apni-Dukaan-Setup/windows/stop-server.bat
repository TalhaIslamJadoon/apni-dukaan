@echo off
REM ============================================================
REM  Canteen POS - Server STOP (staff ke liye, double-click)
REM  Port 3100 par jo server chal raha hai use band karta hai.
REM  NOTE: PC dobara on hone par server khud start ho jayega
REM  (Scheduled Task) - ye sirf abhi ke liye band karta hai.
REM  Roz raat ko is ki zaroorat NAHI - bas PC shutdown kar dein.
REM ============================================================
setlocal
set PORT=3100
title Apni Dukaan - Server Stop

echo.
echo  Canteen POS server band ho raha hai (port %PORT%)...

powershell -NoProfile -Command "$pids = Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique; if ($pids) { foreach ($p in $pids) { & taskkill /PID $p /T /F | Out-Null }; exit 0 } else { exit 1 }"
if %errorlevel%==0 (
    echo  Server BAND ho gaya.
) else (
    echo  Server pehle se band tha - kuch band karne ko nahi mila.
)

echo.
pause
endlocal
