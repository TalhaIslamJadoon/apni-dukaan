# =====================================================================
#  Apni Dukaan - Data Wapas Layein (05-restore-backup.ps1)  [FIXED-12]
#  Backup se purana hisaab wapas lana - owner ke liye asaan tareeqa.
#  RESTORE-DATA.bat is ko chalata hai (admin ban kar).
#    1) Backups ki list tareekh ke sath - number chunein
#    2) Pakka karne ka sawal (plain alfaaz mein)
#    3) Pehle MAUJOODA data ka naya backup (pre-restore-...) -
#       restore pasand na aye to wahi se wapas bhi aa sakte hain
#    4) Server band, database khali karke backup bhar dein
#    5) Sab dobara chala kar test - jawab aye to kamyabi
#  Tafseel C:\CanteenPOS\restore-log.txt mein likhi jati hai.
#  Linux par authored - Windows par untested (pehli asal koshish
#  Talha ke PC par hogi; har step fail-safe hai).
# =====================================================================

$ErrorActionPreference = 'Continue'

$Root    = 'C:\CanteenPOS'
$AppDir  = Join-Path $Root 'app'
$EnvFile = Join-Path $AppDir '.env'
$LogFile = Join-Path $Root 'restore-log.txt'
$Port    = 3100

function Log-Line([string]$Text) {
    $line = '{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Text
    try { Add-Content -Path $LogFile -Value $line -Encoding UTF8 } catch { }
    Write-Host $Text
}

function Read-EnvValue2([string]$Key) {
    if (-not (Test-Path $EnvFile)) { return $null }
    foreach ($raw in Get-Content $EnvFile) {
        if ($raw -match ("^\s*" + [regex]::Escape($Key) + "\s*=\s*(.+)$")) { return $Matches[1].Trim() }
    }
    return $null
}

function Find-PgTool([string]$Name) {
    $base = 'C:\Program Files\PostgreSQL'
    if (Test-Path $base) {
        $dirs = Get-ChildItem $base -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending
        foreach ($d in $dirs) {
            $candidate = Join-Path $d.FullName ("bin\{0}" -f $Name)
            if (Test-Path $candidate) { return $candidate }
        }
    }
    $cmd = Get-Command $Name -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

try {
    Write-Host ''
    Write-Host '============================================================'
    Write-Host '  DATA WAPAS LAYEIN - backup se purana hisaab'
    Write-Host '============================================================'
    Log-Line 'Restore shuru.'

    if (-not (Test-Path $EnvFile)) { throw '.env nahi mila - pehle INSTALL.bat chalain.' }
    $dbUrl    = Read-EnvValue2 'DATABASE_URL'
    $backupDir = Read-EnvValue2 'BACKUP_DIR'
    $superPw  = Read-EnvValue2 'PG_SUPERUSER_PASSWORD'
    if (-not $dbUrl) { throw '.env mein DATABASE_URL nahi mila.' }
    if (-not $superPw) { throw '.env mein database ka master password nahi mila - restore nahi ho sakta.' }
    if (-not $backupDir) { throw '.env mein BACKUP_DIR nahi mila.' }
    if (-not (Test-Path $backupDir)) { throw ("Backup folder nahi mila: {0}" -f $backupDir) }

    # DATABASE_URL tor kar host/port/user/db nikalein:
    $m = [regex]::Match($dbUrl, '^postgres(?:ql)?://([^:]+):(.+)@([^:/]+):(\d+)/([^?]+)')
    if (-not $m.Success) { throw 'DATABASE_URL samajh nahi aya.' }
    $dbUser = [Uri]::UnescapeDataString($m.Groups[1].Value)
    $dbHost = $m.Groups[3].Value
    $dbPort = $m.Groups[4].Value
    $dbName = $m.Groups[5].Value

    $psql      = Find-PgTool 'psql.exe'
    $pgDump    = Find-PgTool 'pg_dump.exe'
    $pgRestore = Find-PgTool 'pg_restore.exe'
    if (-not $psql -or -not $pgDump -or -not $pgRestore) { throw 'PostgreSQL ke tools nahi mile - install check karein.' }

    # --- Backups ki list (naye pehle) --------------------------------
    $files = @(Get-ChildItem $backupDir -Filter '*.dump' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    if ($files.Count -eq 0) { throw ("Backups folder mein koi backup file nahi hai: {0}" -f $backupDir) }
    Write-Host ''
    Write-Host 'Ye backups mile hain (naya sab se upar):'
    for ($i = 0; $i -lt $files.Count; $i++) {
        $f = $files[$i]
        Write-Host ("  [{0}] {1}  -  {2:N1} MB" -f ($i + 1), $f.LastWriteTime.ToString('dd MMM yyyy, hh:mm tt'), ($f.Length / 1MB))
    }
    Write-Host ''
    $pick = Read-Host 'Kaun sa backup wapas layein? Number dabayein (band karne ke liye khali chhorein)'
    if (-not "$pick".Trim()) { Log-Line 'Restore band - koi number nahi chuna.'; return }
    $idx = 0
    if (-not [int]::TryParse("$pick".Trim(), [ref]$idx) -or $idx -lt 1 -or $idx -gt $files.Count) {
        throw 'Number theek nahi - restore band.'
    }
    $chosen = $files[$idx - 1]
    Write-Host ''
    Write-Host ("Chuna gaya backup: {0} ({1})" -f $chosen.Name, $chosen.LastWriteTime.ToString('dd MMM yyyy, hh:mm tt'))
    Write-Host 'Purana hisaab is backup se wapas ajayega - is ke BAAD ka data khatam ho jayega.'
    $confirm = Read-Host 'Pakka? [Y/N]'
    if ("$confirm".Trim().ToUpper() -ne 'Y') { Log-Line 'Restore band - owner ne pakka nahi kiya.'; return }

    # --- Pehle maujooda data ka taza backup (safety) ------------------
    $stamp = Get-Date -Format 'yyyy-MM-dd_HHmm'
    $preFile = Join-Path $backupDir ("pre-restore-{0}.dump" -f $stamp)
    Log-Line ("Pehle maujooda data ka backup ban raha hai: {0}" -f (Split-Path $preFile -Leaf))
    & $pgDump -Fc -f $preFile $dbUrl
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $preFile) -or (Get-Item $preFile).Length -le 0) {
        throw 'Maujooda data ka safety backup nahi bana - restore ROK diya hai (data mehfooz rahe).'
    }
    Log-Line 'Safety backup ban gaya.'

    # --- App server band ----------------------------------------------
    try { Stop-ScheduledTask -TaskName 'CanteenPOS Server' -ErrorAction SilentlyContinue } catch { }
    try {
        $procs = Get-CimInstance Win32_Process -Filter "Name = 'node.exe'" -ErrorAction SilentlyContinue |
            Where-Object { $_.CommandLine -and ($_.CommandLine -like '*CanteenPOS*') }
        foreach ($p in $procs) { Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue }
    } catch { }

    # --- Database khali karke backup bhar dein -------------------------
    $env:PGPASSWORD = $superPw
    Log-Line 'Database dobara ban raha hai...'
    & $psql -U postgres -h $dbHost -p $dbPort -v ON_ERROR_STOP=1 -c ("DROP DATABASE IF EXISTS ""{0}"" WITH (FORCE)" -f $dbName) | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Purana database khatam nahi hua.' }
    & $psql -U postgres -h $dbHost -p $dbPort -v ON_ERROR_STOP=1 -c ("CREATE DATABASE ""{0}"" OWNER ""{1}""" -f $dbName, $dbUser) | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Naya database nahi bana.' }
    Log-Line 'Backup bhar raha hai - thoda intezar karein...'
    & $pgRestore -U postgres -h $dbHost -p $dbPort -d $dbName --no-owner $chosen.FullName | Out-Null
    Remove-Item Env:\PGPASSWORD -ErrorAction SilentlyContinue

    # --- Tasdeeq: test query -------------------------------------------
    $tables = & $psql $dbUrl -t -A -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public'"
    $tableCount = 0
    [int]::TryParse("$tables".Trim(), [ref]$tableCount) | Out-Null
    if ($LASTEXITCODE -ne 0 -or $tableCount -lt 5) { throw 'Restore ke baad database khali lag raha hai - tasdeeq fail.' }
    Log-Line ("Restore ho gaya - {0} tables mile." -f $tableCount)

    # --- Services dobara ------------------------------------------------
    try {
        $svc = Get-Service | Where-Object { $_.Name -like 'postgresql*' } | Select-Object -First 1
        if ($svc -and $svc.Status -ne 'Running') { Start-Service -Name $svc.Name -ErrorAction SilentlyContinue }
    } catch { }
    try { Start-ScheduledTask -TaskName 'CanteenPOS Server' -ErrorAction SilentlyContinue } catch { }
    $portOk = $false
    for ($i = 1; $i -le 30; $i++) {
        Start-Sleep -Seconds 2
        if (Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue) { $portOk = $true; break }
    }
    if (-not $portOk) {
        Log-Line 'NOTE: Restore ho gaya hai lekin server abhi port par nahi aya - PC restart kar dein, server khud chal jayega.'
    }
    Write-Host ''
    Write-Host '============================================================'
    Write-Host '  HISAAB WAPAS AA GAYA HAI'
    Write-Host ("  Backup: {0}" -f $chosen.Name)
    Write-Host ("  Agar ye pasand na aye to aaj wala data is naam se")
    Write-Host ("  mehfooz hai: {0}" -f (Split-Path $preFile -Leaf))
    Write-Host '  Usi ko chunein aur restore dobara kar dein.'
    Write-Host '============================================================'
    Log-Line 'Restore kamyab.'
}
catch {
    Log-Line ("Restore FAIL: {0}" -f $_.Exception.Message)
    Write-Host ''
    Write-Host '============================================================'
    Write-Host '  Restore nahi ho saka.'
    Write-Host ("  Wajah: {0}" -f $_.Exception.Message)
    Write-Host ("  Tafseel is file mein hai: {0}" -f $LogFile)
    Write-Host '  Aap ka maujooda data waisa hi hai - kuch delete nahi hua.'
    Write-Host '============================================================'
    # Server band kiya ho to dobara chala dein:
    try { Start-ScheduledTask -TaskName 'CanteenPOS Server' -ErrorAction SilentlyContinue } catch { }
}
