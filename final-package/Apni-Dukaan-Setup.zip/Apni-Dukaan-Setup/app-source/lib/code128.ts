// ─────────────────────────────────────────────────────────────────────────────
// Code 128 barcode encoder (subset B) — pure local code, no library, no CDN.
// Used by the Dashboard barcode-label printer: grocery products get a
// REAL scannable barcode (their `barcode` value, or SKU when none) printed
// on 50mm × 30mm stickers.
//
// Returns the run widths (bar, space, bar, space…) of the full symbol:
// Start B → data chars (ASCII 32–126 → value = code − 32) → checksum → Stop.
// PATTERNS[i] is the standard Code 128 width sequence for symbol value i
// (6 runs; the stop symbol has 7).
// ─────────────────────────────────────────────────────────────────────────────

const PATTERNS = [
  "212222", "222122", "222221", "121223", "121322", "131222", "122213", "122312", "132212", "221213",
  "221312", "231212", "112232", "122132", "122231", "113222", "123122", "123221", "223211", "221132",
  "221231", "213212", "223112", "312131", "311222", "321122", "321221", "312212", "322112", "322211",
  "212123", "212321", "232121", "111323", "131123", "131321", "112313", "132113", "132311", "211313",
  "231113", "231311", "112133", "112331", "132131", "113123", "113321", "133121", "313121", "211331",
  "231131", "213113", "213311", "213131", "311123", "311321", "331121", "312113", "312311", "332111",
  "314111", "221411", "431111", "111224", "111422", "121124", "121421", "141122", "141221", "112214",
  "112412", "122114", "122411", "142112", "142211", "241211", "221114", "413111", "241112", "134111",
  "111242", "121142", "121241", "114212", "124112", "124211", "411212", "421112", "421211", "212141",
  "214121", "412121", "111143", "111341", "131141", "114113", "114311", "411113", "411311", "113141",
  "114131", "311141", "411131", "211412", "211214", "211232", "2331112",
];

const START_B = 104;
const STOP = 106;

/** Full symbol as alternating bar/space run widths (starts with a bar). */
export function code128Widths(text: string): number[] {
  const values: number[] = [];
  for (const ch of text) {
    const c = ch.charCodeAt(0);
    values.push(c >= 32 && c <= 126 ? c - 32 : 0); // non-printable → space value
  }
  let checksum = START_B;
  values.forEach((v, i) => { checksum += v * (i + 1); });
  const codes = [START_B, ...values, checksum % 103, STOP];
  const widths: number[] = [];
  for (const code of codes) for (const d of PATTERNS[code]) widths.push(Number(d));
  return widths;
}
