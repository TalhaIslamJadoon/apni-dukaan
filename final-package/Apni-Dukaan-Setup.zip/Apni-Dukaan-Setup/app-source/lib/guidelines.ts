export type GuidelineKey =
  | "canteen"
  | "grocery"
  | "rentals"
  | "kitchen"
  | "qr-orders"
  | "stock"
  | "online"
  | "owner-overview"
  | "owner-menu"
  | "owner-grocery"
  | "owner-udhaar"
  | "owner-customers"
  | "owner-dayclose"
  | "owner-suppliers"
  | "owner-reports"
  | "owner-heads"
  | "owner-labels"
  | "owner-staff"
  | "owner-settings"
  | "owner-devices"
  | "owner-tables"
  | "owner-pnl"
  | "owner-lucky"
  | "owner-feedback"
  | "owner-setup";

export interface GuidelineEntry {
  title: string;
  steps: string[];
  tips?: string[];
}

export const GUIDELINE_KEYS: GuidelineKey[] = [
  "canteen",
  "grocery",
  "rentals",
  "kitchen",
  "qr-orders",
  "stock",
  "online",
  "owner-overview",
  "owner-menu",
  "owner-grocery",
  "owner-udhaar",
  "owner-customers",
  "owner-dayclose",
  "owner-suppliers",
  "owner-reports",
  "owner-heads",
  "owner-labels",
  "owner-staff",
  "owner-settings",
  "owner-devices",
  "owner-tables",
  "owner-pnl",
  "owner-lucky",
  "owner-feedback",
  "owner-setup",
];

export const GUIDELINES: Record<GuidelineKey, GuidelineEntry> = {
  canteen: {
    title: "🍽️ Canteen POS — Bill Banana",
    steps: [
      "⭐ Loyalty Points: customer select ho to neeche us ke points dikhte hain — 'Points istemal karein' on karein to points ki raqam (Settings wala hisaab, default 1 point = Rs 1) bill se kam ho jati hai, bill total se zyada nahi. Bill mukammal hone par naye points khud jud jate hain aur receipt par is bill ke points + kul balance print hota hai. Rentals par points NAHI bante.",
      "Apne naam wale card aur PIN se login karein; upar Canteen POS tab khula rakhein.",
      "Pehle Category chip chunein, phir item ki tile dabayein — item Current Bill mein add ho jayega.",
      "Quantity tile par ya bill line mein − / + se badlein; ek line hatani ho to ✕ aur poora bill saaf karna ho to Clear dabayein.",
      "Payment se pehle items, Subtotal aur GRAND TOTAL customer ke samne check karein.",
      "PAY / Charge dabayein; agar discount dena hai to Payment window mein Rs ya % chunein aur value likhein.",
      "👤 Customer Record (ikhtiyari): Payment window mein customer ka naam ya mobile likhein — purana customer ho to neeche us ka record aa jayega, select kar lein. Us ki Special Discount % lagi ho to discount KHUD lag jata hai (is ek bill ke liye badal bhi sakte hain). Naya mobile likha ho to bill ke sath us ka record ban jata hai — koi account nahi banta.",
      "Number pehle se kisi aur naam par registered ho to system rok kar batayega — wohi purana customer lagayein, duplicate record nahi banta.",
      "Cash mein + Rs 100 / 500 / 1000 ya Exact dabayein aur Change (Baqaya) bata dein; JazzCash ya Easypaisa mein payment milne ki tasdeeq ke baad aage barhein.",
      "Udhaar ho to Customer / Student / Staff name (khata) lazmi likhein — baghair naam ke Complete nahi hoga.",
      "✓ Complete — Get Token dabayein; customer ko Token Number batayein, chahein to Print Bill (80mm) karein, phir + New Order se agla bill shuru karein.",
    ],
    tips: [
      "Dhyaan dein: upar Sound ON rakhein taake online order ki awaaz aur banner miss na ho.",
      "⏳ Payment tasdeeq baqi wala order Kitchen nahi jata; Owner ke confirm karne ke baad hi token banta hai.",
    ],
  },

  grocery: {
    title: "🛒 Sell — Counter Sale",
    steps: [
      "⭐ Loyalty Points: customer select ho to neeche us ke points dikhte hain — 'Points istemal karein' on karein to points ki raqam (Settings wala hisaab, default 1 point = Rs 1) bill se kam ho jati hai, bill total se zyada nahi. Bill mukammal hone par naye points khud jud jate hain aur receipt par is bill ke points + kul balance print hota hai. Rentals par points NAHI bante.",
      "Apne naam aur PIN se login karein; scan box par focus rehne dein, taake scanner ki entry seedha bill mein jaye.",
      "Bill shuru karne se pehle Current Bill ke Bill Price Type mein 🏷️ Retail ya 📦 Wholesale chunein — prices isi ke hisaab se badalti hain.",
      "Barcode scanner se scan karke Enter karein; packed item barcode se aur loose item SKU/PLU code ya tile se add karein. Camera ho to 📷 Camera Scan bhi use kar sakte hain.",
      "Search, Main Head aur Sub-Head chips se product dhoondein; tile dabane se item bill mein aayega.",
      "Flavour/packing wale product par pehle variant (flavour) chunein, phir packing (size); chooser ya bill line mein − / + se quantity set karein aur ✓ Ho gaya — Bill dekhein dabayein.",
      "Per-kg item 0.5 kg steps mein add hota hai; bill line ke − / + se 0.5, 1.0 ya 1.5 kg waghera theek karein.",
      "🌐 Online Orders — Packing Queue aye to pehle 📦 Start Packing, samaan tayyar hone par ✓ Ready for Pickup dabayein; ye orders Kitchen nahi jate.",
      "👤 Customer Record (ikhtiyari): Payment window mein customer ka naam ya mobile likhte hi purane customers neeche aa jate hain — select kar lein to bill usi record se jud jata hai. Permanent customer ki Special Discount % lagi ho to wo KHUD bill par lag jati hai (cashier is ek bill ke liye badal/saaf kar sakta hai — saved % nahi badalta). Naya mobile ho to bill ke sath naya record ban jata hai; baghair mobile ke koi record nahi banta.",
      "Number pehle se kisi aur naam par registered ho to Complete par dialogue ayega — wohi purana customer lagayein; ek number ka ek hi record rehta hai.",
      "Bill par customer ka naam+mobile print hota hai, aur neeche us ke Kul Bills aur Kul Khareed bhi — customer ko apna record dikhta hai.",
      "PAY / Charge dabayein, zaroorat ho to Discount likhein, phir Cash, JazzCash, Easypaisa ya Udhaar chunein; Udhaar par customer name (khata) lazmi hai.",
      "✓ Complete Sale dabayein; Print Bill (80mm) ya + New Sale chunein. Sale complete hote hi stock khud kam ho jata hai.",
    ],
    tips: [
      "Dhyaan dein: Wholesale line par red minimum warning aye to pehle quantity poori karein — warning ke sath bill complete nahi hoga.",
      "Unknown code par red Item not found aye to code dobara check karein; search se product dhoond kar hi bill mein add karein.",
    ],
  },

  rentals: {
    title: "👰 Kiraya / Rentals — Dress Rent Par Dena",
    steps: [
      "Apne naam aur PIN se login karein; 👰 Kiraya / Rentals tab kholein. Ye tab sirf tab dikhta hai jab rental wala kaam ON ho (Kapron ki Dukaan setup, ya Owner Settings ka toggle).",
      "Nayi booking: ➕ Nayi Booking dabayein, pehle AVAILABLE dress chunein — booked/bahar gayi dress par nayi booking nahi banti.",
      "Customer ka NAAM aur MOBILE lazmi likhein (baghair mobile booking save nahi hoti); CNIC ho to likh dein, na ho to khali chalega. Naam/mobile likhte hi purane customers neeche aa jate hain — select karne se booking usi customer record se jud jati hai jo bills par banta hai (ek hi record poore system mein). Number pehle se kisi aur naam par ho to system rok kar batayega. NOTE: Special Discount % rentals par auto NAHI lagti — kiraya waisa hi rehta hai jo aap likhein.",
      "Lene ki tareekh aur Wapsi ki tareekh chunein — din aur kul kiraya (roz ka kiraya × din) khud ban jata hai; discount dena ho to kul kiraya khud badal sakte hain.",
      "Security deposit check karein aur select karein ke security kis par rakhi: Cash, CNIC ya Cheque. Advance jo mila woh likhein — baqaya khud nikal ayega.",
      "Booking save hote hi dress BOOKED ho jati hai aur booking slip (parchi) print kar sakte hain — customer ko lazmi dein.",
      "Customer dress lene aye to booking par 📦 Pickup dabayein aur baqaya wasool karke darj karein — dress BAHAR GAYI (Out) ho jayegi.",
      "Wapsi par ↩️ Wapsi dabayein: asal wapsi ki tareekh se late din aur jurmana (roz ka fine × late din) khud ajata hai; dress ki halat chunein — Theek, Damage (charges + note likhein) ya Dry-Clean Bhej Diya.",
      "Security ka hisaab screen par khud banta hai: jama security − (late fine + damage) = wapas ki gayi rakam. Charges deposit se zyada hon to woh rakam customer se wasool karke hi wapsi mukammal karein.",
      "Wapsi mukammal hote hi dress wapas AVAILABLE ho jati hai — Dry-Clean wali dress CLEANING mein jati hai; saaf ho kar aye to Dresses list se usey Available kar dein.",
      "Upar ke filters se dekhein: Aaj Wapsi Wale (aaj jin ki wapsi hai) aur 🔴 Late (jo dress waqt par wapas nahi ayi — woh laal numayan dikhti hai).",
    ],
    tips: [
      "Dhyaan dein: Security deposit AAMDANI nahi hai — woh amanat hai aur wapas hota hai. Aamdani sirf wasool shuda kiraya, late fine aur damage charges hain; yehi 📈 Profit & Loss aur Owner Overview mein ginte hain.",
      "Dress ki KHARID qeemat kiraye ki lagat mein nahi ginti — dress khareedi ho to us ki qeemat Dashboard → 📈 Profit & Loss → Kharchay mein alag se kharcha likhein.",
      "Nayi dress sirf Owner add/edit kar sakta hai (Dresses wale hisse mein); dress ka roz ka kiraya ya deposit badalne se purani bookings ka hisaab NAHI badalta — woh booking ke waqt wala hi rehta hai.",
      "Late fine ka roz ka rate Owner Settings se badalta hai (default Rs 500/din) — nayi bookings par naya rate, purani par purana snapshot.",
      "Har dress/item par CATEGORY (function) lazmi lagayein — Baraat, Walima, Mehndi, Dholki, Mayoun, Bridal, Groom, Party/Event, Kids — ya Sajawat / Decor, Lights, Sign Boards. Dress Board par har category ki alag slide banti hai (masalan 💍 Baraat Collection) aur Rentals screen par category chips se filter hota hai. Nayi category chahiye to item form mein ✏️ Nayi Category Likhein se apna naam bhi likh sakte hain.",
      "Jo cheez tadaad mein hai (string lights, sajawat dholki, sign boards) us ki KUL TADAAD item form ke Total Qty mein likhein. Booking utne hi piece ki bane gi jitne bache hon ge — card par Available X / Y saaf nazar ata hai, aur zyada qty ki booking system khud rok deta hai. Dresses aksar 1 hi piece hoti hain, un ka Total Qty 1 hi rakhein.",
      "Dress Board par dress GHUMTI hui dikhane ke liye: dress ki zyada tasveerein lagayein to board par ghumti hui nazar ayegi. Recipe — dress ko mannequin/stand par pehnayein, barabar roshni rakhein, phone ko ek hi doori par rakh kar aahista aahista gol ghoom kar 12–16 tasveerein lein — board par dress bilkul ghumta hua lagega. Photos Dresses wale hisse mein dress Edit karke lagti hain (max 16).",
    ],
  },

  kitchen: {
    title: "👨‍🍳 Kitchen — Tokens Tayyar Karna",
    steps: [
      "Apne naam aur PIN se login karein; Kitchen screen khuli rakhein — naye tokens khud aa jate hain.",
      "Naya order aane par awaaz/banner aye to pehle ✓ Dekh Liya dabayein, phir token card par items aur quantity dhyaan se parhein.",
      "Card ka source label check karein: 🏪 COUNTER, 🍽️ DINE-IN — TABLE, 🥡 TAKEAWAY ya 🌐 ONLINE; dine-in ka khana sahi table ke hisaab se alag rakhein.",
      "Khana banana shuru karte hi 🍳 Start Preparing dabayein, taake status PENDING se PREPARING ho jaye.",
      "Poora order tayyar ho jaye to bara ✓ READY button dabayein; sirf usi token ko Ready karein jo mukammal ho.",
      "Ready today wali list se token dobara check karke counter/table par bhejein.",
    ],
    tips: [
      "Dhyaan dein: Grocery orders Kitchen nahi aate — woh Sell ki packing queue mein jate hain.",
      "Payment proof pending online order yahan nazar nahi ayega; Owner confirm karega to token ke sath khud aa jayega.",
    ],
  },

  stock: {
    title: "📦 Inventory — Scan / Stock IN aur Wastage",
    steps: [
      "🚚 Supplier: Stock IN karte waqt supplier chunein ya naya naam likhein; KUL RAQAM aur ADA RAQAM likhne se supplier ke khate mein baqaya khud ban jata hai (hisaab Dashboard → Suppliers mein milta hai).",
      "🛒 Low-Stock Order List: jis cheez ka stock Settings wali limit (default 5) par ya us se neeche ho, woh is list mein ati hai — 🖨️ Order List print karke supplier ko de dein. System khud order NAHI bhejta.",
      "Apne naam aur PIN se login karein; pehle 🍽️ Canteen Stock ya 🛒 Grocery Stock chunein.",
      "Stock IN ke liye green ➕ Stock IN (kharid) chunein; Wastage ke liye red 🗑️ Wastage (zaya) chunein.",
      "SAB SE ASAAN TAREEQA — barcode scan: upar scan wala box khud focus mein rehta hai; scanner se product ya packing ka barcode scan karein, sahi item khud select ho jayega. Packing ka barcode scan ho to wahi variant/packing bhi sath select ho jati hai.",
      "Scanner na ho to Search box mein naam likh kar item chunein; Grocery mein barcode ya SKU likh kar Enter karne se bhi sahi item select ho jata hai.",
      "Item select hone ke baad mojooda stock check karein — ghalat item select ho to pehle sahi item par click karein.",
      "Stock IN mein QUANTITY aur PURCHASE RATE (Rs) lazmi bharein; SUPPLIER ho to likh dein, phir ➕ Stock IN — Save Entry dabayein.",
      "Wastage mein QUANTITY aur REASON (Expired, Damaged, Spilled ya Other) chunein, phir 🗑️ Wastage — Save Entry dabayein.",
      "Save ke baad green ✓ message aur right side Stock Entries — Recent mein apni entry zaroor check karein.",
      "Neeche 📋 Mojooda Stock mein LOW ya KHATAM items dekhein aur Owner ko bata dein; prices yahan badalne ki koshish na karein.",
      "Medical Store setup mein Stock IN karte waqt EXPIRY (mahina/saal) bhi bhar dein — upar ⏰ Expiry Qareeb wali list mein woh dawaiyan khud ayengi jin ki expiry 30 din ke andar hai ya guzar chuki hai.",
      "Medical expiry sirf WARNING hai — batch-wise hisaab (konsi batch ki dawai pehle biki) is version mein nahi hai; expiry ke qareeb wali dawai pehle nikaalna staff ki zimmedari hai.",
    ],
    tips: [
      "Dhyaan dein: Scan par '✕ Product nahi mila' aye to woh product system mein hai hi nahi — pehle Owner ko Dashboard se add karna hoga; stock wala banda naya product nahi bana sakta.",
      "Wastage mojooda stock se zyada nahi ho sakti; ghalat quantity save karne se pehle dobara gin lein. Selling price yahan sirf dikhti hai — rate ya product ki detail badalna Dashboard ka kaam hai.",
    ],
  },

  online: {
    title: "📱 Online Orders — Customer Guide",
    steps: [
      "Table par hon to table ka QR scan karein ya I am at a Table chunein; hostel/office se hon to Order Online — Hostel / Office chunein.",
      "Table flow mein apna Name, sahi Table Number aur Mobile Number (LAZMI) likhein, phir 🍽️ Dine-In ya 🥡 Takeaway chunein — is flow mein account nahi chahiye. Aap ka order isi mobile ke customer record mein judta hai.",
      "Remote order ke liye Login karein ya Create Account mein Full Name, Mobile Number, Password aur Place/Room ya Office detail bharein; mobile hi login hota hai.",
      "Ek order mein sirf ek shop chunein: Canteen Order ya Grocery Order. Doosri shop ke liye alag order karein.",
      "Items par ＋ Add to Cart dabayein aur − / + se quantity theek karein; neeche cart bar se Your Cart khol kar items aur TOTAL check karein.",
      "Table order mein sirf do payment options hain: 💵 Cash (counter par adaigi — pehle bill clear, phir takeaway pickup) ya 📱 Online Payment (pehle shop number par payment karke proof dein). Table par Udhaar NAHI milta — udhaar sirf counter par staff ki marzi se hota hai.",
      "Online Payment mein JazzCash, Easypaisa, Raast ya Bank chunein, payment karein, Transaction ID ho to likhein aur payment screenshot (proof) lazmi upload karein — baghair proof Place Order nahi chalega.",
      "✓ Place Order dabayein. Payment proof wale order par ⏳ Payment Tasdeeq Baqi ayega; shop confirm karegi to token aur status milega, reject ho to wajah ke sath My Orders se Dobara Proof Upload Karein.",
      "Status screen ya 📦 My Orders mein apna order dekhein; Ready hone par canteen ya grocery counter se pickup karein. Takeaway pickup se pehle bill clear hona lazmi hai.",
      "Agar payment wale hisay mein shop ka bara QR code dikh raha ho to number likhne ki zaroorat nahi: apne JazzCash / Easypaisa / banking app se usi QR ko scan karke payment karein — phir bhi neeche screenshot (proof) upload karna lazmi hai.",
    ],
    tips: [
      "Dhyaan dein: Agar 🛑 Abhi band hai wala popup aye to online order nahi hoga — screen par diye number par 📞 Call ya 💬 WhatsApp karein, ya 🔄 Dobara check karein dabayein.",
      "Remote order mein Cash option nahi hota; pehle payment aur proof, phir shop ki tasdeeq lazmi hai.",
    ],
  },

  "qr-orders": {
    title: "📱 QR Orders — Table Orders ki Screen",
    steps: [
      "Ye screen sirf TABLE-QR orders ki hai — remote online-account orders yahan nahi aate, wo Online Orders / Dashboard mein rehte hain.",
      "Har card par table number, token, customer ka naam + mobile, items, total aur payment ki halat dikhti hai: 💵 Cash — Counter par lena hai / ⏳ Online — Tasdeeq Baqi / ✅ Bill Clear.",
      "🧾 Bill button se receipt dekhein aur print karein. Online payment wale order par proof check karke ✅ Proof Confirm ya ❌ Reject karein — confirm se pehle order Kitchen nahi jata.",
      "💵 Cash Mila — Bill Clear: customer ne counter par cash de diya ho to is se bill clear karein.",
      "Waiter ne paisay liye hon to: 'Waiter ne customer se le liya' (bill clear, cash abhi waiter ke paas) ya '💵 Waiter Jama Karwaya' (bill clear + cash cashier ke paas bhi darj) — dono kaam COUNTER ki isi screen se hote hain, waiter ke paas mobile nahi hota.",
      "Upar 'Waiters ke paas cash' wali line mein har waiter ka baqi cash dikhta hai — raqam likh kar ✔ Jama Wasool Kar Liya dabayein (thori raqam bhi jama ho sakti hai).",
      "Serve gate: 🍽️ Dine-In serve khana tayyar hote hi ho jata hai (payment khana khanay ke baad). 🥡 Takeaway PICK sirf bill clear hone par — pehle '⚠️ Pehle bill clear karein' ayega.",
      "➕ Table Order Lein: counter se table order lagayein — Waiter chunein picker mein waiter ka naam chunein to order us waiter ke hisse mein jata hai (service + commission usi ko); 🙋 Self Service par koi waiter nahi lagta.",
      "GATE: jis waiter ke paas pichla cash jama karwana baqi ho, us ke naam par naya order nahi lagta — pehle cashier ko jama karwayein.",
      "Waiter-attributed order ke bill mein 'Service (Waiter)' line (Settings wala rate, default Rs 20) khud judti hai — ye customer ka paisa hai jo waiter ko jata hai; dukaan ki aamdani nahi.",
    ],
    tips: [
      "Waiter ka roz ka hisaab (service + commission) Day Close par 'Ada Kar Diya' se ada hota hai — Dashboard → Staff → Waiters mein poora khata dekhein.",
    ],
  },

  "owner-lucky": {
    title: "🎁 Lucky Draw — Haftawaar Inaam",
    steps: [
      "Lucky Draw ON karein, Minimum Bill set karein (default Rs 500) aur Save Settings dabayein — board par announcement strip bhi inhi settings se banti hai (Draw ka Din + Waqt lazmi bharein).",
      "Entries khud banti hain: threshold ya zyada ke har CLEARED bill par — jis par customer ka mobile ho (counter, QR table ya online). Baghair mobile wala bill entry nahi ban sakta — is liye counter par number likhna customer ke faide mein hai.",
      "Pool default IS HAFTA hai (haftawaar draw); Aaj / Is Mahina / Custom bhi chun sakte hain. Jeeta hua bill dobara pool mein nahi aata.",
      "Draw se pehle Prize chunein: 🎁 Deal FREE (active deals mein se) ya 🎀 Special Gift (khud likhein). 🎲 Draw Nikalein — winner screen par ayega.",
      "Winner ko 📱 WhatsApp par Mubarakbaad bhejein. Prize us ke customer record par 'dena baqi' flag ki tarah rahega — mil jaye to Draw History ya Customers se ✓ De Diya mark karein.",
    ],
  },
  "owner-feedback": {
    title: "📝 Feedback — Ray, Shikayat, Tajweez",
    steps: [
      "Customers table QR scan karke Feedback / 🚨 Shikayat / 💡 Tajweez bhejte hain — Taste, Service, Safai, Speed aur Rates ki alag alag ratings ke sath.",
      "Upar har category ki average rating dikhti hai; 🚨 nayi shikayatein laal badge mein — pehle wahi sambhalein.",
      "Filters: Sab / Kam Rating (1–2★) / Shikayatein / Tajweezein / Menu Requests.",
      "🍔 Menu Request par '➕ Menu Mein Add Karein' dabayein — Menu ka form customer ke bataye naam ke sath khul jayega; price/category aap set karke save karein, suggestion khud '✓ Add Ho Gayi' ho jayegi.",
      "Parh lene par ✓ Dekh Liya mark karein; purani/na-pasand entry Delete bhi ho sakti hai.",
      "Kisi waiter ke order par aayi Service rating us waiter ki average mein gin ti hai — Dashboard → Staff → Waiters mein har waiter ki ⭐ Service Rating dikhti hai.",
    ],
  },

  "owner-overview": {
    title: "📊 Dashboard Overview — Sale, Bills aur Tasdeeq",
    steps: [
      "Owner PIN se login karke Dashboard ke 📊 Overview tab par ayen; upar Today strip mein Canteen, Grocery, Counter, Online aur Low Stock ka khulasa dekhein.",
      "KPI cards mein Today's Total Sales, Orders Today, Cash, Online (JazzCash + Easypaisa) aur Udhaar (Khata) check karein.",
      "Overview tab par ⏳ badge ho to 💳 Online Payment Verification mein pending orders pehle check karein.",
      "Har verify card par customer, items, total, Method aur Txn ID dekhein; proof ki chhoti picture par click karke 🔍 Bara dekhein.",
      "Customer ne bheja wala amount order total se match ho aur proof sahi ho to ✅ Confirm — Order Aage Bhejein dabayein; is waqt token banta hai aur order Kitchen ya packing queue mein jata hai.",
      "Proof ghalat ho ya amount match na ho to ❌ Reject dabayein aur prompt mein saaf wajah likhein; stock wapas ho jayega aur customer ko wajah nazar ayegi.",
      "🏆 Best Sellers Today se zyada bikne wali items dekhein; kisi purani entry ko dekhna ho to 🧾 Bill History — Today mein bill par click karein.",
      "Bill khul jaye to receipt check karein aur zaroorat ho to 🖨️ Reprint (80mm) dabayein; kaam khatam ho to ✕ Close karein.",
    ],
    tips: [
      "Dhyaan dein: ⚠️ AMOUNT MATCH NAHI wali warning par Confirm bilkul na karein — pehle asal payment verify karein.",
      "Overview sirf aaj ka khulasa dikhata hai; Low Stock ki tafseel ke liye Inventory tab dekhein.",
    ],
  },

  "owner-menu": {
    title: "🍽️ Dashboard — Menu Item ADD / UPDATE",
    steps: [
      "Dashboard ke 🍽️ Canteen Menu tab par ayen — upar item form aur neeche menu table hai.",
      "⭐ Deal par 'Sirf Permanent Customers ke liye' on karne se deal ki qeemat sirf us bill par lagti hai jis par registered counter-customer select ho; warna deal ki cheezon ki aam qeematon ka total lagta hai. Menu board par aisi deal par ⭐ wala label lagta hai.",
      "ADD karna: form ke labeled boxes bharein — ITEM NAME, PRICE RS, EMOJI aur CATEGORY — phir green + Add Item dabayein; item table aur Canteen POS dono par aa jayega.",
      "UPDATE karna: neeche table mein sahi item ki row se Edit dabayein.",
      "Edit dabate hi wahi item upar form mein bhar jayega; sirf jo box badalna hai — naam, price, emoji ya category — usi ko change karein.",
      "UPDATE save karna: green Save Edit dabayein. Agar irada badal jaye to Cancel dabayein, baghair save kiye wapas aa jayenge.",
      "PHOTOS lagana: form ke neeche ITEM KI PHOTOS wale hisse mein 16 tak photos lag sakti hain (URL likhein ya 📷 Photo Upload Karein) — pehli photo MAIN photo hai jo har jagah dikhti hai. 2 ya zyada photos hon to Menu Board par item ghumta hua nazar ata hai; 8 ya zyada hon to bilkul 360° ghumta hua lagta hai. Photo recipe: item ko ek jagah rakhein, barabar roshni rakhein, phone ko ek hi doori par rakh kar aahista aahista gol ghoom kar 12–16 tasveerein lein.",
      "DELETE karna: item ki row ka red ✕ dabayein — ye kaam soch kar karein, delete ke baad item POS par nahi rahega.",
      "Table ke Stock column mein mojooda stock dekhein; roz ki stock entry kabhi yahan se na karein.",
      "DEAL banana (🎁 Deals section, isi tab mein neeche): DEAL NAME aur DEAL PRICE RS likhein, phir neeche picker mein har item ki qty rakhein jo ek deal mein jayegi (0 = deal mein nahi). Neeche readout mein kul qeemat, deal price aur bachat live dikhta hai — phir green + Add Deal dabayein.",
      "Deal UPDATE karna: Deals list mein us deal ki Edit dabayein — naam, price aur picker ki qty form mein bhar jayengi; badal kar Save Edit dabayein. Deal band karna ho to usi row ka Active wala button Off kar dein — deal POS, Online aur Menu Board teeno se ghayab ho jayegi, delete karne ki zaroorat nahi.",
    ],
    tips: [
      "Dhyaan dein: Canteen rates aur item details yahin Edit se badalte hain; Stock IN / Wastage ki asal entry Inventory tab se hoti hai taake entries log banay rahe.",
      "Current menu sample hai — asal dukaan ka menu aur rates pehle yahin se set karein.",
    ],
  },

  "owner-grocery": {
    title: "🛒 Dashboard — Product ADD / UPDATE",
    steps: [
      "Dashboard ke 🛒 Grocery tab par ayen — upar product form, neeche search/filter wali products table aur pagination hai.",
      "⭐ 'Sirf Permanent Customers ke liye' offer: product ke Offer Price ke sath ye wala nishan on kar dein to offer wali qeemat SIRF us bill par lagegi jis par registered counter-customer select ho — warna aam qeemat lagegi. Display board par aisi offer par ⭐ wala label lagta hai.",
      "ADD karna: labeled boxes bharein — PRODUCT NAME, BRAND / COMPANY (e.g. Sunsilk), SKU, EAN BARCODE (packed item ho to), RETAIL PRICE RS, WHOLESALE PRICE RS, WHOLESALE MIN QTY (khali = shop default), UNIT (per piece ya per kg), MAIN HEAD, SUB-HEAD aur EMOJI.",
      "PHOTOS lagana: form mein PRODUCT KI PHOTOS wale hisse mein 16 tak photos lag sakti hain (URL likhein ya 📷 Photo Upload Karein) — pehli photo MAIN photo hai jo har jagah dikhti hai; koi photo na ho to sub-head/head ki picture lag jati hai. 2 ya zyada photos hon to Products Board par product ghumta hua nazar ata hai; 8 ya zyada hon to bilkul 360° ghumta hua lagta hai. Photo recipe: product ko ek jagah rakhein, barabar roshni rakhein, phone ko ek hi doori par rakh kar aahista aahista gol ghoom kar 12–16 tasveerein lein.",
      "STOCK QTY wala box is form mein band (read-only) hai — stock yahan se NAHI badalta; naya product 0 stock ke sath banta hai, phir Inventory tab se Stock IN karein.",
      "Size add karna ho to 📦 Packings mein + Packing dabayein; har row mein PACKING SIZE, RETAIL PRICE RS, WHOLESALE PRICE RS, BARCODE, CONTAINS (PACKS) aur WS MIN (PACKS) likhein. Ghalat row ka red ✕ dabayein; koi size na ho to Packings khali chhor dein.",
      "Phir green + Add Product dabayein; product table mein aa jayega. List lambi ho to search, Head/Sub-Head filter aur Prev / Next se dhoondein.",
      "UPDATE karna: product ki row se Edit dabayein — poora form usi product se bhar jayega, Packings bhi wapas aa jayengi.",
      "Jo rate ya detail badalni ho labeled box mein change karein aur green Save Edit dabayein; na badalna ho to Cancel dabayein.",
      "FLAVOUR add karna (Edit ke doran): neeche 🎨 Variants wale hisse mein NEW VARIANT NAME likh kar + Variant Add dabayein, phir us variant ki packing — size, rates aur apna barcode — + Variant Packing se add karein. Jis product ke flavours na hon us ka sirf Standard variant rehta hai.",
      "DELETE karna: product ki row ka red ✕ dabayein — pehle naam aur SKU dobara check kar lein.",
    ],
    tips: [
      "Dhyaan dein: Packing alag product nahi hoti — 500g / 1kg / 2kg usi product ke sizes hain; CONTAINS batata hai ke dabbe mein kitne sealed packs hain, stock unhi base packs mein ginta hai.",
      "Company alag = product alag (Sunsilk alag, Pantene alag); ek hi company ke flavours usi product ke VARIANTS hain. Product tabhi sahi bane ga jab us ka Main Head aur Sub-Head pehle Heads tab mein mojood ho.",
      "Rates/details hamesha Edit se badalte hain; roz ki Stock IN aur Wastage hamesha Inventory tab se hoti hai — wahan barcode scan se entry sab se tez hai.",
    ],
  },

  "owner-udhaar": {
    title: "💰 Dashboard — Credit (Udhaar) aur Wasooli",
    steps: [
      "Dashboard ke 💰 Credit tab par ayen; upar Kul Baqaya — Sab Khaatay mein tamam customers ka total baqaya nazar ata hai.",
      "📄 Statement: kisi account ko select karke 📄 Statement dabayein — us ke saare udhaar bills aur wasooli tareekh ke hisaab se chalte hue baqaya ke sath nazar ate hain; print bhi hota hai aur WhatsApp par statement bhejna bhi mumkin hai.",
      "Khata kholna: list mein customer ki row dabayein (Naam, ID/Mobile, Kul Udhaar, Wasool aur Baqaya wali row). Naam, Student/Staff ID ya mobile likh kar 🔍 search se khata jaldi bhi dhoonda ja sakta hai.",
      "Khaata khulte hi neeche 📜 Khata Ledger mein har entry tareekh ke sath ati hai — 🧾 Udhaar Charge (Bill number ke sath), 💰 Wasooli (method ke sath), har entry ke baad wala Baqaya aur Darj Kiya (kis ne darj ki).",
      "Wasooli darj karna: 💰 Wasooli Darj Karein wale hisse mein RAQAM (Rs) likhein — aadhi wasooli ho to sirf utni hi raqam likhein jitni asal mili hai.",
      "METHOD chunein: 💵 Cash, 📱 JazzCash, 📱 Easypaisa, 🏦 Raast ya 🏦 Bank Transfer; zaroorat ho to NOTE (Optional) mein tafseel likh dein.",
      "✓ Wasooli Darj Karein dabayein; ✓ wala message ayega aur khaatay ka naya baqaya foran nazar ayega — ledger mein nayi wasooli entry bhi aa jayegi.",
      "Baqaya check karna: list ki har row par Baqaya laal rang mein aur Clear khata sabz ✓ Clear mein dikhta hai; kisi khaatay ka poora hisaab ledger ke aakhri Baqaya se match karein.",
    ],
    tips: [
      "Dhyaan dein: Wasooli baqaya se zyada darj nahi ho sakti — system rok dega. Zyada raqam mili ho to pehle customer se wajah confirm karein, ghalti ho to Owner adjustment alag entry se hoti hai.",
      "Wasooli hamesha isi screen se darj karein — bill ko edit/delete karke udhaar kabhi adjust na karein; ledger hi asal khata hai.",
    ],
  },

  "owner-heads": {
    title: "🗂️ Dashboard — Categories (Heads aur Sub-Heads)",
    steps: [
      "Dashboard ke 🗂️ Heads tab par ayen; structure hamesha Main Head → Sub Head → Product hoti hai.",
      "Naya Main Head add karna: head ka naam likhein, emoji chunein, image ho to Head Image URL likhein aur + Add Head dabayein.",
      "Naya Sub-Head add karna: pehle sahi Main Head chunein, sub-head ka naam likhein, image ho to URL likhein aur + Add Sub-Head dabayein.",
      "Head ki tafseel dekhna ho to us ki row ka ▶ dabayein; andar us ke sub-heads aur har ek ki product count nazar ayegi.",
      "Rename karna: Head ya Sub-Head ki row se Rename dabayein, naam ya image badlein aur Save dabayein; Cancel se purana naam wapas rahega.",
      "Delete se pehle Grocery tab mein us head/sub-head ke products ko Edit karke doosre head/sub-head mein shift karein.",
      "DELETE tabhi hoga jab product count 0 ho; row ka Delete dabayein. Khali head delete ho to us ke khali sub-heads bhi sath khatam ho jate hain.",
    ],
    tips: [
      "Dhyaan dein: Jis head mein koi sub-head nahi, us mein product add nahi ho sakta — pehle kam az kam ek sub-head banayein.",
      "Naam chhota aur saaf rakhein taake POS chips aur reports mein asaani se parha jaye.",
    ],
  },

  "owner-labels": {
    title: "🏷️ Dashboard — Barcode Stickers Print Karna",
    steps: [
      "Dashboard ke 🏷️ Labels tab par ayen; ek product ka sticker Grocery table ki row ke 🏷️ Label button se bhi khul sakta hai.",
      "Search, Head aur Sub-Head filter se products shortlist karein.",
      "Har product ke checkbox ko tick karein; ☑️ Visible sab select se screen par nazar ane wale sab select aur ✕ Clear se sab clear ho jate hain.",
      "Select shuda product ke samne Stickers wale box mein tadaad likhein — jitni likhein ge, print sheet mein utne stickers banenge.",
      "🖨️ Print Labels dabayein; sheet khul jaye to Har product ke stickers wali quantity dobara check karein.",
      "🖨️ Print dabayein aur print dialog mein label printer chunein; sticker size 50mm × 30mm hai.",
      "Kaam khatam ho to sheet ke ✕ Band karein button se wapas ayen aur ek sticker counter scanner se test scan zaroor karein.",
    ],
    tips: [
      "Dhyaan dein: Sticker par product ka naam aur retail price ata hai; barcode na ho to SKU hi Code128 barcode ban jata hai.",
      "Loose ya shop-packed cheezon par sticker pehle lagayein, phir shelf par rakhein — baghair sticker scan mushkil hoga.",
    ],
  },

  "owner-staff": {
    title: "🔐 Dashboard — Staff Access aur PIN",
    steps: [
      "Dashboard ke 🔐 Staff tab par ayen; list mein har banday ka naam, masked PIN aur us ke tabs ke chips nazar ayenge.",
      "Naya staff ADD karna: Naam likhein, theek 4 digits ka PIN likhein aur sirf wohi tabs tick karein jo us ke kaam ke hain.",
      "Phir + Add Staff dabayein; naya banda apne naam wale card aur naye PIN se login karega — PIN server par check hota hai, kisi ek device par nahi.",
      "UPDATE karna: staff ki row se Edit dabayein; form bhar jayega. Naam, PIN ya tabs badlein aur Save Access dabayein; Cancel se koi change save nahi hoga.",
      "Ek banday ko kai tabs mil sakte hain, masalan Canteen + Grocery; Owner ke Dashboard wala tab hamesha locked rehta hai.",
      "Apna Owner PIN badalna ho to Owner wali row ko Edit karein aur Save Access dabayein.",
      "Staff hatana ho to us ki row se Remove dabayein aur confirm karein — us ka login band ho jayega. Owner ko remove nahi kiya ja sakta.",
    ],
    tips: [
      "Dhyaan dein: Har banday ko sirf usi ke kaam ke tabs dein aur PIN kisi doosre se share na karne ki hidayat dein.",
      "PIN bhool jaye to Owner isi tab mein Edit karke naya 4-digit PIN set kar sakta hai.",
    ],
  },

  "owner-settings": {
    title: "⚙️ Dashboard — Shop Settings",
    steps: [
      "Dashboard ke ⚙️ Settings tab par sab se upar Shop Status dekhein: 🟢 Shop KHULI hai ya 🔴 Shop BAND hai.",
      "⭐ Loyalty Points (Settings): 'Points Earned — 1 point per Rs' mein woh raqam likhein jis par customer ko 1 point mile (default 100) aur 'Point Value — 1 point = Rs' mein ek point ki qeemat (default 1). Dono Save Settings se save hote hain.",
      "🛒 Low-Stock: 'Default Limit (pieces)' woh hadd hai jis par ya us se neeche stock wali cheez Low-Stock / Order List mein ati hai (default 5).",
      "Shop band karna ho to 🔴 Close Shop dabayein; ye switch foran server par save hota hai aur /online par Closed popup aa jata hai. Dobara kholna ho to 🟢 Open Shop dabayein.",
      "Closed popup ka number badalna: Contact Number (shown when closed) box mein asal number likhein — ye wala change neeche 💾 Save Settings dabane se save hota hai.",
      "Institution Name, Canteen Name aur Store Name — jo dukaan Business Setup mein on ho, sirf usi ke naam ka box yahan dikhta hai bharein; ye naam header, bills, online page aur table QR cards par khud update ho jate hain.",
      "Online Payment Accounts mein JazzCash Account Number, Easypaisa Account Number aur Raast / Bank (IBAN) asal values likhein; demo numbers par asal payment na mangwayein.",
      "Merchant QR lagana: neeche 📷 Merchant QR Codes mein har method (JazzCash, Easypaisa, Raast, Bank) ke card par ACCOUNT TITLE aur NUMBER / IBAN check karke 💾 Title/Number dabayein, phir 📷 QR Upload se us method ki asal QR image (PNG/JPG) lagayein — preview aa jayega aur customer ko Online Payment mein wahi QR bara nazar ayega. QR badalna ho to 📷 QR Badlein, hatana ho to 🗑️ Remove dabayein; counter ke liye usi card se 🖨️ QR Stand print karke laga dein. QR upload foran save hota hai — Save Settings ki zaroorat nahi.",
      "Wholesale Minimums mein pieces aur kg ki default limit set karein; kisi ek product ki alag limit Grocery product form ke WHOLESALE MIN QTY se lagti hai.",
      "Saari values check karke 💾 Save Settings dabayein aur ✓ Saved wala message zaroor dekhein.",
      "Settings ke baad Online page ek dafa khol kar naam, payment number aur Shop Open/Band wali surat khud test karein.",
      "Sab se upar 🏪 Business Setup block mein apni maujooda business type (Sirf Canteen / Sirf Dukaan / Dono + dukaan ki qisam) dekhein; badalna ho to 🔁 Tabdeel karein dabayein — type badalne se koi data delete NAHI hota, sirf andar nazar ane wale hisse badalte hain.",
    ],
    tips: [
      "Dhyaan dein: Shop Status switch foran save hota hai, lekin contact number, naam, payment numbers aur wholesale minimums ke liye Save Settings lazmi hai.",
      "Jab shop band ho to customers ko sirf Closed popup, contact number aur Call / WhatsApp button nazar ate hain — koi order place nahi hota.",
    ],
  },

  "owner-devices": {
    title: "🖨️ Owner — Printers & Devices",
    steps: [
      "Printers chalane wala chhota program (print-agent) dukaan ke PC par chalta hai. Is tab par sab se upar us ki halat simple alfaz mein likhi ati hai: ✅ Chal raha hai ya ❌ Band hai. Band ho to usi PC par print-agent chalana hoga — baghair us ke koi bill print nahi hoga.",
      "Printer jodne ke 3 steps (sirf pehli dafa): Step 1 — dukaan ke PC par print-agent folder mein start-print-agent.bat par double-click karke Print Program chalain aur window khuli rakhein. Step 2 — program chalte hi is tab par ek card ata hai: 'Ek Print Program judna chahta hai' — apna PC ho to ✔ Jor dein dabayein. Koi code likhna ya koi file kholni NAHI parti; program khud jud jata hai. Step 3 — printer chunein, Save karein, 🧪 Test Print nikalein. ('Advanced — code se jodein' wala purana tareeqa sirf khaas halat ke liye neeche band hisse mein rakha hai.)",
      "Printer chunnna: Bill Printer, Kitchen Printer aur Label Printer — teeno dropdowns mein wohi naam ate hain jo print program ne khud dhoondhe hain (USB/Network printers). Har kaam ke liye usi ka printer chunein aur 💾 Save dabayein. Naam ya IP haath se kabhi nahi likhna parta.",
      "Test print: har printer ke samne 🧪 Test Print dabayein — ek chhoti test parchi/sticker print hogi. Neeche jobs ki halat simple alfaz mein ati hai (⏳ gaya hai / ✅ print ho gaya / ❌ nahi hua — wajah ke sath). Kagaz par test aa jaye to printer tayyar hai.",
      "Cash drawer: drawer bill printer ke sath juda ho to har CASH bill par khud khul jata hai — koi alag setting nahi. JazzCash/Easypaisa/Udhaar wale bill par drawer nahi khulta.",
      "Barcode scanner: scanner ki USB taang PC mein lagayein — koi driver ya setting nahi hoti. Isi tab ke 🔫 Scanner Test mein kisi bhi cheez ka barcode scan karein: sabz message aa jaye to scanner tayyar hai. Amber message ka matlab hai scanner ne parh liya hai lekin wo cheez system mein nahi — pehle product add karein.",
      "Printer dropdown mein naam na aye to: printer ON karein, USB taang check karein, print program chal raha ho — printer lagte hi naam khud aa jata hai.",
    ],
    tips: [
      "Label printer alag chunein — stickers sirf usi par jate hain; bill printer par sticker sahi nahi ayega.",
      "Test print wali parchi par 'TEST' likha ata hai taake asal bills se alag pehchani jaye.",
    ],
  },

  "owner-tables": {
    title: "🪑 Dashboard — Table QR Cards",
    steps: [
      "Dashboard ke 🪑 Table QR tab par ayen; 🪑 Kul Tables ke samne abhi saved tadaad dekhein.",
      "Tadaad badalna: − ya + dabayein, ya box mein 1 se 100 tak number likhein — abhi ye sirf draft hai.",
      "✔ Apply dabayein aur '✓ Saved — ab N tables active hain' wala message dekhein; server par tables isi tadaad ke hisaab se active ho jati hain aur neeche bilkul utne hi table QR cards bante hain.",
      "🖨️ Print Table Cards dabayein, cards print karein aur har card ko usi number wali table par chipkayein.",
      "Customer Table 1 ka QR scan kare to Online page par Table 1 khud select hota hai; woh chahe to number ya Dine-In/Takeaway badal sakta hai.",
      "Tadaad kam karne se us se upar wali tables server par inactive ho jati hain — un par naya online order nahi aye ga, lekin purane orders aur bills ki table history bilkul nahi badalti.",
      "Tadaad change karne ke baad purane extra cards tables se hata dein aur naye cards ka ek QR khud scan karke test karein.",
    ],
    tips: [
      "Dhyaan dein: Apply dabaye baghair sirf − / + karne se saved tadaad, server ki tables aur online page — kuch nahi badalta.",
      "Aam canteen QR (baghair table ke) ke liye /online wala general link use hota hai; har table ke liye usi table ka apna card chipkayein.",
    ],
  },

  "owner-setup": {
    title: "🏪 Business Setup — Dukaan Ki Qisam",
    steps: [
      "Ye system pehli dafa chale to sab se pehle Business Setup ata hai: Step 1 mein 🍔 Sirf Canteen, 🛒 Sirf Dukaan ya 🏪 Dono chunein.",
      "Setup mukammal karne par system khud us hisse par le jata hai jo aap ke setup mein ON hai — band hisse ki gate screen par kabhi nahi girta. Dashboard hamesha khulta hai; 'Ye Hissa On Nahi Hai' wali screen sirf band hisse (masalan canteen band ho to Canteen POS) par ati hai, aur wahan ka ⚙️ Owner Settings button seedha Business Setup par le jata hai.",
      "Dukaan ho to Step 2 mein us ki qisam chunein — Grocery, Supermarket, Medical Store, Mobile Shop, Shoes, Kapre, Bakery waghera (14 qisamein). Har qisam ke sath us trade ke Heads aur kuch demo products khud aa jate hain taake system foran chal kar dikhe.",
      "Andar ka view isi choice se banta hai: jo dukaan off hai us ki tabs, Owner sections aur TV screens nahi dikhtein — direct link kholo to 'Ye Hissa On Nahi Hai' wala polite notice ata hai.",
      "Baad mein type badalna ho: Dashboard → ⚙️ Settings → 🏪 Business Setup → 🔁 Tabdeel karein. Wahan maujooda choice pehle se selected hoti hai aur warning bhi likhi hoti hai.",
      "Type badalne se KOI data delete nahi hota — purane products, orders, bills aur hisaab mehfooz rehte hain; sirf nazar ane wale hisse badalte hain. Wapas purani type par ao to sab kuch waisa hi milega.",
      "Nayi qisam ka demo catalogue sirf TAB seed hota hai jab product list bilkul khali ho (fresh install) — data maujood ho to seeding kabhi nahi hoti, kuch overwrite nahi hota.",
      "Dukaan ka naam setup par template wala aam naam (masalan 'Medical Store') lagta hai agar naam abhi default ho — asal naam Settings mein CANTEEN/GROCERY NAME se apna likh dein.",
      "Do khaas extra: 💊 Medical Store mein stock-IN par dawai ki Expiry (mahina/saal) bhar sakte hain aur ⏰ Expiry Qareeb warning Stock screen aur Owner Overview par ati hai. 📱 Mobile Shop mein phone par 'Serial/IMEI wala product' tick karein — bikri par har unit ka IMEI lazmi likhna hoga aur bill par print hoga.",
    ],
    tips: [
      "Setup ek dafa hi karna hota hai — ghalat type chun li ho to ghabrayen nahi, Settings se kabhi bhi badal sakte hain, data mehfooz rehta hai.",
      "Demo products sirf sample hain — Dashboard ke Grocery tab se apni asal products, rates aur stock daalein.",
      "Medical expiry sirf warning hai: batch-wise hisaab (konsi batch pehle biki) is version mein track nahi hota.",
    ],
  },

  "owner-customers": {
    title: "👥 Dashboard — Customers (Counter Record)",
    steps: [
      "Har counter bill par naam+mobile likha ho to us customer ka record yahan banta hai — ek record per mobile number, poore system ke liye ek hi (Sell, Canteen POS aur Rentals teeno ka). Koi account ya login NAHI banta — ye sirf counter wali maloomat hai; online accounts is se bilkul alag hain.",
      "⭐ Loyalty Points: har cleared bill par points khud bante hain (Settings mein rule: default har Rs 100 par 1 point) aur is tab ki detail mein har customer ka points balance dikhta hai. Bill par customer select ho to cashier 'Points istemal karein' se us ke points bill mein laga sakta hai (default 1 point = Rs 1) — balance kabhi minus nahi hota.",
      "📄 Udhaar Statement: customer ki detail mein (ya 💰 Credit tab mein) Statement dabayein — saare udhaar bills + wasooli tareekh ke hisaab se chalte hue baqaya ke sath; 🖨️ Print aur WhatsApp par bhejna dono mumkin hain.",
      "📱 WhatsApp Bill: jis bill par customer ka mobile ho, bill mukammal hone par aur bill dobara kholne par 'WhatsApp par Bill bhejein' ka button ata hai — dabate hi WhatsApp khul jata hai aur poora bill likha hua tayyar milta hai, sirf Send dabana rehta hai.",
      "List mein har customer ki Kul Khareed (cleared bills ka total), Bills ki tadaad aur Akhri Bill ki tareekh dikhti hai. Upar search se naam ya mobile se dhoond sakte hain.",
      "Customer par click karein → us ki POORI history: dono dukaanon ke bills (🛒 SELL / 🍽️ CANTEEN chip ke sath) aur 👰 Rental bookings, tareekh ke hisaab se. Kisi bill par click karne se woh bill dobara nazar ata hai aur Reprint bhi ho sakta hai.",
      "⭐ Special Discount %: Edit wale hisse mein apne permanent customer ka % set karein (masalan 5). Phir jab bhi woh customer kisi bill par select hoga, discount KHUD lag jayega — cashier chahe to us ek bill ke liye badal ya saaf kar sakta hai, saved % nahi badalta. Rentals par ye discount auto NAHI lagti.",
      "Naam ya mobile ghalat likha gaya ho to yahin Edit kar dein — purane bills par chhapa hua naam waisa hi rehta hai (bill ka snapshot), record ka naam naya ho jata hai.",
      "Naya record haath se bhi bana sakte hain (➕ Naya Customer Record) — number pehle se kisi aur naam par registered ho to system rok kar us customer ka naam batayega; ek number ka doosra record nahi banta.",
      "Receipt par customer ko us ke Kul Bills aur Kul Khareed bhi print hoti hai — ye figures cleared bills se bante hain aur current bill shamil hota hai.",
    ],
    tips: [
      "Customer ka data counter cashier ke liye hai — naam/mobile likhna ikhtiyari hai; baghair mobile ke bill bhi normal banta hai, sirf record nahi banta.",
      "Udhaar khata aur ye Customers record alag cheezein hain: Udhaar Wasooli 💰 Credit tab mein rehti hai; lekin udhaar bill naam+mobile ke sath bana ho to woh bill is customer ki history mein bhi dikhta hai.",
    ],
  },


  "owner-dayclose": {
    title: "🌙 Dashboard — Day Close (Z-Report)",
    steps: [
      "Har roz dukaan band karte waqt is tab se din ka hisaab milan karein: tareekh chunein — kul bikri payment tareeqe ke hisaab se (Cash / JazzCash / Easypaisa / Udhaar), udhaar diya aur wasool, kharchay aur sale returns apne aap gine jate hain.",
      "Expected Cash = Cash bikri + Cash wasooli − kharchay − cash refunds. Kharchay hamesha cash se gaye samjhe jate hain (kharcha record mein payment tareeqa nahi hota).",
      "Gina hua cash: drawer mein asal gine hue note box mein likhein — FARQ khud nazar ayega (zyada ho to +, kam ho to −).",
      "💾 Day Close Save karein dabayein — record (tareekh, cashier, figures, farq) hamesha ke liye save ho jata hai aur neeche History mein rehta hai; 🖨️ Print se din ki report nikalti hai.",
      "↩️ Sale Returns bhi isi tab ke neeche dikhte hain — kis bill ki wapsi hui, kitni raqam wapas hui. Ye sirf REPORT hai: is se koi paisa dobara nahi ghumta aur Profit & Loss mein double ginti nahi hoti.",
    ],
    tips: [
      "Farq roz aye to pehle cash wasooli aur kharchay ke records check karein — aksar entry reh jati hai, paisa nahi.",
    ],
  },
  "owner-suppliers": {
    title: "🚚 Dashboard — Suppliers (Khata)",
    steps: [
      "Supplier add karein: naam aur mobile likh kar ➕ Add dabayein. Ek naam ka ek hi record banta hai.",
      "Stock IN karte waqt (Inventory tab) supplier chunein ya naya naam likhein, KUL RAQAM (poori khareed) aur ADA RAQAM (abhi di hui) likhein — baqaya khud ban jata hai.",
      "Supplier par click karein → us ka khata: har khareed aur har payment tareekh ke hisaab se, chalta hua baqaya ke sath.",
      "Payment deni ho to 💰 Payment dein mein raqam likh kar save karein — baqaya foran kam ho jata hai. Kul raqam se zyada payment system nahi leta.",
      "Dashboard → Overview par kul dene wale (Payables) ka total card bhi dikhta hai.",
    ],
    tips: [
      "Supplier khata bilkul Udhaar khate jaisa hai — bas ye paisa HUM ne dena hai, lena nahi.",
    ],
  },
  "owner-reports": {
    title: "📋 Dashboard — Reports",
    steps: [
      "Upar se muddat chunein: Aaj / Is Hafta (pichle 7 din) / Is Mahina / Custom (apni tareekhein). Saari reports sirf cleared (mukammal) bills se banti hain.",
      "👤 Cashier Report: har cashier ki bills ki tadaad, kul bikri aur payment tareeqe ke hisaab se tor — kis ne kitna becha, ek nazar mein.",
      "🏆 Top Sellers: sab se zyada bikne wali cheezein — tadaad (qty) ke hisaab se bhi aur raqam ke hisaab se bhi, alag alag list.",
      "🐢 Slow Movers: stock mein mojood cheezein jin ki is muddat mein EK bhi sale nahi hui — in par paisa phansa hota hai; dobara order se pehle ye list zaroor dekhein.",
      "Jo dukaan Business Setup mein band ho, us ke orders in reports mein NAHI gine jate — canteen aur dukaan ka data kabhi mix nahi hota (Customers ki combined history is se alag, wahan har bill par dukaan ka chip lagta hai).",
    ],
    tips: [
      "Slow movers ko pehle khatam karne ke liye Deal ya Offer Price laga kar dekhein.",
    ],
  },
  "owner-pnl": {
    title: "📈 Dashboard — Profit & Loss",
    steps: [
      "Upar se period chunein — Aaj, Is Hafta, Is Mahina, Pichla Mahina, ya Custom tareekhein (From–To) rakhein. Saare hisaab usi period ke hain.",
      "Summary table parhein: Kul Bikri − Lagat = Gross Munafa; phir Kharchay aur Wastage Nuqsan minus hokar aakhir mein Khaals Munafa (Net) ata hai. Har dukaan ka column alag hai aur teesra Dono Mila Kar hai.",
      "Grocery ki lagat hamesha WHOLESALE price hai (wahi khareed rate hai) — is liye wholesale bills par munafa takreeban 0 ata hai, ye theek hai.",
      "Canteen item ka munafa tabhi gina jata hai jab us ki LAGAT bhari ho (Canteen Menu tab mein item Edit karke Lagat / Cost likhein). Jis item ki lagat nahi bhari, us ki bikri amber wale 'Lagat Baqi' hisse mein alag dikhti hai — munafa mein shamil NAHI hoti.",
      "Deal ka munafa us ke andar ki cheezon ki lagaton se banta hai — ek bhi cheez ki lagat missing ho to poori deal lagat-baqi mein jati hai.",
      "Kharcha darj karna: neeche form mein Tareekh, Kharcha kis cheez ka, Raqam aur Dukaan (Canteen / Grocery / Dono Dono) likh kar Add karein. 'Dono Dono' wala kharcha sirf combined column mein ginta hai. Galat entry Edit ya Delete kar sakte hain.",
      "Neeche per-item list mein har cheez ki bikri, lagat aur munafa hai — sab se zyada munafa dene wali cheez pehle; nuqsan wali lines red hain.",
      "Udhaar wali line sirf maloomat hai: is period mein kitna udhaar diya, kitni wasooli ayi, aur kul baqaya kitna hai (baqaya hamesha all-time hota hai). Udhaar ki bikri Kul Bikri mein pehle se shamil hai.",
    ],
    tips: [
      "Munafa tabhi sahi ayega jab lagat aur kharchay sahi bhare hon — canteen items ki lagat pehle din hi bhar dein, aur kharchay roz darj karein.",
      "Payment tasdeeq baqi (proof pending) ya reject hue online orders bikri mein NAHI ginte — confirm honay par hi woh sale banti hai.",
    ],
  }
};
