// ─────────────────────────────────────────────────────────────────────────────
// Supplier Khata (Phase B7) — Talha, 18 Nov 2026. Udhaar pattern ki mirror:
// suppliers (naam + mobile), khareed (stock-in entries jin par supplier +
// kul raqam + abhi-ada laga ho), aur "Payment dein" entries. Baqaya =
// Σ(kul − ada) − Σ(payments). Halka rakha gaya hai — koi order/booking nahi.
// ─────────────────────────────────────────────────────────────────────────────
import { q, one, tx, ApiError, paisa, rupees } from "../db";
import { emit, audit } from "../events";
import type { StaffPrincipal } from "../auth";

async function supplierBalance(c: import("pg").PoolClient | null, supplierId: string): Promise<number> {
  const run = c ? (sql: string, p: unknown[]) => c.query(sql, p).then((r) => r.rows[0]) : (sql: string, p: unknown[]) => one<any>(sql, p);
  const pur = await run(
    `SELECT COALESCE(SUM(COALESCE(purchase_total_paisa, 0) - COALESCE(purchase_paid_paisa, 0)), 0) AS s
     FROM stock_entries WHERE supplier_id = $1 AND entry_type = 'stock_in'`, [supplierId]
  );
  const pay = await run("SELECT COALESCE(SUM(amount_paisa), 0) AS s FROM supplier_payments WHERE supplier_id = $1", [supplierId]);
  return Number(pur?.s ?? 0) - Number(pay?.s ?? 0);
}

export async function listSuppliers(): Promise<Record<string, unknown>[]> {
  // Newest pehle (Talha, FIXED-12): naya supplier hamesha PEHLI row mein.
  const rows = await q<any>("SELECT * FROM suppliers WHERE is_active = true ORDER BY created_at DESC");
  const out: Record<string, unknown>[] = [];
  for (const s of rows) {
    const bal = await supplierBalance(null, s.id);
    const tot = await one<any>(
      "SELECT COALESCE(SUM(COALESCE(purchase_total_paisa,0)),0) AS t, COUNT(*) AS n FROM stock_entries WHERE supplier_id = $1 AND entry_type = 'stock_in'", [s.id]
    );
    out.push({
      id: s.id, name: s.name, mobile: s.phone ?? "",
      createdAt: s.created_at ? new Date(s.created_at).toISOString() : "",
      balance: rupees(bal), totalPurchases: rupees(Number(tot?.t ?? 0)), purchasesCount: Number(tot?.n ?? 0),
    });
  }
  return out;
}

export async function createSupplier(input: { name?: string; mobile?: string }): Promise<Record<string, unknown>> {
  const name = (input.name ?? "").trim();
  if (!name) throw new ApiError(400, "SUPPLIER_NAME_REQUIRED", "Supplier ka naam likhein");
  const mobile = (input.mobile ?? "").replace(/\D/g, "");
  const ex = await one<any>("SELECT * FROM suppliers WHERE lower(name) = lower($1) AND is_active = true", [name]);
  if (ex) return { id: ex.id, name: ex.name, mobile: ex.phone ?? "", balance: 0, totalPurchases: 0, purchasesCount: 0, existed: true };
  const ins = await q<any>("INSERT INTO suppliers (name, phone) VALUES ($1, $2) RETURNING *", [name, mobile || null]);
  return { id: ins[0].id, name: ins[0].name, mobile: ins[0].phone ?? "", balance: 0, totalPurchases: 0, purchasesCount: 0 };
}

export async function supplierLedger(supplierId: string): Promise<Record<string, unknown>> {
  const sup = await one<any>("SELECT * FROM suppliers WHERE id = $1", [supplierId]);
  if (!sup) throw new ApiError(404, "SUPPLIER_NOT_FOUND", "Supplier nahi mila");
  const purchases = await q<any>(
    `SELECT e.*, COALESCE(m.name, p.name) AS item_name FROM stock_entries e
     JOIN inventory_balances b ON b.id = e.inventory_id
     LEFT JOIN menu_items m ON m.id = b.menu_item_id
     LEFT JOIN grocery_products p ON p.id = b.grocery_product_id
     WHERE e.supplier_id = $1 AND e.entry_type = 'stock_in' ORDER BY e.created_at`,
    [supplierId]
  );
  const payments = await q<any>("SELECT * FROM supplier_payments WHERE supplier_id = $1 ORDER BY created_at", [supplierId]);
  type Ev = { at: string; label: string; amount: number; balanceAfter: number; sort: number };
  const events: Ev[] = [];
  let bal = 0; let seq = 0;
  const merged = [
    ...purchases.map((p) => ({ at: new Date(p.created_at).toISOString(), kind: "purchase" as const, row: p })),
    ...payments.map((p) => ({ at: new Date(p.created_at).toISOString(), kind: "payment" as const, row: p })),
  ].sort((a, b) => (a.at < b.at ? -1 : a.at > b.at ? 1 : 0));
  for (const ev of merged) {
    if (ev.kind === "purchase") {
      const due = Number(ev.row.purchase_total_paisa ?? 0) - Number(ev.row.purchase_paid_paisa ?? 0);
      if (due <= 0 && Number(ev.row.purchase_total_paisa ?? 0) <= 0) continue;
      bal += due;
      events.push({ at: ev.at, label: `📦 Khareed — ${ev.row.item_name ?? "Item"} × ${Math.abs(Number(ev.row.qty_delta))} (Kul Rs ${rupees(Number(ev.row.purchase_total_paisa ?? 0)).toLocaleString()}, Ada Rs ${rupees(Number(ev.row.purchase_paid_paisa ?? 0)).toLocaleString()})`, amount: due, balanceAfter: bal, sort: seq++ });
    } else {
      bal -= Number(ev.row.amount_paisa);
      events.push({ at: ev.at, label: `💰 Payment — ${ev.row.method ?? "cash"}${ev.row.note ? ` · ${ev.row.note}` : ""}`, amount: -Number(ev.row.amount_paisa), balanceAfter: bal, sort: seq++ });
    }
  }
  return {
    supplier: { id: sup.id, name: sup.name, mobile: sup.phone ?? "" },
    balance: rupees(bal),
    entries: events.map((e) => ({ at: e.at, label: e.label, amount: rupees(e.amount), balanceAfter: rupees(e.balanceAfter) })),
  };
}

export async function recordSupplierPayment(
  supplierId: string,
  input: { amount: number; method?: string; note?: string },
  staff: StaffPrincipal
): Promise<Record<string, unknown>> {
  const amt = paisa(input.amount);
  if (!(amt > 0)) throw new ApiError(400, "BAD_AMOUNT", "Payment ki raqam sahi likhein");
  return tx(async (c) => {
    const sup = (await c.query("SELECT * FROM suppliers WHERE id = $1 FOR UPDATE", [supplierId])).rows[0];
    if (!sup) throw new ApiError(404, "SUPPLIER_NOT_FOUND", "Supplier nahi mila");
    const bal = await supplierBalance(c, supplierId);
    if (amt > bal) throw new ApiError(409, "OVERPAYMENT", "Payment baqaya se zyada hai", { balance: rupees(bal) });
    await c.query(
      "INSERT INTO supplier_payments (supplier_id, amount_paisa, method, note, by_name) VALUES ($1,$2,$3,$4,$5)",
      [supplierId, amt, input.method ?? "cash", input.note?.trim() || null, staff.name]
    );
    await emit(c, "dashboard.changed", "dashboard", null, {});
    await audit(c, { type: "staff", staffId: staff.id }, "supplier.payment", "supplier", supplierId, { amount: input.amount });
    return { supplierId, balance: rupees(bal - amt) };
  });
}
