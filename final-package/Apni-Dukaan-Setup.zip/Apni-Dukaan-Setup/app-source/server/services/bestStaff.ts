import { one, q, tx, ApiError } from "../db";

// ── FIXED-12: Mahine ka Behtareen Staff ─────────────────────────────────
// Attribution: Service + Behaviour -> waiter (feedback.waiter_staff_id,
// customer-selected or order-derived); Taste -> jis staff ne order ready
// kiya (orders.ready_by_staff_id); Speed -> jis staff ne bill banaya
// (orders.cashier_staff_id). Jis order par link na ho, wo category
// attribute nahi hoti.

export interface BestStaffRow {
  staffId: string; // legacy id
  staffName: string;
  category: string; // "Waiter — Service + Behaviour" | "Kitchen — Taste" | "Cashier — Speed"
  count: number;
  avg: number; // 1 decimal
}

export async function bestStaffLeaderboard(month: string): Promise<BestStaffRow[]> {
  const rows = await q<any>(
    `WITH attributed AS (
       SELECT f.waiter_staff_id AS staff_id, 'Waiter — Service + Behaviour' AS category, f.service_rating AS rating
         FROM feedback f WHERE f.waiter_staff_id IS NOT NULL AND f.service_rating IS NOT NULL
         AND to_char(f.created_at AT TIME ZONE 'Asia/Karachi', 'YYYY-MM') = $1
       UNION ALL
       SELECT f.waiter_staff_id, 'Waiter — Service + Behaviour', f.behaviour_rating
         FROM feedback f WHERE f.waiter_staff_id IS NOT NULL AND f.behaviour_rating IS NOT NULL
         AND to_char(f.created_at AT TIME ZONE 'Asia/Karachi', 'YYYY-MM') = $1
       UNION ALL
       SELECT o.ready_by_staff_id, 'Kitchen — Taste', f.taste_rating
         FROM feedback f JOIN orders o ON o.id = f.order_id
         WHERE o.ready_by_staff_id IS NOT NULL AND f.taste_rating IS NOT NULL
         AND to_char(f.created_at AT TIME ZONE 'Asia/Karachi', 'YYYY-MM') = $1
       UNION ALL
       SELECT o.cashier_staff_id, 'Cashier — Speed', f.speed_rating
         FROM feedback f JOIN orders o ON o.id = f.order_id
         WHERE o.cashier_staff_id IS NOT NULL AND f.speed_rating IS NOT NULL
         AND to_char(f.created_at AT TIME ZONE 'Asia/Karachi', 'YYYY-MM') = $1
     )
     SELECT a.staff_id, s.legacy_id, s.display_name AS name, a.category,
            COUNT(*)::int AS cnt, ROUND(AVG(a.rating)::numeric, 1)::float8 AS avg
       FROM attributed a JOIN staff_users s ON s.id = a.staff_id
      GROUP BY a.staff_id, s.legacy_id, s.display_name, a.category
      ORDER BY avg DESC, cnt DESC`,
    [month]
  );
  return rows.map((r: any) => ({
    staffId: r.legacy_id ?? String(r.staff_id), staffName: r.name, category: r.category,
    count: Number(r.cnt), avg: Number(r.avg),
  }));
}

export async function listRewards() {
  const rows = await q<any>(
    `SELECT * FROM staff_month_rewards ORDER BY created_at DESC LIMIT 100`
  );
  return rows.map((r: any) => ({
    id: r.id, month: r.month, staffName: r.staff_name, category: r.category,
    avgRating: Number(r.avg_rating), ratingsCount: Number(r.ratings_count),
    rewardKind: r.reward_kind, amount: Math.round(Number(r.amount_paisa) / 100),
    giftText: r.gift_text, createdAt: r.created_at,
  }));
}

export async function recordReward(
  input: { month: string; staffId: string; category: string; avgRating: number; ratingsCount: number; rewardKind: "cash" | "gift"; amountRs?: number; giftText?: string },
  staff: { id: string }
) {
  const s = await one<any>("SELECT id, display_name AS name FROM staff_users WHERE legacy_id = $1 OR id::text = $1", [input.staffId]);
  if (!s) throw new ApiError(404, "STAFF_NOT_FOUND", "Staff nahi mila");
  const kind = input.rewardKind === "gift" ? "gift" : "cash";
  const amountPaisa = kind === "cash" ? Math.max(0, Math.round(Number(input.amountRs ?? 0) * 100)) : 0;
  const giftText = kind === "gift" ? String(input.giftText ?? "").slice(0, 200) : "";
  if (kind === "cash" && amountPaisa <= 0) throw new ApiError(400, "BAD_AMOUNT", "Cash inaam ki raqam likhein");
  if (kind === "gift" && !giftText) throw new ApiError(400, "BAD_GIFT", "Gift ki tafseel likhein");
  return tx(async (c) => {
    const r = await c.query(
      `INSERT INTO staff_month_rewards (month, staff_id, staff_name, category, avg_rating, ratings_count, reward_kind, amount_paisa, gift_text, given_by_staff_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
      [input.month, s.id, s.name, String(input.category ?? "").slice(0, 80), Number(input.avgRating) || 0,
       Math.round(Number(input.ratingsCount) || 0), kind, amountPaisa, giftText, staff.id]
    );
    if (kind === "cash") {
      // Cash inaam = dukaan ka kharcha (Expense) — P&L mein saaf nazar aaye.
      await c.query(
        `INSERT INTO expenses (legacy_id, title, amount_paisa, shop, expense_date, note, created_by_staff_id)
         VALUES ($1, $2, $3, 'canteen', to_char(now() AT TIME ZONE 'Asia/Karachi', 'YYYY-MM-DD')::date, $4, $5)`,
        [`exp-${Date.now()}-${Math.floor(Math.random() * 1e6)}`, `Mahine ka Inaam — ${s.name}`, amountPaisa,
         `${input.month} — Behtareen Staff (⭐${input.avgRating}, ${input.ratingsCount} ratings)`, staff.id]
      );
    }
    return { id: r.rows[0].id };
  });
}
