// ─────────────────────────────────────────────────────────────────────────────
// Waiters — commission / service / tankhwah / cash-jama (Talha, FIXED-12).
// Teen saaf hisaab, kabhi mix nahi:
//  1) SERVICE (customer-paid): waiter-attributed order ke bill ki service
//     line (orders.service_charge_paisa). Customer ka paisa waiter ko —
//     dukaan ki bikri NAHI, payout par EXPENSE BHI NAHI (pass-through).
//  2) COMMISSION (shop-paid): item-14 %/fixed, snapshot har order par;
//     sirf commission|both pay types; bill CLEAR hone par accrue; payout
//     par Expense post hota hai ("Waiter Commission — <name>").
//  3) TANKHWAH (salary): sirf payments ka khata (auto-accrue NAHI) —
//     payout par Expense ("Tankhwah — <name>").
// Cash-jama: waiter ki collections (orders.collected_by_staff_id) minus
// waiter_deposits = us ke paas baqi cash (Day Close isi par chalta hai).
// ─────────────────────────────────────────────────────────────────────────────
import { q, one, tx, ApiError, paisa, businessDate } from "../db";

const rupees = (p: number) => Math.round(Number(p ?? 0) / 100);
import type { StaffPrincipal } from "../auth";

const CLEARED = "(o.payment_status IS NULL OR o.payment_status = 'confirmed') AND o.status <> 'cancelled'";

export interface WaiterSummary {
  staffId: string; // legacy id
  name: string;
  payType: string;
  salaryAmount: number; // Rs / mahina
  ordersToday: number;
  ordersPeriod: number;
  billTotalPeriod: number; // Rs — attributed orders (cleared) ka bill total
  serviceToday: number;
  servicePeriod: number;
  servicePaid: number; // kul ada (service)
  serviceBaqaya: number;
  commissionToday: number;
  commissionPeriod: number;
  commissionPaid: number;
  commissionBaqaya: number;
  salaryPaidTotal: number;
  salaryLastAt: string | null;
  collectedToday: number; // aaj customers se wasool (us waiter ke haath)
  depositedToday: number;
  pendingDeposit: number; // abhi waiter ke paas (kul)
  serviceRatingAvg: number | null; // customers ki service rating (feedback se)
  serviceRatingCount: number;
}

/** Ek order ki commission (Rs) — snapshot se; pay type commission na ho
 *  ya bill clear na ho to 0. Return hua bill commission wapas karta hai:
 *  us order ke returns ka hissa proportion mein kat jata hai. */
function commissionOf(o: any, returnedPaisa: number): number {
  if (!o.waiter_staff_id) return 0;
  if (o.waiter_pay_type !== "commission" && o.waiter_pay_type !== "both") return 0;
  const mode = o.commission_mode ?? "percent";
  const val = Number(o.commission_value ?? 0);
  if (!(val > 0)) return 0;
  // Commission bill ke SHOP hisse par (service pass-through par nahi).
  const base = Math.max(0, Number(o.total_paisa) - Number(o.service_charge_paisa ?? 0));
  let comm = mode === "fixed" ? paisa(val) : Math.round((base * val) / 100);
  if (returnedPaisa > 0 && Number(o.total_paisa) > 0) {
    comm = Math.round(comm * Math.max(0, 1 - returnedPaisa / Number(o.total_paisa)));
  }
  return rupees(comm);
}


// pg DATE columns ko JS Date bana kar deta hai — String(date) se
// "Thu Nov 19 2026..." banta hai jo YYYY-MM-DD se kabhi match nahi
// hota (commission/service ke hisaab isi liye 0 aa rahe thay). Local
// getters pg ki apni construction (local midnight) se hamesha sahi
// din dete hain, har timezone mein.
function dayStr(v: unknown): string {
  if (v instanceof Date) {
    const m = String(v.getMonth() + 1).padStart(2, "0");
    const d = String(v.getDate()).padStart(2, "0");
    return `${v.getFullYear()}-${m}-${d}`;
  }
  return String(v).slice(0, 10);
}

export async function waiterSummaries(range: { from: string; to: string }): Promise<WaiterSummary[]> {
  const waiters = await q<any>("SELECT * FROM staff_users WHERE is_waiter = true AND is_active = true ORDER BY created_at ASC");
  const today = businessDate();
  const out: WaiterSummary[] = [];
  for (const w of waiters) {
    const orders = await q<any>(
      `SELECT * FROM orders o WHERE o.waiter_staff_id = $1 AND ${CLEARED}`,
      [w.id]
    );
    const returns = await q<any>(
      `SELECT order_id, COALESCE(SUM(total_paisa),0) AS s FROM sale_returns WHERE order_id IS NOT NULL GROUP BY order_id`
    );
    const retByOrder = new Map<string, number>(returns.map((r: any) => [r.order_id, Number(r.s)]));
    let ordersToday = 0, ordersPeriod = 0, billTotalPeriod = 0;
    let serviceToday = 0, servicePeriod = 0, commissionToday = 0, commissionPeriod = 0;
    for (const o of orders) {
      const d = dayStr(o.business_date);
      const inPeriod = d >= range.from && d <= range.to;
      const comm = commissionOf(o, retByOrder.get(o.id) ?? 0);
      const svc = rupees(Number(o.service_charge_paisa ?? 0));
      if (d === today) { ordersToday += 1; serviceToday += svc; commissionToday += comm; }
      if (inPeriod) {
        ordersPeriod += 1;
        billTotalPeriod += rupees(Number(o.total_paisa));
        servicePeriod += svc; commissionPeriod += comm;
      }
    }
    const pays = await q<any>("SELECT kind, COALESCE(SUM(amount_paisa),0) AS s, MAX(created_at) AS last_at FROM waiter_payments WHERE staff_id = $1 GROUP BY kind", [w.id]);
    const paidOf = (k: string) => rupees(Number(pays.find((p: any) => p.kind === k)?.s ?? 0));
    const serviceEarnedAll = orders.reduce((s: number, o: any) => s + rupees(Number(o.service_charge_paisa ?? 0)), 0);
    const commissionEarnedAll = orders.reduce((s: number, o: any) => s + commissionOf(o, retByOrder.get(o.id) ?? 0), 0);
    const colT = await one<any>("SELECT COALESCE(SUM(total_paisa),0) AS s FROM orders WHERE collected_by_staff_id = $1 AND status <> 'cancelled' AND business_date = $2", [w.id, today]);
    const depT = await one<any>("SELECT COALESCE(SUM(amount_paisa),0) AS s FROM waiter_deposits WHERE staff_id = $1 AND business_date = $2", [w.id, today]);
    const colAll = await one<any>("SELECT COALESCE(SUM(total_paisa),0) AS s FROM orders WHERE collected_by_staff_id = $1 AND status <> 'cancelled'", [w.id]);
    const depAll = await one<any>("SELECT COALESCE(SUM(amount_paisa),0) AS s FROM waiter_deposits WHERE staff_id = $1", [w.id]);
    const fb = await one<any>("SELECT AVG(service_rating)::float AS a, COUNT(service_rating)::int AS n FROM feedback WHERE waiter_staff_id = $1 AND service_rating IS NOT NULL", [w.id]);
    const salaryRow = pays.find((p: any) => p.kind === "salary");
    out.push({
      staffId: w.legacy_id ?? w.id,
      name: w.display_name,
      payType: w.pay_type ?? "commission",
      salaryAmount: rupees(Number(w.salary_amount_paisa ?? 0)),
      ordersToday, ordersPeriod, billTotalPeriod,
      serviceToday, servicePeriod,
      servicePaid: paidOf("service"),
      serviceBaqaya: Math.max(0, serviceEarnedAll - paidOf("service")),
      commissionToday, commissionPeriod,
      commissionPaid: paidOf("commission"),
      commissionBaqaya: Math.max(0, commissionEarnedAll - paidOf("commission")),
      salaryPaidTotal: paidOf("salary"),
      salaryLastAt: salaryRow?.last_at ? new Date(salaryRow.last_at).toISOString() : null,
      collectedToday: rupees(Number(colT?.s ?? 0)),
      depositedToday: rupees(Number(depT?.s ?? 0)),
      pendingDeposit: Math.max(0, rupees(Number(colAll?.s ?? 0)) - rupees(Number(depAll?.s ?? 0))),
      serviceRatingAvg: fb?.a != null ? Math.round(Number(fb.a) * 10) / 10 : null,
      serviceRatingCount: Number(fb?.n ?? 0),
    });
  }
  return out;
}

export interface WaiterDailyLine {
  staffId: string;
  name: string;
  payType: string;
  orders: number;
  billTotal: number;
  serviceToday: number;
  commissionToday: number;
  paidToday: number; // service + commission adaigi (us date par)
  pichlaBaqaya: number; // service + commission, date se pehle ka
  kulBaqaya: number; // pichla + aaj − aaj ki adaigi
  collectedToday: number;
  depositedToday: number;
  pendingDeposit: number; // kul (us date tak)
  serviceBaqaya: number; // kul (us date tak) — kind-wise split
  commissionBaqaya: number;
}

/** Ek business date ke waiter figures — Day Close isi par chalta hai. */
export async function waiterDailyFigures(date: string): Promise<WaiterDailyLine[]> {
  const waiters = await q<any>("SELECT * FROM staff_users WHERE is_waiter = true AND is_active = true ORDER BY created_at ASC");
  const returns = await q<any>("SELECT order_id, COALESCE(SUM(total_paisa),0) AS s FROM sale_returns WHERE order_id IS NOT NULL GROUP BY order_id");
  const retByOrder = new Map<string, number>(returns.map((r: any) => [r.order_id, Number(r.s)]));
  const out: WaiterDailyLine[] = [];
  for (const w of waiters) {
    const orders = await q<any>(`SELECT * FROM orders o WHERE o.waiter_staff_id = $1 AND ${CLEARED}`, [w.id]);
    let ordersN = 0, billTotal = 0, serviceToday = 0, commissionToday = 0, serviceBefore = 0, commissionBefore = 0;
    for (const o of orders) {
      const d = dayStr(o.business_date);
      const comm = commissionOf(o, retByOrder.get(o.id) ?? 0);
      const svc = rupees(Number(o.service_charge_paisa ?? 0));
      if (d === date) { ordersN += 1; billTotal += rupees(Number(o.total_paisa)); serviceToday += svc; commissionToday += comm; }
      else if (d < date) { serviceBefore += svc; commissionBefore += comm; }
    }
    const pays = await q<any>("SELECT kind, business_date, COALESCE(SUM(amount_paisa),0) AS s FROM waiter_payments WHERE staff_id = $1 AND kind IN ('service','commission') GROUP BY kind, business_date", [w.id]);
    let paidToday = 0, paidBefore = 0;
    for (const p of pays) {
      const d = dayStr(p.business_date);
      if (d === date) paidToday += rupees(Number(p.s));
      else if (d < date) paidBefore += rupees(Number(p.s));
    }
    const pichla = Math.max(0, serviceBefore + commissionBefore - paidBefore);
    const paidSvcAll = pays.filter((p: any) => p.kind === "service").reduce((s: number, p: any) => s + rupees(Number(p.s)), 0);
    const paidCommAll = pays.filter((p: any) => p.kind === "commission").reduce((s: number, p: any) => s + rupees(Number(p.s)), 0);
    const serviceBaqaya = Math.max(0, serviceBefore + serviceToday - paidSvcAll);
    const commissionBaqaya = Math.max(0, commissionBefore + commissionToday - paidCommAll);
    const colT = await one<any>("SELECT COALESCE(SUM(total_paisa),0) AS s FROM orders WHERE collected_by_staff_id = $1 AND status <> 'cancelled' AND business_date = $2", [w.id, date]);
    const depT = await one<any>("SELECT COALESCE(SUM(amount_paisa),0) AS s FROM waiter_deposits WHERE staff_id = $1 AND business_date = $2", [w.id, date]);
    const colAll = await one<any>("SELECT COALESCE(SUM(total_paisa),0) AS s FROM orders WHERE collected_by_staff_id = $1 AND status <> 'cancelled' AND business_date <= $2", [w.id, date]);
    const depAll = await one<any>("SELECT COALESCE(SUM(amount_paisa),0) AS s FROM waiter_deposits WHERE staff_id = $1 AND business_date <= $2", [w.id, date]);
    out.push({
      staffId: w.legacy_id ?? w.id, name: w.display_name, payType: w.pay_type ?? "commission",
      orders: ordersN, billTotal, serviceToday, commissionToday, paidToday,
      pichlaBaqaya: pichla, kulBaqaya: pichla + serviceToday + commissionToday - paidToday,
      collectedToday: rupees(Number(colT?.s ?? 0)), depositedToday: rupees(Number(depT?.s ?? 0)),
      pendingDeposit: Math.max(0, rupees(Number(colAll?.s ?? 0)) - rupees(Number(depAll?.s ?? 0))),
      serviceBaqaya, commissionBaqaya,
    });
  }
  return out;
}

export async function waiterSummaryFor(staffUuid: string): Promise<WaiterSummary | null> {
  const all = await waiterSummaries({ from: "0001-01-01", to: "9999-12-31" });
  const w = await one<any>("SELECT legacy_id FROM staff_users WHERE id = $1", [staffUuid]);
  return all.find((s) => s.staffId === (w?.legacy_id ?? staffUuid)) ?? null;
}

/** Adaigi darj karein. Commission/Salary → Expense bhi post (dukaan ka
 *  kharcha). Service → koi expense NAHI (customer-funded pass-through). */
export async function recordWaiterPayment(
  staffLegacyId: string,
  args: { kind: "commission" | "salary" | "service"; amountRs: number; method?: string; monthLabel?: string; dateISO?: string },
  staff: StaffPrincipal
): Promise<Record<string, unknown>> {
  const w = await one<any>("SELECT * FROM staff_users WHERE legacy_id = $1 AND is_waiter = true", [staffLegacyId]);
  if (!w) throw new ApiError(404, "WAITER_NOT_FOUND", "Waiter nahi mila");
  const amount = Math.round(Number(args.amountRs) || 0);
  if (amount <= 0) throw new ApiError(400, "BAD_AMOUNT", "Raqam sahi likhein");
  if (args.kind === "commission" || args.kind === "service") {
    const sums = await waiterSummaries({ from: "0001-01-01", to: "9999-12-31" });
    const s = sums.find((x) => x.staffId === staffLegacyId);
    const baqaya = args.kind === "commission" ? (s?.commissionBaqaya ?? 0) : (s?.serviceBaqaya ?? 0);
    if (amount > baqaya) throw new ApiError(409, "OVERPAYMENT", `Adaigi baqaya (Rs ${baqaya.toLocaleString()}) se zyada hai`);
  }
  const today = args.dateISO ?? businessDate();
  await tx(async (c) => {
    await c.query(
      "INSERT INTO waiter_payments (staff_id, kind, amount_paisa, method, month_label, business_date, created_by_staff_id) VALUES ($1,$2,$3,$4,$5,$6,$7)",
      [w.id, args.kind, paisa(amount), args.method ?? "cash", args.monthLabel ?? null, today, staff.id]
    );
    if (args.kind === "commission" || args.kind === "salary") {
      const title = args.kind === "commission" ? `Waiter Commission — ${w.display_name}` : `Tankhwah — ${w.display_name}`;
      await c.query(
        "INSERT INTO expenses (title, amount_paisa, expense_date, shop, note) VALUES ($1,$2,$3,'canteen',$4)",
        [title, paisa(amount), today, args.kind === "salary" ? (args.monthLabel ?? null) : "Waiter commission adaigi"]
      );
    }
  });
  return { ok: true };
}

/** Cashier ne waiter se cash wasool kar liya (partial bhi ho sakta hai). */
export async function recordWaiterDeposit(
  staffLegacyId: string,
  args: { amountRs: number },
  staff: StaffPrincipal
): Promise<Record<string, unknown>> {
  const w = await one<any>("SELECT * FROM staff_users WHERE legacy_id = $1 AND is_waiter = true", [staffLegacyId]);
  if (!w) throw new ApiError(404, "WAITER_NOT_FOUND", "Waiter nahi mila");
  const amount = Math.round(Number(args.amountRs) || 0);
  if (amount <= 0) throw new ApiError(400, "BAD_AMOUNT", "Raqam sahi likhein");
  const sums = await waiterSummaries({ from: "0001-01-01", to: "9999-12-31" });
  const s = sums.find((x) => x.staffId === staffLegacyId);
  if (amount > (s?.pendingDeposit ?? 0)) {
    throw new ApiError(409, "OVER_DEPOSIT", `Jama raqam waiter ke baqi cash (Rs ${(s?.pendingDeposit ?? 0).toLocaleString()}) se zyada hai`);
  }
  await q(
    "INSERT INTO waiter_deposits (staff_id, amount_paisa, business_date, confirmed_by_staff_id) VALUES ($1,$2,$3,$4)",
    [w.id, paisa(amount), businessDate(), staff.id]
  );
  return { ok: true };
}
