// ─────────────────────────────────────────────────────────────────────────────
// Sale Returns (Phase B6) — Talha, 18 Nov 2026.
// Ek mukammal (cleared) bill ki lines wapas: qty kabhi sold − pehle-wapas
// se zyada nahi; stock EXACTLY ONCE wapas (order_lines.returned_qty guard);
// refund bill ke apne payment method par — Udhaar bill ka return khata
// adjustment ban kar baqaya kam karta hai. Return record hamesha original
// bill se linked rehta hai; P&L inhein negative bikri gin ta hai.
// ─────────────────────────────────────────────────────────────────────────────
import { tx, q, one, ApiError, rupees } from "../db";
import { emit, audit } from "../events";
import type { StaffPrincipal } from "../auth";

export interface ReturnLineInput { lineId: string; qty: number }

async function restoreStock(c: import("pg").PoolClient, line: any, qty: number, staffId: string | null) {
  // Deal line: components ke pools wapas (snapshot legacy ids se).
  if (line.item_kind === "deal") {
    const comps: { itemId: string; qty: number }[] = line.components ?? [];
    for (const comp of comps) {
      const mi = await one<any>("SELECT id FROM menu_items WHERE legacy_id = $1 OR id::text = $1", [comp.itemId]);
      if (!mi) continue;
      const bal = await one<any>("SELECT id FROM inventory_balances WHERE menu_item_id = $1", [mi.id]);
      if (!bal) continue;
      const upd = await c.query(
        "UPDATE inventory_balances SET quantity_on_hand = quantity_on_hand + $2, version = version + 1, updated_at = now() WHERE id = $1 RETURNING quantity_on_hand",
        [bal.id, comp.qty * qty]
      );
      await c.query(
        "INSERT INTO stock_entries (inventory_id, entry_type, qty_delta, qty_after, order_line_id, created_by_staff_id) VALUES ($1,'sale_reversal',$2,$3,$4,$5)",
        [bal.id, comp.qty * qty, Number(upd.rows[0].quantity_on_hand), line.id, staffId]
      );
    }
    return;
  }
  // Menu / grocery line: base pieces = qty × contains_qty.
  let bal: any = null;
  if (line.menu_item_id) {
    bal = await one<any>("SELECT id FROM inventory_balances WHERE menu_item_id = $1", [line.menu_item_id]);
  } else if (line.grocery_product_id) {
    // Balance pool product par hai (variants share karte hain — orders.ts
    // ki tarah); variant column inventory_balances par hai hi nahi.
    bal = await one<any>(
      "SELECT id FROM inventory_balances WHERE grocery_product_id = $1",
      [line.grocery_product_id]
    );
  }
  if (bal) {
    const baseQty = qty * Number(line.contains_qty_snapshot ?? 1);
    const upd = await c.query(
      "UPDATE inventory_balances SET quantity_on_hand = quantity_on_hand + $2, version = version + 1, updated_at = now() WHERE id = $1 RETURNING quantity_on_hand",
      [bal.id, baseQty]
    );
    await c.query(
      "INSERT INTO stock_entries (inventory_id, entry_type, qty_delta, qty_after, order_line_id, created_by_staff_id) VALUES ($1,'sale_reversal',$2,$3,$4,$5)",
      [bal.id, baseQty, Number(upd.rows[0].quantity_on_hand), line.id, staffId]
    );
  }
  // Packing-tracked stock bhi wapas.
  if (line.grocery_packing_id) {
    await c.query(
      "UPDATE grocery_packings SET stock_qty = stock_qty + $2, updated_at = now() WHERE id = $1 AND stock_qty IS NOT NULL",
      [line.grocery_packing_id, qty]
    );
  }
}

export async function createReturn(
  input: { orderId: string; lines: ReturnLineInput[] },
  staff: StaffPrincipal
): Promise<Record<string, unknown>> {
  if (!input.lines?.length) throw new ApiError(400, "RETURN_LINES_REQUIRED", "Kam az kam ek line select karein");
  return tx(async (c) => {
    const order = (await c.query("SELECT o.*, s.kind AS shop_kind FROM orders o JOIN shops s ON s.id = o.shop_id WHERE o.id = $1 FOR UPDATE OF o", [input.orderId])).rows[0];
    if (!order) throw new ApiError(404, "ORDER_NOT_FOUND", "Bill nahi mila");
    if (order.status === "cancelled" || order.payment_status === "proof_pending" || order.payment_status === "rejected") {
      throw new ApiError(409, "ORDER_NOT_CLEARED", "Ye bill abhi mukammal (cleared) nahi — return nahi ho sakta");
    }
    const billRow = (await c.query(
      "SELECT b.bill_no FROM bill_orders bo JOIN bills b ON b.id = bo.bill_id WHERE bo.order_id = $1 LIMIT 1", [order.id]
    )).rows[0];
    const billNo = billRow?.bill_no ?? "";

    let totalPaisa = 0;
    const doneLines: { line: any; qty: number; amount: number; itemId: string }[] = [];
    for (const rl of input.lines) {
      if (!(rl.qty > 0)) continue;
      const line = (await c.query("SELECT * FROM order_lines WHERE id = $1 AND order_id = $2 FOR UPDATE", [rl.lineId, order.id])).rows[0];
      if (!line) throw new ApiError(400, "LINE_NOT_FOUND", "Bill ki line nahi mili");
      const remaining = Number(line.quantity) - Number(line.returned_qty ?? 0);
      if (rl.qty > remaining + 1e-9) {
        throw new ApiError(409, "RETURN_QTY_EXCEEDED", `"${line.item_name_snapshot}" ki sirf ${remaining} qty wapas ho sakti hai (baqi pehle wapas ho chuki)`);
      }
      const amount = Math.round(Number(line.unit_price_paisa) * rl.qty);
      totalPaisa += amount;
      await c.query("UPDATE order_lines SET returned_qty = returned_qty + $2 WHERE id = $1", [line.id, rl.qty]);
      await restoreStock(c, line, rl.qty, staff.id);
      const legacy = line.item_kind === "deal"
        ? `deal:${(await one<any>("SELECT legacy_id FROM deals WHERE id = $1", [line.deal_id]))?.legacy_id ?? line.deal_id}`
        : line.menu_item_id ? (await one<any>("SELECT legacy_id FROM menu_items WHERE id = $1", [line.menu_item_id]))?.legacy_id
        : line.grocery_product_id ? (await one<any>("SELECT legacy_id FROM grocery_products WHERE id = $1", [line.grocery_product_id]))?.legacy_id
        : null;
      doneLines.push({ line, qty: rl.qty, amount, itemId: legacy ?? "" });
    }
    if (!doneLines.length || totalPaisa <= 0) throw new ApiError(400, "RETURN_EMPTY", "Return mein koi valid line nahi");

    const ret = await c.query(
      "INSERT INTO sale_returns (order_id, bill_no, shop_kind, refund_method, total_paisa, by_name) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id, created_at",
      [order.id, billNo, order.shop_kind, order.payment_method ?? "Cash", totalPaisa, staff.name]
    );
    const returnId = ret.rows[0].id as string;
    for (const d of doneLines) {
      await c.query(
        "INSERT INTO sale_return_lines (return_id, order_line_id, item_id, name, qty, unit_price_paisa, line_total_paisa) VALUES ($1,$2,$3,$4,$5,$6,$7)",
        [returnId, d.line.id, d.itemId || null, d.line.item_name_snapshot, d.qty, Number(d.line.unit_price_paisa), d.amount]
      );
    }

    // Udhaar bill: khata adjustment — baqaya kam.
    if ((order.payment_method ?? "") === "Udhaar") {
      const pay = (await c.query(
        `SELECT p.udhaar_account_id FROM payments p JOIN bill_orders bo ON bo.bill_id = p.bill_id
         WHERE bo.order_id = $1 AND p.payment_kind = 'udhaar_charge' AND p.udhaar_account_id IS NOT NULL LIMIT 1`,
        [order.id]
      )).rows[0];
      if (pay?.udhaar_account_id) {
        const balRow = (await c.query(
          "SELECT COALESCE(SUM(amount_paisa),0) AS s FROM udhaar_ledger_entries WHERE udhaar_account_id = $1", [pay.udhaar_account_id]
        )).rows[0];
        const newBal = Number(balRow.s) - totalPaisa;
        await c.query(
          "INSERT INTO udhaar_ledger_entries (udhaar_account_id, entry_type, amount_paisa, balance_after_paisa, note, created_by_staff_id) VALUES ($1,'adjustment',$2,$3,$4,$5)",
          [pay.udhaar_account_id, -totalPaisa, newBal, `Sale Return — Bill ${billNo}`, staff.id]
        );
      }
    }

    await emit(c, "stock.changed", "order", order.id, {});
    await emit(c, "dashboard.changed", "dashboard", null, {});
    await audit(c, { type: "staff", staffId: staff.id }, "sale.return", "order", order.id, { billNo, total: rupees(totalPaisa) });
    return {
      id: returnId, orderId: order.id, billNo, mode: order.shop_kind,
      refundMethod: order.payment_method ?? "Cash", total: rupees(totalPaisa),
      byName: staff.name, createdAt: ret.rows[0].created_at,
      lines: doneLines.map((d) => ({ itemId: d.itemId, name: d.line.item_name_snapshot, qty: d.qty, price: rupees(Number(d.line.unit_price_paisa)), total: rupees(d.amount) })),
    };
  });
}

export async function listReturns(orderId?: string): Promise<Record<string, unknown>[]> {
  const rets = await q<any>(
    `SELECT * FROM sale_returns ${orderId ? "WHERE order_id = $1" : ""} ORDER BY created_at DESC LIMIT 500`,
    orderId ? [orderId] : []
  );
  const out: Record<string, unknown>[] = [];
  for (const r of rets) {
    const lines = await q<any>("SELECT * FROM sale_return_lines WHERE return_id = $1 ORDER BY name", [r.id]);
    out.push({
      id: r.id, orderId: r.order_id, billNo: r.bill_no, mode: r.shop_kind,
      refundMethod: r.refund_method, total: rupees(Number(r.total_paisa)),
      byName: r.by_name, createdAt: r.created_at,
      lines: lines.map((l) => ({ itemId: l.item_id ?? "", name: l.name, qty: Number(l.qty), price: rupees(Number(l.unit_price_paisa)), total: rupees(Number(l.line_total_paisa)) })),
    });
  }
  return out;
}
