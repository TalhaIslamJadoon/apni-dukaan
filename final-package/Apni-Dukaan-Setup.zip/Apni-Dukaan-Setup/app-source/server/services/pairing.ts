import crypto from "node:crypto";
import { q, one, ApiError } from "@/server/db";

// ── Print-agent AUTO-PAIRING (Talha, 18 Nov 2026) ─────────────────────
// Aam bande wala flow: agent bina token start → pairing request (PC ke
// naam ke sath) → Owner Dashboard → Printers & Devices mein "Jor dein"
// → server token bana kar request par rakh deta hai → agent apni poll
// par token utha kar KHUD config mein save kar leta hai. Client kabhi
// code nahi dekhta, kabhi JSON file nahi kholta.
// Request ka uuid hi us ka secret hai (sirf usi PC ko maloom hota hai
// jis ne request bheji). Token plain sirf collect hone tak rehta hai.
const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
const PENDING_TTL_MIN = 15;

export interface PairingRequestDTO {
  id: string; machineName: string; version: string | null;
  status: string; createdAt: string;
}

const dto = (r: any): PairingRequestDTO => ({
  id: r.id, machineName: r.machine_name ?? "", version: r.version ?? null,
  status: r.status, createdAt: new Date(r.created_at).toISOString(),
});

/** Agent ki taraf se: naya request, ya usi PC ka taza pending wapas. */
export async function createPairingRequest(machineName: string, version?: string) {
  const name = (machineName || "").trim().slice(0, 120) || "Shop PC";
  const existing = await one<any>(
    `SELECT * FROM agent_pairing_requests
      WHERE machine_name = $1 AND status = 'pending'
        AND created_at > now() - ($2 || ' minutes')::interval
      ORDER BY created_at DESC LIMIT 1`,
    [name, String(PENDING_TTL_MIN)]
  );
  if (existing) return dto(existing);
  const row = (await q<any>(
    "INSERT INTO agent_pairing_requests (machine_name, version) VALUES ($1,$2) RETURNING *",
    [name, version ?? null]
  ))[0];
  return dto(row);
}

/** Agent ki poll: halat; approved ho to token EK dafa de kar collected. */
export async function pollPairingRequest(id: string) {
  if (!/^[0-9a-f-]{36}$/i.test(id)) throw new ApiError(404, "NOT_FOUND", "Pairing request nahi mili");
  const row = await one<any>("SELECT * FROM agent_pairing_requests WHERE id = $1", [id]);
  if (!row) throw new ApiError(404, "NOT_FOUND", "Pairing request nahi mili");
  if (row.status === "approved" && row.token_plain) {
    await q("UPDATE agent_pairing_requests SET status = 'collected', token_plain = NULL WHERE id = $1 AND status = 'approved'", [id]);
    const agent = await one<any>("SELECT display_name FROM print_agents WHERE id = $1", [row.agent_id]);
    return { status: "approved", token: row.token_plain as string, agentName: agent?.display_name ?? row.machine_name };
  }
  if (row.status === "pending" && new Date(row.created_at).getTime() < Date.now() - PENDING_TTL_MIN * 60_000) {
    return { status: "expired" };
  }
  return { status: row.status as string };
}

/** Owner: pending (taza) requests ki list. */
export async function listPendingPairingRequests(): Promise<PairingRequestDTO[]> {
  const rows = await q<any>(
    `SELECT * FROM agent_pairing_requests
      WHERE status = 'pending' AND created_at > now() - ($1 || ' minutes')::interval
      ORDER BY created_at`,
    [String(PENDING_TTL_MIN)]
  );
  return rows.map(dto);
}

/** Owner: approve — print_agents row + token (hash server par, plain
 *  sirf is request par collect hone tak). */
export async function approvePairingRequest(id: string) {
  const row = await one<any>("SELECT * FROM agent_pairing_requests WHERE id = $1 AND status = 'pending'", [id]);
  if (!row) throw new ApiError(404, "NOT_FOUND", "Pending pairing request nahi mili (shayad time khatam ho gaya hai)");
  const displayName = (row.machine_name || "Counter PC").trim() || "Counter PC";
  const token = crypto.randomBytes(32).toString("hex");
  const existing = await q<any>("SELECT id FROM print_agents WHERE display_name = $1", [displayName]);
  let agentId: string;
  if (existing[0]) {
    agentId = existing[0].id;
    await q("UPDATE print_agents SET token_hash = $2, machine_name = $3, is_active = true WHERE id = $1",
      [agentId, sha256(token), row.machine_name]);
  } else {
    const ins = (await q<any>(
      "INSERT INTO print_agents (display_name, machine_name, token_hash, version) VALUES ($1,$2,$3,$4) RETURNING id",
      [displayName, row.machine_name, sha256(token), row.version ?? null]
    ))[0];
    agentId = ins.id;
  }
  await q("UPDATE agent_pairing_requests SET status = 'approved', agent_id = $2, token_plain = $3, decided_at = now() WHERE id = $1",
    [id, agentId, token]);
  return { id, status: "approved", agentName: displayName };
}

export async function rejectPairingRequest(id: string) {
  const upd = await q<any>(
    "UPDATE agent_pairing_requests SET status = 'rejected', decided_at = now() WHERE id = $1 AND status = 'pending' RETURNING id",
    [id]
  );
  if (!upd[0]) throw new ApiError(404, "NOT_FOUND", "Pending pairing request nahi mili");
  return { id, status: "rejected" };
}
