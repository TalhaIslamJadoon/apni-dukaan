// Counter Customers (Talha, 18 Nov 2026) — walk-in customer ka halka
// record: NAAM + MOBILE par banta hai, koi account/password/login NAHI.
// Cashier bill par naam+mobile likhta hai to us mobile ke saare bills is
// record se link ho jate hain; Dashboard → Customers mein poori history,
// Kul Khareed aur permanent-customer special discount (discount_pct)
// rehta hai. Online accounts (customers table) se bilkul alag cheez hai.
import type { PoolClient } from "pg";
import { q, one, rupees, ApiError } from "../db";

/** Mobile ko sirf digits mein normalize karein (spaces/dashes hatayein) —
 *  yahi record ki unique pehchan hai. */
export function normalizeMobile(raw: string): string {
  return (raw ?? "").replace(/\D/g, "");
}

export interface CounterCustomerDTO {
  id: string;
  name: string;
  mobile: string;
  discountPct: number;
  pointsBalance: number;
  createdAt: string;
  updatedAt: string;
}

function toDTO(r: any): CounterCustomerDTO {
  return {
    id: r.id,
    name: r.name,
    mobile: r.mobile,
    discountPct: Number(r.discount_pct ?? 0),
    pointsBalance: Number(r.points_balance ?? 0),
    createdAt: new Date(r.created_at).toISOString(),
    updatedAt: new Date(r.updated_at).toISOString(),
  };
}

/**
 * Order transaction ke andar: mobile diya ho to record banayein/update
 * karein (latest naam jeet-ta hai — lekin khaali naam purana naam nahi
 * mitata) aur us ki id wapas karein. Mobile na ho to null.
 */
export async function upsertCounterCustomer(
  c: PoolClient,
  name: string | undefined,
  mobileRaw: string | undefined
): Promise<string | null> {
  const mobile = normalizeMobile(mobileRaw ?? "");
  if (!mobile) return null;
  const cleanName = (name ?? "").trim();
  const r = await c.query(
    `INSERT INTO counter_customers (name, mobile) VALUES ($1, $2)
     ON CONFLICT (mobile) DO UPDATE SET
       name = CASE WHEN EXCLUDED.name <> '' THEN EXCLUDED.name ELSE counter_customers.name END,
       updated_at = now()
     RETURNING id`,
    [cleanName, mobile]
  );
  return r.rows[0].id as string;
}

/** Cleared = payment_status NULL (normal counter bills) ya 'confirmed'. */
const CLEARED = "(o.payment_status IS NULL OR o.payment_status = 'confirmed') AND o.status <> 'cancelled'";

/** Ek customer ka running summary — receipts ka loyalty block isi se
 *  banta hai: is bill समेत kul bills + kul khareed (cleared bills). */
export async function counterSummaryForOrder(order: {
  id?: string;
  counter_customer_id?: string | null;
  created_at?: unknown;
}): Promise<{ bills: number; totalSpent: number; pointsBalance: number } | null> {
  if (!order.counter_customer_id) return null;
  const upto = order.created_at ? new Date(order.created_at as string) : new Date();
  // NOTE: JS Date sirf milliseconds rakhta hai, DB timestamptz microseconds
  // — is liye "created_at <=" akela is bill ko khud kabhi kabhi exclude kar
  // deta tha. Apni order id hamesha shamil karein (OR o.id = $3).
  const r = await one<any>(
    `SELECT COUNT(*)::int AS bills, COALESCE(SUM(o.total_paisa), 0)::bigint AS total
     FROM orders o
     WHERE o.counter_customer_id = $1 AND ${CLEARED} AND (o.created_at <= $2 OR o.id = $3)`,
    [order.counter_customer_id, upto, order.id ?? null]
  );
  if (!r) return null;
  // Points balance is bill tak: Σ(earned − redeemed) usi as-of usool par.
  const pr = await one<any>(
    `SELECT COALESCE(SUM(points_earned - points_redeemed), 0)::bigint AS bal
     FROM orders o
     WHERE o.counter_customer_id = $1 AND ${CLEARED} AND (o.created_at <= $2 OR o.id = $3)`,
    [order.counter_customer_id, upto, order.id ?? null]
  );
  return { bills: Number(r.bills), totalSpent: rupees(Number(r.total)), pointsBalance: Number(pr?.bal ?? 0) };
}

/**
 * Loyalty points (Phase B1) — order transaction ke ANDAR chalti hai:
 * pehle redeem (cashier ne jo points lagaye, balance aur bill ki gunjaish
 * tak capped), phir final total par earn. Balance kabhi negative nahi.
 * Sirf counter bills par — aur sirf tab jab order ka payment cleared ho
 * (counter bills hamesha cleared hote hain; proof-pending online is mein
 * ata hi nahi kyunke ye sirf source=counter par bulti hai).
 * Wapas: is bill ke points figures (order row par likhne ke liye).
 */
export async function applyLoyaltyForOrder(
  c: PoolClient,
  args: {
    counterCustomerId: string;
    totalPaisaAfterDiscount: number; // manual/special discount ke BAAD ka total (points se pehle)
    pointsRedeemRequested: number;
  }
): Promise<{ pointsEarned: number; pointsRedeemed: number; pointsRedeemedPaisa: number; finalTotalPaisa: number; newBalance: number }> {
  const s = await c.query("SELECT loyalty_earn_rs, loyalty_point_value_rs FROM system_settings WHERE id = true");
  const earnRs = Math.max(0, Math.round(Number(s.rows[0]?.loyalty_earn_rs ?? 100)));
  const valueRs = Math.max(0, Math.round(Number(s.rows[0]?.loyalty_point_value_rs ?? 1)));
  const cur = await c.query("SELECT points_balance FROM counter_customers WHERE id = $1 FOR UPDATE", [args.counterCustomerId]);
  const balance = Number(cur.rows[0]?.points_balance ?? 0);

  let pointsRedeemed = 0;
  let pointsRedeemedPaisa = 0;
  if (valueRs > 0 && args.pointsRedeemRequested > 0 && balance > 0 && args.totalPaisaAfterDiscount > 0) {
    pointsRedeemed = Math.min(Math.floor(args.pointsRedeemRequested), balance);
    pointsRedeemedPaisa = Math.min(pointsRedeemed * valueRs * 100, args.totalPaisaAfterDiscount);
    // Paisay wali cap ki wajah se points bhi utne hi katein jitne istemal hue
    pointsRedeemed = Math.floor(pointsRedeemedPaisa / (valueRs * 100));
  }
  const finalTotalPaisa = args.totalPaisaAfterDiscount - pointsRedeemedPaisa;
  const pointsEarned = earnRs > 0 ? Math.floor(finalTotalPaisa / 100 / earnRs) : 0;
  const newBalance = balance - pointsRedeemed + pointsEarned;
  if (pointsRedeemed > 0 || pointsEarned > 0) {
    await c.query("UPDATE counter_customers SET points_balance = $2, updated_at = now() WHERE id = $1", [args.counterCustomerId, newBalance]);
  }
  return { pointsEarned, pointsRedeemed, pointsRedeemedPaisa, finalTotalPaisa, newBalance };
}

export interface CounterCustomerListRow extends CounterCustomerDTO {
  bills: number;
  totalSpent: number; // Rs — sirf cleared bills
  lastBillAt: string | null;
}

/** Dashboard → Customers: har record ke sath us ke aggregates. */
export async function listCounterCustomers(): Promise<CounterCustomerListRow[]> {
  const rows = await q<any>(
    `SELECT cc.*,
       COUNT(o.id)::int AS bills,
       COALESCE(SUM(CASE WHEN ${CLEARED} THEN o.total_paisa ELSE 0 END), 0)::bigint AS total,
       MAX(o.created_at) AS last_bill_at
     FROM counter_customers cc
     LEFT JOIN orders o ON o.counter_customer_id = cc.id
     GROUP BY cc.id
     ORDER BY cc.updated_at DESC`
  );
  return rows.map((r) => ({
    ...toDTO(r),
    bills: Number(r.bills),
    totalSpent: rupees(Number(r.total)),
    lastBillAt: r.last_bill_at ? new Date(r.last_bill_at).toISOString() : null,
  }));
}

/** Ek customer ki tafseel + us ke saare bills (bill DTOs — Receipt re-view
 *  ke liye mukammal lines ke sath) + rental bookings (lite rows). Ek hi
 *  record: dono dukaanon ke bills AUR bookings ek history mein. */
export async function getCounterCustomerDetail(id: string) {
  const r = await one<any>("SELECT * FROM counter_customers WHERE id = $1", [id]);
  if (!r) throw new ApiError(404, "CUSTOMER_NOT_FOUND", "Counter customer nahi mila");
  const { fetchOrdersDTO } = await import("../dto");
  const bills = await fetchOrdersDTO({ counterCustomerId: id, limit: 500 });
  const cleared = bills.filter((b: any) => b.paymentStatus === undefined || b.paymentStatus === "confirmed");
  const bookingRows = await q<any>(
    `SELECT booking_no, item_name, pickup_date, return_date, rent_total_paisa, status, created_at
     FROM rental_bookings WHERE counter_customer_id = $1 ORDER BY created_at DESC LIMIT 500`,
    [id]
  );
  const bookings = bookingRows.map((b) => ({
    bookingNo: String(b.booking_no),
    itemName: String(b.item_name),
    pickupDate: b.pickup_date ? new Date(b.pickup_date).toISOString().slice(0, 10) : "",
    returnDate: b.return_date ? new Date(b.return_date).toISOString().slice(0, 10) : "",
    rentTotal: rupees(Number(b.rent_total_paisa)),
    status: String(b.status),
    createdAt: new Date(b.created_at).toISOString(),
  }));
  return {
    customer: toDTO(r),
    bills,
    bookings,
    totals: {
      bills: cleared.length,
      totalSpent: cleared.reduce((s: number, b: any) => s + Number(b.total ?? 0), 0),
    },
  };
}

/** Owner: Dashboard se naya customer record haath se banayein.
 *  Duplicate-number guard: number pehle se ho to 409 — error mein
 *  maujooda customer ka naam bhi jata hai (UI wahi dikhati hai). */
export async function createCounterCustomer(input: { name?: string; mobile?: string; discountPct?: number }): Promise<CounterCustomerDTO> {
  const name = String(input.name ?? "").trim();
  const mobile = normalizeMobile(String(input.mobile ?? ""));
  if (!name) throw new ApiError(400, "NAME_REQUIRED", "Naam lazmi hai");
  if (!mobile) throw new ApiError(400, "MOBILE_REQUIRED", "Mobile number lazmi hai");
  const pct = input.discountPct !== undefined ? Number(input.discountPct) : 0;
  if (!Number.isFinite(pct) || pct < 0 || pct > 100) throw new ApiError(400, "BAD_DISCOUNT", "Discount 0 se 100 ke darmiyan hona chahiye");
  const existing = await one<any>("SELECT * FROM counter_customers WHERE mobile = $1", [mobile]);
  if (existing) {
    throw new ApiError(409, "DUPLICATE_MOBILE", `Ye number pehle se ${existing.name} ke naam par registered hai`, { existingName: existing.name, existingId: existing.id });
  }
  const r = await one<any>(
    "INSERT INTO counter_customers (name, mobile, discount_pct) VALUES ($1, $2, $3) RETURNING *",
    [name, mobile, pct]
  );
  return toDTO(r);
}

/** Owner: naam, mobile ya special discount % tabdeel karein. Mobile
 *  badla jaye aur wo kisi AUR record par ho to 409 duplicate guard. */
export async function updateCounterCustomer(
  id: string,
  patch: { name?: string; mobile?: string; discountPct?: number }
): Promise<CounterCustomerDTO> {
  const sets: string[] = [];
  const params: unknown[] = [];
  if (patch.name !== undefined) {
    const name = String(patch.name).trim();
    if (!name) throw new ApiError(400, "NAME_REQUIRED", "Naam khaali nahi ho sakta");
    params.push(name);
    sets.push(`name = $${params.length}`);
  }
  if (patch.mobile !== undefined) {
    const mobile = normalizeMobile(String(patch.mobile));
    if (!mobile) throw new ApiError(400, "MOBILE_REQUIRED", "Mobile number khaali nahi ho sakta");
    const existing = await one<any>("SELECT * FROM counter_customers WHERE mobile = $1 AND id <> $2", [mobile, id]);
    if (existing) {
      throw new ApiError(409, "DUPLICATE_MOBILE", `Ye number pehle se ${existing.name} ke naam par registered hai`, { existingName: existing.name, existingId: existing.id });
    }
    params.push(mobile);
    sets.push(`mobile = $${params.length}`);
  }
  if (patch.discountPct !== undefined) {
    const pct = Number(patch.discountPct);
    if (!Number.isFinite(pct) || pct < 0 || pct > 100) {
      throw new ApiError(400, "BAD_DISCOUNT", "Discount 0 se 100 ke darmiyan hona chahiye");
    }
    params.push(pct);
    sets.push(`discount_pct = $${params.length}`);
  }
  if (!sets.length) throw new ApiError(400, "NOTHING_TO_UPDATE", "Koi tabdeeli nahi bheji gayi");
  params.push(id);
  const r = await one<any>(
    `UPDATE counter_customers SET ${sets.join(", ")}, updated_at = now() WHERE id = $${params.length} RETURNING *`,
    params
  );
  if (!r) throw new ApiError(404, "CUSTOMER_NOT_FOUND", "Counter customer nahi mila");
  return toDTO(r);
}

export interface CounterCustomerSuggestion extends CounterCustomerDTO {
  bills: number;
}

/** Sell checkout picker: naam ya mobile ka partial match (as-you-type),
 *  har suggestion ke sath bills count + discount %. */
export async function searchCounterCustomers(query: string): Promise<CounterCustomerSuggestion[]> {
  const raw = (query ?? "").trim();
  if (!raw) return [];
  const digits = normalizeMobile(raw);
  const rows = await q<any>(
    `SELECT cc.*, COUNT(o.id)::int AS bills
     FROM counter_customers cc
     LEFT JOIN orders o ON o.counter_customer_id = cc.id
     WHERE cc.name ILIKE $1 OR ($2 <> '' AND cc.mobile LIKE '%' || $2 || '%')
     GROUP BY cc.id
     ORDER BY cc.updated_at DESC
     LIMIT 8`,
    [`%${raw}%`, digits]
  );
  return rows.map((r) => ({ ...toDTO(r), bills: Number(r.bills) }));
}
