// ─────────────────────────────────────────────────────────────────────────────
// Held Bills — Bill Hold / Suspend-Recall (FIXED-13, Talha, 20 Nov 2026).
// Counter (Sell + Canteen POS) par bill rok kar rakhna: customer gaya kuch
// lene, cashier dusre ko serve kare, phir wahi bill EXACT wapas khule.
// Held bill SALE NAHI hai: koi order record nahi, stock nahi katta, token
// nahi banta, Day Close / Reports / P&L / Customers par koi asar nahi —
// asar sirf tab jab bill recall ke baad aam payment flow se mukammal ho.
// Canteen aur grocery holds hamesha alag (mode column). Cap: 20 per mode.
// ─────────────────────────────────────────────────────────────────────────────
import { q, one, tx, ApiError, paisa, rupees } from "../db";
import { emit } from "../events";
import type { StaffPrincipal } from "../auth";

export const HELD_BILLS_CAP = 20;

function toDTO(r: any): Record<string, unknown> {
  return {
    id: r.id,
    mode: r.mode,
    label: r.label ?? "",
    itemCount: Number(r.item_count ?? 0),
    total: rupees(Number(r.total_paisa ?? 0)),
    staffName: r.staff_name ?? "",
    createdAt: r.created_at ? new Date(r.created_at).toISOString() : "",
    payload: r.payload ?? {},
  };
}

export async function listHeldBills(mode?: string): Promise<Record<string, unknown>[]> {
  const rows = mode
    ? await q<any>("SELECT * FROM held_bills WHERE mode = $1 ORDER BY created_at", [mode])
    : await q<any>("SELECT * FROM held_bills ORDER BY created_at");
  return rows.map(toDTO);
}

export async function createHeldBill(
  staff: StaffPrincipal,
  input: { mode?: string; label?: string; itemCount?: number; total?: number; payload?: unknown }
): Promise<Record<string, unknown>> {
  const mode = input.mode === "grocery" ? "grocery" : input.mode === "canteen" ? "canteen" : null;
  if (!mode) throw new ApiError(400, "HELD_BILL_MODE_REQUIRED", "Bill kis screen ka hai (canteen / grocery) — ye batana lazmi hai");
  if (!input.payload || typeof input.payload !== "object") {
    throw new ApiError(400, "HELD_BILL_PAYLOAD_REQUIRED", "Bill ka data (payload) lazmi hai");
  }
  return tx(async (c) => {
    const cnt = (await c.query("SELECT COUNT(*)::int AS n FROM held_bills WHERE mode = $1", [mode])).rows[0];
    if (Number(cnt?.n ?? 0) >= HELD_BILLS_CAP) {
      throw new ApiError(409, "HELD_BILLS_FULL",
        `Hold bills full hain (max ${HELD_BILLS_CAP}) — pehle ek purana hold bill recall ya khatam karein`);
    }
    const ins = (await c.query(
      `INSERT INTO held_bills (mode, label, item_count, total_paisa, payload, staff_id, staff_name)
       VALUES ($1, $2, $3, $4, $5::jsonb, $6, $7) RETURNING *`,
      [mode, (input.label ?? "").slice(0, 300), Math.max(0, Math.floor(input.itemCount ?? 0)),
       paisa(Math.max(0, Number(input.total ?? 0))), JSON.stringify(input.payload),
       staff.id, staff.name ?? ""]
    )).rows[0];
    await emit(c, "held_bills.changed", "held_bill", ins.id, {});
    return toDTO(ins);
  });
}

export async function deleteHeldBill(id: string): Promise<{ id: string }> {
  return tx(async (c) => {
    const del = (await c.query("DELETE FROM held_bills WHERE id = $1 RETURNING id", [id])).rows[0];
    if (!del) throw new ApiError(404, "HELD_BILL_NOT_FOUND", "Ye hold bill nahi mila — shayad pehle hi khatam ho chuka hai");
    await emit(c, "held_bills.changed", "held_bill", id, {});
    return { id };
  });
}

export async function countHeldBills(mode: string): Promise<number> {
  const r = await one<any>("SELECT COUNT(*)::int AS n FROM held_bills WHERE mode = $1", [mode]);
  return Number(r?.n ?? 0);
}
