// ─────────────────────────────────────────────────────────────────────────────
// Day Close / Z-Report (Phase B5) — Talha, 18 Nov 2026.
// Ek business date ke figures SERVER gin ta hai (orders + udhaar ledger +
// expenses + returns). Save karna sirf ek record hai — koi paisa move
// nahi hota, P&L par koi double-count asar nahi.
// Expected cash = cash bikri + cash wasooli − cash kharchay − cash refunds.
// Kharchay (expenses) hamesha cash-out ginay jate hain (un par payment
// method nahi hota) — guideline mein wazeh likha hai.
// ─────────────────────────────────────────────────────────────────────────────
import { q, one, ApiError, rupees } from "../db";
import type { StaffPrincipal } from "../auth";
import { waiterDailyFigures, recordWaiterPayment, type WaiterDailyLine } from "./waiters";

const CLEARED = "(o.payment_status IS NULL OR o.payment_status = 'confirmed') AND o.status <> 'cancelled'";

export interface DayFigures {
  date: string;
  billsCount: number;
  byMethod: Record<string, number>;
  cashSales: number;
  cashWasooli: number;
  cashExpenses: number;
  cashRefunds: number;
  expectedCash: number;
  udhaarGiven: number;
  udhaarReceived: number;
  expensesTotal: number;
  returnsTotal: number;
  // Waiter hisaab (FIXED-12): commission/service lines + cash-jama soorat.
  waiterLines: WaiterDailyLine[];
  waiterCollectedToday: number; // customers se waiter ke haath gaya
  waiterDepositedToday: number; // cashier ko jama hua (yehi galla cash hai)
  waiterPendingTotal: number; // abhi waiters ke paas (galla NAHI)
  waiterPaidToday: number; // aaj ada ki gayi service+commission
}

export async function dayFigures(date: string): Promise<DayFigures> {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new ApiError(400, "BAD_DATE", "Date YYYY-MM-DD format mein dein");
  // Shop-type scoping: band dukaan ke purane orders Z-report mein nahi
  // ginte (setup badalne ke baad bhi hisaab saaf rehta hai).
  const st = await one<any>("SELECT has_canteen, retail_type FROM system_settings WHERE id = true");
  const modes: string[] = [];
  if (st?.has_canteen) modes.push("canteen");
  if (st?.retail_type) modes.push("grocery");
  // orders par mode column NAHI hai — shop ki kind shops table se aati
  // hai (o.mode likhne par PostgreSQL use mode() aggregate samajh kar
  // "WITHIN GROUP is required" deta tha — Day Close hamesha 500).
  const modeFilter = modes.length ? `AND o.shop_id IN (SELECT id FROM shops WHERE kind = ANY($2::text[]))` : "AND false";
  const byMethodRows = await q<any>(
    `SELECT o.payment_method AS m, COUNT(*) AS n, COALESCE(SUM(o.total_paisa),0) AS s
     FROM orders o WHERE o.business_date = $1 AND ${CLEARED} ${modeFilter} GROUP BY o.payment_method`,
    modes.length ? [date, modes] : [date]
  );
  const byMethod: Record<string, number> = {};
  let billsCount = 0;
  for (const r of byMethodRows) { byMethod[r.m ?? "Cash"] = rupees(Number(r.s)); billsCount += Number(r.n); }
  // udhaar_ledger_entries par method column nahi — wasooli ki method
  // payments table se aati hai (payment entries payment_id se linked hain).
  const wasooli2 = await one<any>(
    `SELECT COALESCE(SUM(CASE WHEN p.method = 'cash' THEN -le.amount_paisa ELSE 0 END),0) AS cash_sum,
            COALESCE(SUM(-le.amount_paisa),0) AS total_sum
     FROM udhaar_ledger_entries le LEFT JOIN payments p ON p.id = le.payment_id
     WHERE le.entry_type = 'payment' AND (le.created_at AT TIME ZONE 'Asia/Karachi')::date = $1::date`,
    [date]
  );
  const expShops = [...modes, "both"];
  const exp = await one<any>("SELECT COALESCE(SUM(amount_paisa),0) AS s FROM expenses WHERE expense_date = $1::date AND shop = ANY($2::text[])", [date, expShops]);
  const rets = await q<any>(
    `SELECT refund_method, COALESCE(SUM(total_paisa),0) AS s FROM sale_returns
     WHERE (created_at AT TIME ZONE 'Asia/Karachi')::date = $1::date AND shop_kind = ANY($2::text[]) GROUP BY refund_method`,
    [date, modes]
  );
  let returnsTotal = 0, cashRefunds = 0;
  for (const r of rets) { returnsTotal += rupees(Number(r.s)); if (r.refund_method === "Cash") cashRefunds += rupees(Number(r.s)); }
  const cashSales = byMethod["Cash"] ?? 0;
  const cashWasooli = rupees(Number(wasooli2?.cash_sum ?? 0));
  const expensesTotal = rupees(Number(exp?.s ?? 0));
  // Waiter cash: cashSales mein waiter ki collections bhi shamil hain —
  // lekin galla mein sirf JAMashuda cash hai. Is liye expected cash se
  // aaj ki collections minus, aaj ki deposits plus. Waiter ke paas baqi
  // raqam alag line mein dikhti hai — farq mein chhupi shortage NAHI.
  const waiterLines = st?.has_canteen ? await waiterDailyFigures(date) : [];
  const waiterCollectedToday = waiterLines.reduce((s, l) => s + l.collectedToday, 0);
  const waiterDepositedToday = waiterLines.reduce((s, l) => s + l.depositedToday, 0);
  const waiterPendingTotal = waiterLines.reduce((s, l) => s + l.pendingDeposit, 0);
  const waiterPaidToday = waiterLines.reduce((s, l) => s + l.paidToday, 0);
  return {
    date,
    billsCount,
    byMethod,
    cashSales,
    cashWasooli,
    cashExpenses: expensesTotal,
    cashRefunds,
    expectedCash: cashSales + cashWasooli - expensesTotal - cashRefunds - waiterCollectedToday + waiterDepositedToday,
    udhaarGiven: byMethod["Udhaar"] ?? 0,
    udhaarReceived: rupees(Number(wasooli2?.total_sum ?? 0)),
    expensesTotal,
    returnsTotal,
    waiterLines,
    waiterCollectedToday,
    waiterDepositedToday,
    waiterPendingTotal,
    waiterPaidToday,
  };
}

export async function saveDayClose(date: string, countedCash: number, staff: StaffPrincipal, waiterPayouts: string[] = []): Promise<Record<string, unknown>> {
  // Day-end waiter payout (Talha, FIXED-12): "✔ Ada Kar Diya" wale har
  // waiter ka POORA baqaya (service + commission) pehle ada hota hai —
  // service portion bina expense (pass-through), commission portion
  // Expense ke sath. Phir figures ginay jate hain taa ke commission
  // kharcha aur adaigi dono isi close mein nazar aayein.
  let servicePaidNow = 0;
  let waiterPaidNow = 0;
  if (waiterPayouts.length) {
    const { waiterSummaries } = await import("./waiters");
    const sums = await waiterSummaries({ from: "0001-01-01", to: "9999-12-31" });
    for (const legacyId of waiterPayouts) {
      const s = sums.find((x) => x.staffId === legacyId);
      if (!s) continue;
      if (s.serviceBaqaya > 0) {
        await recordWaiterPayment(legacyId, { kind: "service", amountRs: s.serviceBaqaya, method: "cash", dateISO: date }, staff);
        servicePaidNow += s.serviceBaqaya; waiterPaidNow += s.serviceBaqaya;
      }
      if (s.commissionBaqaya > 0) {
        await recordWaiterPayment(legacyId, { kind: "commission", amountRs: s.commissionBaqaya, method: "cash", dateISO: date }, staff);
        waiterPaidNow += s.commissionBaqaya;
      }
    }
  }
  const f = await dayFigures(date);
  // Service adaigi galla se cash nikalti hai lekin Expense nahi banti —
  // expected cash se sirf is close par ada shuda service minus karein.
  const expectedCash = f.expectedCash - servicePaidNow;
  const farq = Math.round(countedCash) - expectedCash;
  const ins = await q<any>(
    `INSERT INTO day_closes (business_date, cashier_name, bills_count, by_method, cash_sales_paisa, cash_wasooli_paisa,
       cash_expenses_paisa, cash_refunds_paisa, expected_cash_paisa, counted_cash_paisa, farq_paisa,
       udhaar_given_paisa, udhaar_received_paisa, expenses_total_paisa, returns_total_paisa, waiter_paid_paisa)
     VALUES ($1::date,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) RETURNING id, created_at`,
    [date, staff.name, f.billsCount, JSON.stringify(f.byMethod), Math.round(f.cashSales * 100), Math.round(f.cashWasooli * 100),
     Math.round(f.cashExpenses * 100), Math.round(f.cashRefunds * 100), Math.round(expectedCash * 100), Math.round(countedCash * 100),
     Math.round(farq * 100), Math.round(f.udhaarGiven * 100), Math.round(f.udhaarReceived * 100), Math.round(f.expensesTotal * 100),
     Math.round(f.returnsTotal * 100), Math.round(waiterPaidNow * 100)]
  );
  return { id: ins[0].id, createdAt: ins[0].created_at, figures: { ...f, expectedCash }, countedCash: Math.round(countedCash), farq, waiterPaid: waiterPaidNow };
}

export async function listDayCloses(): Promise<Record<string, unknown>[]> {
  const rows = await q<any>("SELECT * FROM day_closes ORDER BY created_at DESC LIMIT 100");
  return rows.map((r) => ({
    id: r.id, date: r.business_date instanceof Date ? `${r.business_date.getFullYear()}-${String(r.business_date.getMonth() + 1).padStart(2, "0")}-${String(r.business_date.getDate()).padStart(2, "0")}` : String(r.business_date).slice(0, 10), cashierName: r.cashier_name, createdAt: r.created_at,
    billsCount: Number(r.bills_count), byMethod: r.by_method ?? {},
    cashSales: rupees(Number(r.cash_sales_paisa)), cashWasooli: rupees(Number(r.cash_wasooli_paisa)),
    cashExpenses: rupees(Number(r.cash_expenses_paisa)), cashRefunds: rupees(Number(r.cash_refunds_paisa)),
    expectedCash: rupees(Number(r.expected_cash_paisa)), countedCash: rupees(Number(r.counted_cash_paisa)),
    farq: rupees(Number(r.farq_paisa)), udhaarGiven: rupees(Number(r.udhaar_given_paisa)),
    udhaarReceived: rupees(Number(r.udhaar_received_paisa)), expensesTotal: rupees(Number(r.expenses_total_paisa)),
    returnsTotal: rupees(Number(r.returns_total_paisa)),
    waiterPaid: rupees(Number(r.waiter_paid_paisa ?? 0)),
  }));
}
