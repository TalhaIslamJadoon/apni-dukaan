// ─────────────────────────────────────────────────────────────────────────────
// FEEDBACK / SHIKAYAT / TAJWEEZ (Talha, FIXED-12) — table QR se aata hai,
// koi account nahi. Paanch categories ki alag ratings (taste, service,
// safai, speed, rates) — jo category bhari wahi average mein gin ti hai.
// Service rating us waiter se attach hoti hai jis ke order par feedback
// aaya (waiter_id) — us ki average Waiters view mein dikhti hai.
// ─────────────────────────────────────────────────────────────────────────────
import { q, one, ApiError } from "../db";
import type { StaffPrincipal } from "../auth";

export interface FeedbackInput {
  kind?: string;
  taste?: number | null; service?: number | null; cleanliness?: number | null;
  speed?: number | null; rates?: number | null; behaviour?: number | null;
  comment?: string;
  source?: string; tableNo?: number | null;
  customerName?: string; customerMobile?: string;
  waiterId?: string; orderId?: string;
  suggestionType?: string; itemName?: string;
}

const star = (v: unknown): number | null => {
  const n = Math.round(Number(v));
  return Number.isFinite(n) && n >= 1 && n <= 5 ? n : null;
};

export async function createFeedback(input: FeedbackInput): Promise<Record<string, unknown>> {
  const kind = input.kind === "complaint" || input.kind === "suggestion" ? input.kind : "feedback";
  const taste = star(input.taste), service = star(input.service), cleanliness = star(input.cleanliness);
  const speed = star(input.speed), rates = star(input.rates), behaviour = star(input.behaviour);
  const comment = String(input.comment ?? "").slice(0, 1000).trim();
  const anyRating = [taste, service, cleanliness, speed, rates, behaviour].some((x) => x !== null);
  if (kind === "complaint" && !comment) throw new ApiError(400, "COMMENT_REQUIRED", "Shikayat ke liye tafseel likhna lazmi hai");
  // Menu request par note ikhtiyari hai — item ka naam hi lazmi hai
  // (neeche ITEM_NAME_REQUIRED). Aam tajweez par tafseel lazmi rehti hai.
  if (kind === "suggestion" && !comment && input.suggestionType !== "menu_item") throw new ApiError(400, "COMMENT_REQUIRED", "Tajweez likhna lazmi hai");
  if (kind === "feedback" && !anyRating && !comment) throw new ApiError(400, "EMPTY_FEEDBACK", "Kam az kam ek rating ya apni ray likhein");
  const suggestionType = kind === "suggestion" && input.suggestionType === "menu_item" ? "menu_item" : "general";
  const itemName = String(input.itemName ?? "").slice(0, 120).trim();
  if (suggestionType === "menu_item" && !itemName) throw new ApiError(400, "ITEM_NAME_REQUIRED", "Konsi cheez menu mein add karwana hai — us ka naam likhein");
  let waiterUuid: string | null = null;
  if (input.waiterId) {
    const w = await one<any>("SELECT id FROM staff_users WHERE legacy_id = $1 AND is_waiter = true", [input.waiterId]);
    waiterUuid = w?.id ?? null;
  }
  let orderUuid: string | null = null;
  if (input.orderId) {
    const o = await one<any>("SELECT id, waiter_staff_id FROM orders WHERE id::text = $1", [input.orderId]).catch(() => null);
    if (o) { orderUuid = o.id; if (!waiterUuid) waiterUuid = o.waiter_staff_id ?? null; }
  }
  const rows = await q<any>(
    `INSERT INTO feedback (kind, taste_rating, service_rating, cleanliness_rating, speed_rating, rates_rating, behaviour_rating,
       comment, source, table_no, customer_name, customer_mobile, waiter_staff_id, order_id, suggestion_type, requested_item_name)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) RETURNING id, created_at`,
    [kind, taste, service, cleanliness, speed, rates, behaviour, comment,
     input.source === "online" ? "online" : "table",
     Number.isFinite(Number(input.tableNo)) && input.tableNo ? Math.round(Number(input.tableNo)) : null,
     String(input.customerName ?? "").slice(0, 80), String(input.customerMobile ?? "").slice(0, 20),
     waiterUuid, orderUuid, suggestionType, itemName]
  );
  return { id: rows[0].id, createdAt: rows[0].created_at };
}

export async function listFeedback(): Promise<Record<string, unknown>> {
  const rows = await q<any>(
    `SELECT f.*, w.display_name AS waiter_name FROM feedback f
     LEFT JOIN staff_users w ON w.id = f.waiter_staff_id
     ORDER BY f.created_at DESC LIMIT 300`
  );
  const avg = (key: string) => {
    const vals = rows.map((r) => r[key]).filter((v: unknown) => v !== null && v !== undefined) as number[];
    return vals.length ? Math.round((vals.reduce((s, v) => s + Number(v), 0) / vals.length) * 10) / 10 : null;
  };
  return {
    items: rows.map((r) => ({
      id: r.id, kind: r.kind,
      taste: r.taste_rating, service: r.service_rating, cleanliness: r.cleanliness_rating,
      speed: r.speed_rating, rates: r.rates_rating, behaviour: r.behaviour_rating,
      comment: r.comment, source: r.source, tableNo: r.table_no,
      customerName: r.customer_name, customerMobile: r.customer_mobile,
      waiterName: r.waiter_name ?? null, seen: r.seen,
      suggestionType: r.suggestion_type ?? "general", requestedItemName: r.requested_item_name ?? "",
      done: !!r.done,
      createdAt: r.created_at,
    })),
    averages: {
      taste: avg("taste_rating"), service: avg("service_rating"), cleanliness: avg("cleanliness_rating"),
      speed: avg("speed_rating"), rates: avg("rates_rating"), behaviour: avg("behaviour_rating"),
    },
    total: rows.length,
    unseenComplaints: rows.filter((r) => r.kind === "complaint" && !r.seen).length,
    unseenTotal: rows.filter((r) => !r.seen).length,
  };
}

export async function markFeedbackSeen(id: string, staff: StaffPrincipal): Promise<Record<string, unknown>> {
  void staff;
  const rows = await q<any>("UPDATE feedback SET seen = true WHERE id = $1 RETURNING id", [id]);
  if (!rows.length) throw new ApiError(404, "NOT_FOUND", "Feedback nahi mila");
  return { ok: true };
}

/** Menu request poora hua — item menu mein add ho gaya. */
export async function markFeedbackDone(id: string, staff: StaffPrincipal): Promise<Record<string, unknown>> {
  void staff;
  const rows = await q<any>("UPDATE feedback SET done = true, seen = true WHERE id = $1 RETURNING id", [id]);
  if (!rows.length) throw new ApiError(404, "NOT_FOUND", "Feedback nahi mila");
  return { ok: true };
}

export async function deleteFeedback(id: string, staff: StaffPrincipal): Promise<Record<string, unknown>> {
  void staff;
  const rows = await q<any>("DELETE FROM feedback WHERE id = $1 RETURNING id", [id]);
  if (!rows.length) throw new ApiError(404, "NOT_FOUND", "Feedback nahi mila");
  return { ok: true };
}
