// ─────────────────────────────────────────────────────────────────────────────
// LUCKY DRAW (Talha, FIXED-12) — haftawaar draw.
// Entries DERIVE hoti hain: cleared bill (payment_status NULL/confirmed,
// cancelled nahi) jiska total threshold+ ho AUR jis par customer record
// (counter customer) ya online account ka mobile ho. Anonymous bill entry
// nahi ban sakta. Jeeta hua order dobara pool mein nahi aata
// (lucky_draws.winner_order_id UNIQUE + NOT IN filter).
// Prize draw ke waqt chuna jata hai: kind 'deal' (active deal FREE) ya
// 'gift' (free text). Winner ka prize customer record par pending flag ki
// tarah dikhta hai jab tak staff "De Diya" mark na kare (status 'given') —
// deal prize par mark sirf note action hai, koi auto-billing nahi.
// ─────────────────────────────────────────────────────────────────────────────
import { q, one, tx, ApiError, rupees } from "../db";
import type { StaffPrincipal } from "../auth";

const CLEARED = "(o.payment_status IS NULL OR o.payment_status = 'confirmed') AND o.status <> 'cancelled'";

export interface LuckyEntry {
  orderId: string;
  billNo: string;
  name: string;
  mobile: string;
  total: number;
  date: string;
}

async function minBillPaisa(): Promise<number> {
  const s = await one<any>("SELECT lucky_draw_min_bill_paisa, lucky_draw_enabled FROM system_settings WHERE id = true");
  if (!s?.lucky_draw_enabled) throw new ApiError(409, "DRAW_OFF", "Lucky Draw abhi OFF hai — pehle Settings se ON karein");
  return Number(s.lucky_draw_min_bill_paisa ?? 50000);
}

export async function listEntries(from: string, to: string): Promise<LuckyEntry[]> {
  const min = await minBillPaisa();
  const rows = await q<any>(
    `SELECT o.id, (SELECT b.bill_no FROM bill_orders bo JOIN bills b ON b.id = bo.bill_id WHERE bo.order_id = o.id LIMIT 1) AS bill_no, o.total_paisa, o.business_date,
            COALESCE(cc.name, o.customer_name_snapshot, '') AS cname,
            COALESCE(cc.mobile, o.customer_mobile_snapshot) AS cmobile
     FROM orders o
     LEFT JOIN counter_customers cc ON cc.id = o.counter_customer_id
     WHERE ${CLEARED} AND o.total_paisa >= $3
       AND o.business_date >= $1::date AND o.business_date <= $2::date
       AND (o.counter_customer_id IS NOT NULL OR (o.customer_mobile_snapshot IS NOT NULL AND o.customer_mobile_snapshot <> ''))
       AND o.id NOT IN (SELECT winner_order_id FROM lucky_draws)
     ORDER BY o.created_at ASC`,
    [from, to, min]
  );
  return rows.map((r) => ({
    orderId: r.id, billNo: r.bill_no ?? "", name: r.cname ?? "", mobile: r.cmobile ?? "",
    total: rupees(Number(r.total_paisa)), date: r.business_date instanceof Date ? r.business_date.toISOString().slice(0, 10) : String(r.business_date).slice(0, 10),
  }));
}

export async function listDraws(): Promise<Record<string, unknown>[]> {
  const rows = await q<any>("SELECT * FROM lucky_draws ORDER BY created_at DESC LIMIT 100");
  return rows.map((r) => ({
    id: r.id, prizeKind: r.prize_kind, prizeDetail: r.prize_detail, dealId: r.deal_id,
    winnerOrderId: r.winner_order_id, winnerCustomerId: r.winner_counter_customer_id,
    winnerName: r.winner_name, winnerMobile: r.winner_mobile, winnerBillNo: r.winner_bill_no,
    poolFrom: r.pool_from ? String(r.pool_from).slice(0, 10) : null,
    poolTo: r.pool_to ? String(r.pool_to).slice(0, 10) : null,
    status: r.status, createdAt: r.created_at, givenAt: r.given_at,
  }));
}

/** Draw nikalein — transaction mein random pick; ek entry ek hi dafa
 *  jeet sakti hai (UNIQUE + NOT IN dono taraf se pakka). */
export async function runDraw(
  from: string, to: string,
  prize: { kind: "deal" | "gift"; detail: string; dealId?: string },
  staff: StaffPrincipal
): Promise<Record<string, unknown>> {
  const min = await minBillPaisa();
  if (!prize.detail?.trim()) throw new ApiError(400, "BAD_PRIZE", "Prize ki tafseel likhein (deal chunein ya gift likhein)");
  return await tx(async (c) => {
    const pick = await c.query<any>(
      `SELECT o.id, (SELECT b.bill_no FROM bill_orders bo JOIN bills b ON b.id = bo.bill_id WHERE bo.order_id = o.id LIMIT 1) AS bill_no, o.total_paisa, o.counter_customer_id,
              COALESCE(cc.name, o.customer_name_snapshot, '') AS cname,
              COALESCE(cc.mobile, o.customer_mobile_snapshot, '') AS cmobile
       FROM orders o
       LEFT JOIN counter_customers cc ON cc.id = o.counter_customer_id
       WHERE ${CLEARED} AND o.total_paisa >= $3
         AND o.business_date >= $1::date AND o.business_date <= $2::date
         AND (o.counter_customer_id IS NOT NULL OR (o.customer_mobile_snapshot IS NOT NULL AND o.customer_mobile_snapshot <> ''))
         AND o.id NOT IN (SELECT winner_order_id FROM lucky_draws)
       ORDER BY random() LIMIT 1 FOR UPDATE OF o`,
      [from, to, min]
    );
    const w = pick.rows[0];
    if (!w) throw new ApiError(400, "POOL_EMPTY", "Is period mein koi entry nahi — draw nahi ho sakta");
    let dealUuid: string | null = null;
    if (prize.kind === "deal" && prize.dealId) {
      const d = await c.query<any>("SELECT id FROM deals WHERE legacy_id = $1", [prize.dealId]);
      dealUuid = d.rows[0]?.id ?? null;
    }
    const ins = await c.query<any>(
      `INSERT INTO lucky_draws (prize_kind, prize_detail, deal_id, winner_order_id, winner_counter_customer_id,
         winner_name, winner_mobile, winner_bill_no, pool_from, pool_to)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
      [prize.kind, prize.detail.trim(), dealUuid, w.id, w.counter_customer_id ?? null,
       w.cname ?? "", w.cmobile ?? "", w.bill_no ?? "", from, to]
    );
    void staff;
    const r = ins.rows[0];
    return {
      id: r.id, prizeKind: r.prize_kind, prizeDetail: r.prize_detail,
      winnerName: r.winner_name, winnerMobile: r.winner_mobile, winnerBillNo: r.winner_bill_no,
      winnerTotal: rupees(Number(w.total_paisa)), status: r.status, createdAt: r.created_at,
    };
  });
}

/** Prize "De Diya" mark — Draw History AUR customer record dono jagah
 *  yahi ek status hai (shared). */
export async function markDrawGiven(drawId: string, staff: StaffPrincipal): Promise<Record<string, unknown>> {
  const rows = await q<any>(
    `UPDATE lucky_draws SET status = 'given', given_at = now(), given_by_staff_id = $2
     WHERE id = $1 AND status = 'pending' RETURNING id, status`,
    [drawId, staff.id]
  );
  if (!rows.length) throw new ApiError(404, "DRAW_NOT_FOUND", "Draw nahi mila ya prize pehle de diya gaya hai");
  return { ok: true };
}
