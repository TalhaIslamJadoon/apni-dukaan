"use client";

import { useEffect, useMemo, useState } from "react";
import TopBar from "@/components/TopBar";
import StaffGate from "@/components/StaffGate";
import { CanteenOnly } from "@/components/BusinessGate";
import Receipt from "@/components/Receipt";
import {
  Order, Deal, MenuItem, loadOrders, saveOrders, loadMenu, loadDeals, loadStaff,
  useShop, useStaffSession, isToday, isPaymentCleared, nextToken, adjustStockForOrder,
  normalizeMobile, dealOrderLine, fetchWaiterSummaries, confirmWaiterDepositApi,
  collectOrderPaymentApi, fetchMyWaiterSummary, type WaiterSummaryDTO,
} from "@/lib/store";

// ─────────────────────────────────────────────────────────────────────────────
// QR ORDERS (Talha, FIXED-12) — sirf TABLE-QR orders ki staff screen.
// Remote online-account orders yahan NAHI aate (wo Online Orders /
// Dashboard mein rehte hain) — no-mixing rule.
// Full view (Owner + Canteen Wala): bill, print, cash confirm, proof
// confirm/reject, waiter collection + jama, counter se table order entry.
// Serving view (Waiter — optional shared tablet): sirf serve/pick.
// Serve gate: DINE-IN serve hamesha (payment khana khanay ke baad);
// TAKEAWAY pick sirf bill clear hone par.
// ─────────────────────────────────────────────────────────────────────────────

const rs = (n: number) => `Rs ${Math.round(n).toLocaleString()}`;

function payChip(o: Order) {
  if (o.paymentStatus === "cash_pending") return { t: "💵 Cash — Counter par lena hai", bg: "#F59E0B" };
  if (o.paymentStatus === "proof_pending") return { t: "⏳ Online — Tasdeeq Baqi", bg: "#D97706" };
  if (o.paymentStatus === "rejected") return { t: "❌ Payment Reject", bg: "#DC2626" };
  if (o.collectedByName) return { t: `✅ Bill Clear — ${o.collectedByName} ne liya`, bg: "#16A34A" };
  return { t: "✅ Bill Clear", bg: "#16A34A" };
}

function QrOrdersScreen() {
  const shop = useShop();
  const member = useStaffSession();
  const [orders, setOrders] = useState<Order[]>([]);
  const [summaries, setSummaries] = useState<WaiterSummaryDTO[]>([]);
  const [mySummary, setMySummary] = useState<WaiterSummaryDTO | null>(null);
  const [billOrder, setBillOrder] = useState<Order | null>(null);
  const [msg, setMsg] = useState("");
  const fullView = !!member && (member.isOwner || member.tabs.includes("canteen"));

  function refresh() { setOrders(loadOrders()); }
  useEffect(() => {
    refresh();
    const t = setInterval(refresh, 1500);
    window.addEventListener("canteen-orders-changed", refresh);
    return () => { clearInterval(t); window.removeEventListener("canteen-orders-changed", refresh); };
  }, []);
  useEffect(() => {
    if (!member) return;
    if (fullView) { void fetchWaiterSummaries().then(setSummaries).catch(() => undefined); }
    else if (member.isWaiter) { void fetchMyWaiterSummary().then(setMySummary).catch(() => undefined); }
  }, [member?.id, fullView, orders.length]); // eslint-disable-line react-hooks/exhaustive-deps

  const tableOrders = useMemo(
    () => orders.filter((o) => isToday(o) && o.mode === "canteen" && o.identityType === "table")
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt)),
    [orders]
  );
  const active = tableOrders.filter((o) => o.status !== "completed");
  const done = tableOrders.filter((o) => o.status === "completed");
  const waiters = useMemo(() => loadStaff().filter((s) => s.isWaiter), [shop]); // eslint-disable-line react-hooks/exhaustive-deps
  const pendingOf = (staffId: string) => summaries.find((s) => s.staffId === staffId)?.pendingDeposit ?? 0;

  function patch(id: string, p: Partial<Order>) {
    const all = loadOrders().map((o) => (o.id === id ? { ...o, ...p } : o));
    saveOrders(all); setOrders(all);
  }
  function confirmProof(o: Order) {
    const all = loadOrders();
    const token = nextToken(all, o.mode);
    saveOrders(all.map((x) => (x.id === o.id ? { ...x, paymentStatus: "confirmed" as const, token, rejectReason: undefined } : x)));
    refresh();
  }
  function rejectProof(o: Order) {
    const reason = window.prompt("Reject ki wajah likhein — yeh customer ko dikhe gi:", "");
    if (reason === null) return;
    const all = loadOrders();
    const fresh = all.find((x) => x.id === o.id);
    if (fresh) adjustStockForOrder(fresh, 1);
    saveOrders(all.map((x) => (x.id === o.id ? { ...x, paymentStatus: "rejected" as const, rejectReason: reason.trim() || "Payment proof qabool nahi — sahi payment karke dobara proof upload karein" } : x)));
    refresh();
  }
  async function collect(o: Order, waiterId: string, depositNow: boolean) {
    setMsg("");
    try {
      await collectOrderPaymentApi(o, waiterId, depositNow);
      refresh();
      if (fullView) void fetchWaiterSummaries().then(setSummaries).catch(() => undefined);
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Collection save nahi ho saki");
    }
  }
  async function confirmDeposit(staffId: string, amount: number) {
    setMsg("");
    try {
      await confirmWaiterDepositApi(staffId, amount);
      void fetchWaiterSummaries().then(setSummaries).catch(() => undefined);
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Jama save nahi ho saka");
    }
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: "#FFF7ED" }}>
      <TopBar />
      <div className="px-4 py-2 flex items-center gap-2 flex-wrap" style={{ background: "#0F172A" }}>
        <span className="text-white font-black">📱 QR Orders — Table Orders</span>
        <span className="text-xs font-bold text-stone-300">Sirf table-QR orders · Remote online orders yahan nahi aate</span>
      </div>

      {fullView && summaries.some((s) => s.pendingDeposit > 0) && (
        <div className="mx-4 mt-3 bg-amber-50 border-2 border-amber-300 rounded-2xl p-3" data-testid="pending-deposits">
          <div className="font-black text-amber-800 mb-2">💵 Waiters ke paas cash — cashier ko jama karwana baqi</div>
          {summaries.filter((s) => s.pendingDeposit > 0).map((s) => (
            <DepositRow key={s.staffId} s={s} onConfirm={(amt) => void confirmDeposit(s.staffId, amt)} />
          ))}
        </div>
      )}
      {msg && <div className="mx-4 mt-3 rounded-xl px-3 py-2 font-bold text-white" style={{ background: "#DC2626" }} role="alert">{msg}</div>}

      {!fullView && mySummary && (
        <div className="mx-4 mt-3 bg-white border-2 border-orange-200 rounded-2xl p-3" data-testid="waiter-my-summary">
          <div className="font-black">🧾 Mera Hisaab — {mySummary.name}</div>
          <div className="grid grid-cols-2 gap-2 mt-2 text-sm">
            {(mySummary.payType === "commission" || mySummary.payType === "both") && (
              <div className="rounded-xl bg-orange-50 p-2"><div className="text-xs font-bold text-stone-500">AAJ KI COMMISSION</div><div className="text-lg font-black">{rs(mySummary.commissionToday)}</div></div>
            )}
            <div className="rounded-xl bg-orange-50 p-2"><div className="text-xs font-bold text-stone-500">AAJ KI SERVICE</div><div className="text-lg font-black">{rs(mySummary.serviceToday)}</div></div>
            <div className="rounded-xl bg-orange-50 p-2"><div className="text-xs font-bold text-stone-500">KUL BAQAYA (Service + Commission)</div><div className="text-lg font-black">{rs(mySummary.serviceBaqaya + mySummary.commissionBaqaya)}</div></div>
            {mySummary.pendingDeposit > 0 && (
              <div className="rounded-xl bg-amber-100 p-2"><div className="text-xs font-bold text-amber-700">CASHIER KO JAMA KARWANA BAQI</div><div className="text-lg font-black text-amber-800">{rs(mySummary.pendingDeposit)}</div></div>
            )}
            {(mySummary.payType === "salary" || mySummary.payType === "both") && (
              <div className="rounded-xl bg-orange-50 p-2"><div className="text-xs font-bold text-stone-500">TANKHWAH — {rs(mySummary.salaryAmount)}/mahina · Kul Ada</div><div className="text-lg font-black">{rs(mySummary.salaryPaidTotal)}</div></div>
            )}
          </div>
        </div>
      )}

      {fullView && (
        <EntryPanel
          waiters={waiters}
          pendingOf={pendingOf}
          onPlaced={() => { refresh(); void fetchWaiterSummaries().then(setSummaries).catch(() => undefined); }}
        />
      )}

      <main className="p-4 space-y-3 max-w-5xl w-full mx-auto">
        {active.length === 0 && <p className="text-center font-bold text-stone-500 py-8">Aaj koi table order nahi aaya.</p>}
        {active.map((o) => (
          <OrderCard key={o.id} o={o} fullView={fullView} waiters={waiters}
            onBill={() => setBillOrder(o)}
            onConfirmProof={() => confirmProof(o)}
            onRejectProof={() => rejectProof(o)}
            onCashClear={() => patch(o.id, { paymentStatus: "confirmed" })}
            onCollect={(wid, dep) => void collect(o, wid, dep)}
            onServe={() => patch(o.id, { status: "completed" })}
          />
        ))}
        {done.length > 0 && (
          <>
            <h3 className="font-black text-stone-500 pt-2">✅ Ho Gaye ({done.length})</h3>
            {done.map((o) => (
              <OrderCard key={o.id} o={o} fullView={fullView} waiters={waiters}
                onBill={() => setBillOrder(o)} onConfirmProof={() => undefined} onRejectProof={() => undefined}
                onCashClear={() => undefined} onCollect={() => undefined} onServe={() => undefined} />
            ))}
          </>
        )}
      </main>

      {billOrder && (
        <div className="fixed inset-0 z-50 bg-black/60 overflow-y-auto p-4">
          <div className="max-w-md mx-auto py-4 pop-in">
            <Receipt order={billOrder} />
            <div className="flex gap-2 mt-4 no-print">
              <button onClick={() => window.print()} className="flex-1 rounded-2xl py-3.5 font-black bg-white text-stone-900 shadow">🖨️ Print (80mm)</button>
              <button onClick={() => setBillOrder(null)} className="flex-1 rounded-2xl py-3.5 font-black text-white shadow" style={{ background: "#DC2626" }}>✕ Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function DepositRow({ s, onConfirm }: { s: WaiterSummaryDTO; onConfirm: (amt: number) => void }) {
  const [amt, setAmt] = useState(String(s.pendingDeposit));
  useEffect(() => { setAmt(String(s.pendingDeposit)); }, [s.pendingDeposit]);
  return (
    <div className="flex items-center gap-2 flex-wrap py-1" data-testid={`deposit-row-${s.staffId}`}>
      <span className="font-bold flex-1 min-w-[140px]">{s.name} — baqi {rs(s.pendingDeposit)}</span>
      <input value={amt} onChange={(e) => setAmt(e.target.value)} inputMode="numeric" aria-label={`${s.name} jama raqam`}
        className="w-28 rounded-lg border-2 border-amber-300 px-2 py-1.5 font-bold" />
      <button onClick={() => { const n = Number(amt); if (n > 0) onConfirm(n); }} data-testid={`deposit-confirm-${s.staffId}`}
        className="rounded-lg px-3 py-1.5 font-black text-white" style={{ background: "#16A34A" }}>✔ Jama Wasool Kar Liya</button>
    </div>
  );
}

function OrderCard({ o, fullView, waiters, onBill, onConfirmProof, onRejectProof, onCashClear, onCollect, onServe }: {
  o: Order; fullView: boolean; waiters: { id: string; name: string }[];
  onBill: () => void; onConfirmProof: () => void; onRejectProof: () => void;
  onCashClear: () => void; onCollect: (waiterId: string, depositNow: boolean) => void; onServe: () => void;
}) {
  const [collectWaiter, setCollectWaiter] = useState(o.waiterId ?? "");
  useEffect(() => { if (!collectWaiter && waiters.length) setCollectWaiter(o.waiterId ?? waiters[0].id); }, [waiters, o.waiterId]); // eslint-disable-line react-hooks/exhaustive-deps
  const chip = payChip(o);
  const cleared = isPaymentCleared(o);
  const isTakeaway = o.orderType !== "dine-in";
  const serveBlocked = isTakeaway && !cleared;
  const statusLabel = o.status === "completed" ? "✅ Serve/Pick Ho Gaya" : o.status === "ready" ? "🍽️ Taiyar" : o.status === "preparing" ? "👨‍🍳 Tayyar Ho Raha" : "🧾 Ordered";
  return (
    <div className="bg-white rounded-2xl border-2 border-orange-100 shadow-sm p-3" data-testid="qr-order-card">
      <div className="flex items-start justify-between gap-2 flex-wrap">
        <div>
          <span className="font-black text-lg">{o.orderType === "dine-in" ? `🍽️ Table ${o.tableNo}` : "🥡 Takeaway"}</span>
          <span className="ml-2 font-black rounded-full px-2 py-0.5 text-white text-sm" style={{ background: "#0F172A" }}>Token {o.token || "—"}</span>
          <span className="ml-2 text-xs font-black rounded-full px-2 py-0.5 text-white" style={{ background: "#334155" }}>{statusLabel}</span>
          <div className="text-sm font-bold text-stone-600">{o.customerName ?? o.counterName ?? "Customer"}{o.customerMobile || o.counterMobile ? ` · ${o.customerMobile ?? o.counterMobile}` : ""}</div>
          {o.waiterName && <div className="text-xs font-bold text-stone-500">🧑‍🍳 Waiter: {o.waiterName}</div>}
        </div>
        <div className="text-right">
          <div className="text-xl font-black" style={{ color: "#F97316" }}>{rs(o.total)}</div>
          <span className="text-[11px] font-black rounded-full px-2 py-0.5 text-white" style={{ background: chip.bg }}>{chip.t}</span>
        </div>
      </div>
      <ul className="mt-2 space-y-0.5 text-sm">
        {o.lines.map((l, i) => (
          <li key={`${l.itemId}-${i}`} className="flex justify-between border-b border-dashed border-stone-200 pb-0.5">
            <span>{l.name}{l.components?.length ? <span className="block text-xs text-stone-500">{l.components.map((c) => `${c.qty}× ${c.name}`).join(", ")}</span> : null}</span>
            <b>× {l.qty} · {rs(l.price * l.qty)}</b>
          </li>
        ))}
        {(o.waiterServiceRs ?? 0) > 0 && (
          <li className="flex justify-between border-b border-dashed border-stone-200 pb-0.5"><span>Service (Waiter)</span><b>{rs(o.waiterServiceRs ?? 0)}</b></li>
        )}
      </ul>

      {o.status !== "completed" && (
        <div className="flex gap-2 mt-3 flex-wrap">
          {fullView && <button onClick={onBill} data-testid="qr-bill-btn" className="rounded-xl px-3 py-2.5 font-black text-white" style={{ background: "#0F172A" }}>🧾 Bill</button>}
          {fullView && o.paymentStatus === "proof_pending" && (
            <>
              <button onClick={onConfirmProof} data-testid="qr-proof-confirm" className="rounded-xl px-3 py-2.5 font-black text-white" style={{ background: "#16A34A" }}>✅ Proof Confirm</button>
              <button onClick={onRejectProof} data-testid="qr-proof-reject" className="rounded-xl px-3 py-2.5 font-black text-white" style={{ background: "#DC2626" }}>❌ Reject</button>
            </>
          )}
          {fullView && o.paymentStatus === "cash_pending" && (
            <>
              <button onClick={onCashClear} data-testid="qr-cash-clear" className="rounded-xl px-3 py-2.5 font-black text-white" style={{ background: "#16A34A" }}>💵 Cash Mila — Bill Clear</button>
              {waiters.length > 0 && (
                <span className="flex gap-2 items-center flex-wrap rounded-xl border-2 border-amber-200 bg-amber-50 px-2 py-1">
                  <select value={collectWaiter} onChange={(e) => setCollectWaiter(e.target.value)} aria-label="Collection waiter"
                    className="rounded-lg border px-2 py-1.5 font-bold" data-testid="qr-collect-waiter">
                    {waiters.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
                  </select>
                  <button onClick={() => collectWaiter && onCollect(collectWaiter, false)} data-testid="qr-collect-leliya" className="rounded-lg px-2.5 py-1.5 font-black text-white" style={{ background: "#D97706" }}>Waiter ne customer se le liya</button>
                  <button onClick={() => collectWaiter && onCollect(collectWaiter, true)} data-testid="qr-collect-jama" className="rounded-lg px-2.5 py-1.5 font-black text-white" style={{ background: "#0F172A" }}>💵 Waiter Jama Karwaya</button>
                </span>
              )}
            </>
          )}
          {serveBlocked ? (
            <span className="flex items-center gap-2">
              <button disabled data-testid="qr-pick-btn" className="rounded-xl px-3 py-2.5 font-black text-white opacity-50" style={{ background: "#64748B" }}>📦 Pick Ho Gaya</button>
              <span className="font-black text-sm" style={{ color: "#DC2626" }} data-testid="qr-pick-blocked-note">⚠️ Pehle bill clear karein</span>
            </span>
          ) : (
            <button onClick={onServe} data-testid={isTakeaway ? "qr-pick-btn" : "qr-serve-btn"} className="rounded-xl px-3 py-2.5 font-black text-white" style={{ background: "#F97316" }}>
              {isTakeaway ? "📦 Pick Ho Gaya" : "🍽️ Serve Ho Gaya"}
            </button>
          )}
        </div>
      )}
    </div>
  );
}

function EntryPanel({ waiters, pendingOf, onPlaced }: {
  waiters: { id: string; name: string }[]; pendingOf: (id: string) => number; onPlaced: () => void;
}) {
  const shop = useShop();
  const [open, setOpen] = useState(false);
  const [tableNo, setTableNo] = useState(1);
  const [orderType, setOrderType] = useState<"dine-in" | "takeaway">("dine-in");
  const [custName, setCustName] = useState("");
  const [custMobile, setCustMobile] = useState("");
  const [waiterSel, setWaiterSel] = useState(""); // "" = Self Service
  const [cart, setCart] = useState<{ key: string; name: string; price: number; qty: number; itemId: string; deal?: Deal }[]>([]);
  const [gateMsg, setGateMsg] = useState("");
  const menu = loadMenu();
  const deals = loadDeals().filter((d) => d.active);
  const waiter = waiters.find((w) => w.id === waiterSel);
  const pending = waiter ? pendingOf(waiter.id) : 0;
  const subtotal = cart.reduce((s, l) => s + l.price * l.qty, 0);
  const service = waiter ? (shop.waiterServiceRs ?? 0) : 0;
  const total = subtotal + service;

  function addLine(key: string, name: string, price: number, itemId: string, deal?: Deal) {
    setCart((c) => {
      const ex = c.find((l) => l.key === key);
      if (ex) return c.map((l) => (l.key === key ? { ...l, qty: l.qty + 1 } : l));
      return [...c, { key, name, price, qty: 1, itemId, deal }];
    });
  }
  function place() {
    setGateMsg("");
    if (!custName.trim()) { setGateMsg("Customer ka naam lazmi hai"); return; }
    if (!cart.length) { setGateMsg("Pehle kam az kam ek item add karein"); return; }
    if (waiter && pending > 0) {
      setGateMsg(`⛔ ${waiter.name} pehle cashier ko ${rs(pending)} jama karwaye — us ke paas abhi pichla cash baqi hai, naya order nahi lag sakta`);
      return;
    }
    const lines = cart.map((l) => l.deal
      ? { ...dealOrderLine(l.deal, loadMenu(), l.qty), price: l.price }
      : { itemId: l.itemId, name: l.name, price: l.price, qty: l.qty });
    const mobileNorm = normalizeMobile(custMobile);
    const order: Order = {
      id: `o-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`,
      mode: "canteen", source: "online", identityType: "table",
      lines, subtotal, discount: 0, total,
      payment: "Cash", paymentStatus: "cash_pending",
      token: 0, status: "pending",
      createdAt: new Date().toISOString(),
      customerName: custName.trim(),
      orderType, tableNo: orderType === "dine-in" ? tableNo : undefined,
      ...(mobileNorm.length >= 10 ? { counterName: custName.trim(), counterMobile: mobileNorm, customerMobile: mobileNorm } : {}),
      ...(waiter ? {
        waiterId: waiter.id, waiterName: waiter.name,
        waiterPayType: (waiter as { payType?: string }).payType as Order["waiterPayType"],
        commissionMode: shop.waiterCommissionMode, commissionValue: shop.waiterCommissionValue,
        ...(service > 0 ? { waiterServiceRs: service } : {}),
      } : {}),
    };
    const all = [...loadOrders(), order];
    saveOrders(all);
    setCart([]); setCustName(""); setCustMobile(""); setOpen(false);
    onPlaced();
  }

  if (!open) {
    return (
      <div className="mx-4 mt-3">
        <button onClick={() => setOpen(true)} data-testid="qr-entry-open" className="w-full rounded-2xl py-3 font-black text-white" style={{ background: "#F97316" }}>➕ Table Order Lein (Counter se)</button>
      </div>
    );
  }
  return (
    <div className="mx-4 mt-3 bg-white border-2 border-orange-200 rounded-2xl p-3" data-testid="qr-entry-panel">
      <div className="font-black mb-2">➕ Table Order Lein</div>
      <div className="grid grid-cols-2 gap-2">
        <label className="block"><span className="text-[11px] font-black uppercase text-stone-500">Table Number</span>
          <select value={tableNo} onChange={(e) => setTableNo(Number(e.target.value))} data-testid="qr-entry-table" className="w-full rounded-lg border-2 border-orange-100 px-2 py-2 font-bold">
            {Array.from({ length: shop.tableCount || 8 }, (_, i) => i + 1).map((n) => <option key={n} value={n}>Table {n}</option>)}
          </select></label>
        <label className="block"><span className="text-[11px] font-black uppercase text-stone-500">Order Type</span>
          <select value={orderType} onChange={(e) => setOrderType(e.target.value as "dine-in" | "takeaway")} data-testid="qr-entry-type" className="w-full rounded-lg border-2 border-orange-100 px-2 py-2 font-bold">
            <option value="dine-in">🍽️ Dine-In</option><option value="takeaway">🥡 Takeaway</option>
          </select></label>
        <label className="block"><span className="text-[11px] font-black uppercase text-stone-500">Customer Name *</span>
          <input value={custName} onChange={(e) => setCustName(e.target.value)} data-testid="qr-entry-name" className="w-full rounded-lg border-2 border-orange-100 px-2 py-2 font-bold" placeholder="Customer ka naam" /></label>
        <label className="block"><span className="text-[11px] font-black uppercase text-stone-500">Mobile (ikhtiyari)</span>
          <input value={custMobile} onChange={(e) => setCustMobile(e.target.value)} data-testid="qr-entry-mobile" className="w-full rounded-lg border-2 border-orange-100 px-2 py-2 font-bold" placeholder="03001234567" /></label>
      </div>
      <label className="block mt-2"><span className="text-[11px] font-black uppercase text-stone-500">Waiter chunein</span>
        <select value={waiterSel} onChange={(e) => setWaiterSel(e.target.value)} data-testid="qr-entry-waiter" className="w-full rounded-lg border-2 border-orange-100 px-2 py-2 font-bold">
          <option value="">🙋 Self Service — koi waiter nahi</option>
          {waiters.map((w) => <option key={w.id} value={w.id}>{w.name}{pendingOf(w.id) > 0 ? ` — ⛔ ${rs(pendingOf(w.id))} jama baqi` : ""}</option>)}
        </select></label>
      {waiter && pending > 0 && (
        <p className="mt-1 font-black text-sm" style={{ color: "#DC2626" }} data-testid="qr-entry-gate-note">⛔ {waiter.name} pehle cashier ko {rs(pending)} jama karwaye, phir agla order milega</p>
      )}
      <div className="mt-3 grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-56 overflow-y-auto">
        {menu.map((m) => (
          <button key={m.id} onClick={() => addLine(m.id, `${m.emoji ?? ""} ${m.name}`, m.price, m.id)} data-testid={`qr-entry-item-${m.id}`}
            className="rounded-xl border-2 border-orange-100 px-2 py-2 text-left font-bold text-sm bg-orange-50/50">
            {m.emoji} {m.name}<span className="block text-xs" style={{ color: "#F97316" }}>{rs(m.price)}</span>
          </button>
        ))}
        {deals.map((d) => (
          <button key={d.id} onClick={() => addLine(`deal:${d.id}`, `🎁 ${d.name}`, d.price, `deal:${d.id}`, d)} data-testid={`qr-entry-deal-${d.id}`}
            className="rounded-xl border-2 border-red-200 px-2 py-2 text-left font-bold text-sm bg-red-50">
            🎁 {d.name}<span className="block text-xs" style={{ color: "#DC2626" }}>{rs(d.price)}</span>
          </button>
        ))}
      </div>
      {cart.length > 0 && (
        <ul className="mt-2 text-sm space-y-1">
          {cart.map((l) => (
            <li key={l.key} className="flex items-center gap-2 border-b border-dashed border-stone-200 pb-1">
              <span className="flex-1 font-bold">{l.name}</span>
              <button onClick={() => setCart((c) => c.map((x) => (x.key === l.key ? { ...x, qty: Math.max(0, x.qty - 1) } : x)).filter((x) => x.qty > 0))} className="px-2 font-black">−</button>
              <b>{l.qty}</b>
              <button onClick={() => addLine(l.key, l.name, l.price, l.itemId, l.deal)} className="px-2 font-black">+</button>
              <b className="w-20 text-right">{rs(l.price * l.qty)}</b>
            </li>
          ))}
        </ul>
      )}
      <div className="flex justify-between font-black mt-2 text-sm">
        <span>Subtotal {rs(subtotal)}{service > 0 ? ` · Service (Waiter) ${rs(service)}` : ""}</span><span>Total {rs(total)}</span>
      </div>
      {gateMsg && <p className="mt-2 font-black text-sm" style={{ color: "#DC2626" }} role="alert">{gateMsg}</p>}
      <div className="flex gap-2 mt-3">
        <button onClick={place} data-testid="qr-entry-place" className="flex-1 rounded-xl py-3 font-black text-white" style={{ background: "#16A34A" }}>✅ Order Lagayein</button>
        <button onClick={() => setOpen(false)} className="rounded-xl px-4 py-3 font-black text-white" style={{ background: "#64748B" }}>Band</button>
      </div>
    </div>
  );
}

export default function QrOrdersPage() {
  return (
    <StaffGate tab="qrorders">
      <CanteenOnly what="QR Orders">
        <QrOrdersScreen />
      </CanteenOnly>
    </StaffGate>
  );
}
