import { handler, ok, body } from "@/server/http";
import { createFeedback, type FeedbackInput } from "@/server/services/feedback";

export const dynamic = "force-dynamic";

// POST /api/v1/public/feedback — table QR / online page se feedback,
// shikayat ya tajweez. Koi login nahi; validation service mein hai.
export const POST = handler(async (req) => {
  const b = await body<FeedbackInput>(req);
  return ok(await createFeedback(b), 201);
});
