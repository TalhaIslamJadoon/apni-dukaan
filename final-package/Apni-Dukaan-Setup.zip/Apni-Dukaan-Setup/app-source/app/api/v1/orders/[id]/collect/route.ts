import { handler, ok, body } from "@/server/http";
import { getStaff, requireStaff } from "@/server/auth";
import { collectOrderPayment } from "@/server/services/orders";

export const dynamic = "force-dynamic";

// POST /api/v1/orders/:id/collect { waiterId, depositNow } — counter par
// waiter collection: bill clear (+ depositNow ho to cash cashier ke paas
// bhi darj). Staff only.
export const POST = handler(async (req, ctx: { params: Promise<{ id: string }> }) => {
  const { id } = await ctx.params;
  const staff = requireStaff(await getStaff(req));
  const b = await body<{ waiterId: string; depositNow?: boolean }>(req);
  return ok({ order: await collectOrderPayment(id, { waiterId: b.waiterId, depositNow: !!b.depositNow }, staff) });
});
