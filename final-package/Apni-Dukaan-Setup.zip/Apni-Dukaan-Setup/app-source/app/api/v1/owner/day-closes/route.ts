import { handler, ok, body } from "@/server/http";
import { getStaff, requireOwner } from "@/server/auth";
import { dayFigures, saveDayClose, listDayCloses } from "@/server/services/dayClose";

export const dynamic = "force-dynamic";

// GET /api/v1/owner/day-closes — history.
// GET /api/v1/owner/day-closes?date=YYYY-MM-DD — us date ke live figures.
export const GET = handler(async (req) => {
  requireOwner(await getStaff(req));
  const date = new URL(req.url).searchParams.get("date");
  if (date) return ok({ figures: await dayFigures(date) });
  return ok({ closes: await listDayCloses() });
});

// POST { date, countedCash, waiterPayouts? } — figures server dobara gin
// kar record save. waiterPayouts = "✔ Ada Kar Diya" marked waiter legacy
// ids: un ka poora baqaya (service + commission) close se pehle ada hota.
export const POST = handler(async (req) => {
  const staff = requireOwner(await getStaff(req));
  const input = await body<{ date: string; countedCash: number; waiterPayouts?: string[] }>(req);
  return ok({ close: await saveDayClose(input.date, Number(input.countedCash) || 0, staff, input.waiterPayouts ?? []) }, 201);
});
