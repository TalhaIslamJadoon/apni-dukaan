import { handler, ok } from "@/server/http";
import { getStaff, requireOwner } from "@/server/auth";
import { listReturns } from "@/server/services/returns";

export const dynamic = "force-dynamic";

// GET /api/v1/owner/returns[?orderId=] — returns ki list (Dashboard).
export const GET = handler(async (req) => {
  requireOwner(await getStaff(req));
  const orderId = new URL(req.url).searchParams.get("orderId") ?? undefined;
  return ok({ returns: await listReturns(orderId) });
});
