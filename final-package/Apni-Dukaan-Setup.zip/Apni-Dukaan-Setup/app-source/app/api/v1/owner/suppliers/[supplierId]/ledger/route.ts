import { handler, ok } from "@/server/http";
import { getStaff, requireOwner } from "@/server/auth";
import { supplierLedger } from "@/server/services/suppliers";

export const dynamic = "force-dynamic";

// GET — supplier ka poora khata (khareed + payments, running baqaya).
export const GET = handler(async (req, ctx: { params: Promise<{ supplierId: string }> }) => {
  requireOwner(await getStaff(req));
  const { supplierId } = await ctx.params;
  return ok(await supplierLedger(supplierId));
});
