import { handler, ok, body } from "@/server/http";
import { getStaff, requireOwner } from "@/server/auth";
import { listSuppliers, createSupplier } from "@/server/services/suppliers";

export const dynamic = "force-dynamic";

// GET /api/v1/owner/suppliers — har supplier ka baqaya + kul khareed.
export const GET = handler(async (req) => {
  requireOwner(await getStaff(req));
  return ok({ suppliers: await listSuppliers() });
});

// POST { name, mobile } — naya supplier (naam pehle se ho to wahi wapas).
export const POST = handler(async (req) => {
  requireOwner(await getStaff(req));
  const input = await body<{ name?: string; mobile?: string }>(req);
  return ok({ supplier: await createSupplier(input) }, 201);
});
