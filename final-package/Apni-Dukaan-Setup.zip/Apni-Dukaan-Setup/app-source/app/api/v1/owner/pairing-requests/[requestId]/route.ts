import { handler, ok, body } from "@/server/http";
import { ApiError } from "@/server/db";
import { getStaff, requireOwner } from "@/server/auth";
import { approvePairingRequest, rejectPairingRequest } from "@/server/services/pairing";

export const dynamic = "force-dynamic";

// POST /api/v1/owner/pairing-requests/:id { action: "approve" | "reject" }
export const POST = handler(async (req, ctx: { params: Promise<{ requestId: string }> }) => {
  requireOwner(await getStaff(req));
  const { requestId } = await ctx.params;
  const b = await body<{ action?: string }>(req);
  if (b.action === "approve") return ok(await approvePairingRequest(requestId));
  if (b.action === "reject") return ok(await rejectPairingRequest(requestId));
  throw new ApiError(400, "BAD_ACTION", "action approve ya reject dein");
});
