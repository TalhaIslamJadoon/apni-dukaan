import { handler, ok } from "@/server/http";
import { getStaff, requireOwner } from "@/server/auth";
import { listPendingPairingRequests } from "@/server/services/pairing";

export const dynamic = "force-dynamic";

// GET /api/v1/owner/pairing-requests — Dashboard ke pending cards ke liye.
export const GET = handler(async (req) => {
  requireOwner(await getStaff(req));
  return ok({ requests: await listPendingPairingRequests() });
});
