import { handler, ok, body } from "@/server/http";
import { getStaff, requireOwner } from "@/server/auth";
import { recordReward } from "@/server/services/bestStaff";

export const dynamic = "force-dynamic";

// POST /api/v1/owner/best-staff/reward — inaam record + cash par Expense.
export const POST = handler(async (req) => {
  const p = requireOwner(await getStaff(req));
  const b = await body(req);
  const r = await recordReward(
    {
      month: String(b.month ?? ""), staffId: String(b.staffId ?? ""), category: String(b.category ?? ""),
      avgRating: Number(b.avgRating) || 0, ratingsCount: Number(b.ratingsCount) || 0,
      rewardKind: b.rewardKind === "gift" ? "gift" : "cash",
      amountRs: b.amountRs != null ? Number(b.amountRs) : undefined,
      giftText: b.giftText != null ? String(b.giftText) : undefined,
    },
    p
  );
  return ok(r, 201);
});
