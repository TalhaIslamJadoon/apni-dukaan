import { handler, ok, body } from "@/server/http";
import { getStaff, requireOwner } from "@/server/auth";
import { listCounterCustomers, createCounterCustomer } from "@/server/services/counterCustomers";

export const dynamic = "force-dynamic";

// GET /api/v1/owner/counter-customers — walk-in customers ki list, har
// record ke sath kul bills / kul khareed / akhri bill (owner only).
export const GET = handler(async (req) => {
  requireOwner(await getStaff(req));
  return ok({ customers: await listCounterCustomers() });
});

// POST /api/v1/owner/counter-customers — naya record haath se banayein.
// Number pehle se registered ho to 409 DUPLICATE_MOBILE (naam ke sath).
export const POST = handler(async (req) => {
  requireOwner(await getStaff(req));
  const input = await body<{ name?: string; mobile?: string; discountPct?: number }>(req);
  return ok({ customer: await createCounterCustomer(input) }, 201);
});
