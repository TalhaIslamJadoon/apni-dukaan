import { handler, ok, body } from "@/server/http";
import { getStaff, requireOwner } from "@/server/auth";
import { runDraw } from "@/server/services/luckyDraw";

export const dynamic = "force-dynamic";

// POST /api/v1/owner/lucky-draw/draw { from, to, prizeKind, prizeDetail, dealId? }
export const POST = handler(async (req) => {
  const staff = requireOwner(await getStaff(req));
  const b = await body<{ from: string; to: string; prizeKind: "deal" | "gift"; prizeDetail: string; dealId?: string }>(req);
  const winner = await runDraw(b.from, b.to, { kind: b.prizeKind === "deal" ? "deal" : "gift", detail: b.prizeDetail, dealId: b.dealId }, staff);
  return ok({ winner }, 201);
});
