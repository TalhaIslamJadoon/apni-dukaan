import { handler, ok } from "@/server/http";
import { getStaff, requireOwner } from "@/server/auth";
import { markDrawGiven } from "@/server/services/luckyDraw";

export const dynamic = "force-dynamic";

// PATCH /api/v1/owner/lucky-draw/draws/:id — prize "De Diya" mark
// (Draw History + customer record — ek hi shared status).
export const PATCH = handler(async (req, ctx: { params: Promise<{ id: string }> }) => {
  const staff = requireOwner(await getStaff(req));
  const { id } = await ctx.params;
  return ok(await markDrawGiven(id, staff));
});
