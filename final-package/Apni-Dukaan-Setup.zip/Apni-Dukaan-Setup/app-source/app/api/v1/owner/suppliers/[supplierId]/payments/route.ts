import { handler, ok, body } from "@/server/http";
import { getStaff, requireOwner } from "@/server/auth";
import { recordSupplierPayment } from "@/server/services/suppliers";

export const dynamic = "force-dynamic";

// POST { amount (Rs), method, note } — supplier ko payment.
export const POST = handler(async (req, ctx: { params: Promise<{ supplierId: string }> }) => {
  const staff = requireOwner(await getStaff(req));
  const { supplierId } = await ctx.params;
  const input = await body<{ amount: number; method?: string; note?: string }>(req);
  return ok(await recordSupplierPayment(supplierId, input, staff));
});
