import { handler, ok, body } from "@/server/http";
import { tx } from "@/server/db";
import { getStaff, requireOwner } from "@/server/auth";
import { shopSettingsDTO } from "@/server/dto";
import { emit, audit } from "@/server/events";
import { applyRetailTemplate } from "@/server/services/templates";

export const dynamic = "force-dynamic";

// GET/PATCH /api/v1/owner/settings — Shop Settings (names, payment numbers,
// wholesale minimum defaults). Owner only.
export const GET = handler(async (req) => {
  requireOwner(await getStaff(req));
  return ok({ settings: await shopSettingsDTO() });
});

export const PATCH = handler(async (req) => {
  const staff = requireOwner(await getStaff(req));
  const b = await body<{
    collegeName?: string; canteenName?: string; groceryName?: string;
    jazzcashNumber?: string; easypaisaNumber?: string; raastInfo?: string;
    wholesaleMinPieces?: number; wholesaleMinKg?: number;
    shopOpen?: boolean; closedContactNumber?: string;
    tableCount?: number;
    hasCanteen?: boolean; retailType?: string | null; setupDone?: boolean;
    boardColor?: string;
    rentalsEnabled?: boolean; rentalLateFinePerDay?: number;
    loyaltyEarnRs?: number; loyaltyPointValueRs?: number; lowStockDefault?: number;
    waiterCommissionMode?: string; waiterCommissionValue?: number; waiterServiceRs?: number;
    luckyDrawEnabled?: boolean; luckyDrawMinBill?: number;
    luckyDrawDay?: string; luckyDrawTime?: string; luckyDrawPrizeKind?: string;
    luckyDrawPrizeText?: string; luckyDrawDealId?: string;
  }>(req);
  // Board rang sirf saaf #RRGGBB hex ho to hi save ho — warna purana rang.
  const boardColor = b.boardColor !== undefined && /^#[0-9a-f]{6}$/i.test(b.boardColor.trim())
    ? b.boardColor.trim() : null;
  // Tables are 1..100 — clamp whatever arrives to the sane range.
  const tableCount = b.tableCount === undefined
    ? null
    : Math.min(100, Math.max(1, Math.round(Number(b.tableCount) || 8)));
  let template: { applied: boolean; reason?: string } | undefined;
  await tx(async (c) => {
    await c.query(
      `UPDATE system_settings SET
         college_name = COALESCE($1, college_name),
         jazzcash_number = COALESCE($2, jazzcash_number),
         easypaisa_number = COALESCE($3, easypaisa_number),
         raast_info = COALESCE($4, raast_info),
         wholesale_min_pieces = COALESCE($5, wholesale_min_pieces),
         wholesale_min_kg = COALESCE($6, wholesale_min_kg),
         shop_open = COALESCE($7, shop_open),
         closed_contact_number = COALESCE($8, closed_contact_number),
         table_count = COALESCE($9, table_count),
         has_canteen = COALESCE($10, has_canteen),
         retail_type = CASE WHEN $11 THEN $12 ELSE retail_type END,
         setup_done = COALESCE($13, setup_done),
         board_color = COALESCE($14, board_color),
         rentals_enabled = COALESCE($15, rentals_enabled),
         rental_late_fine_per_day_paisa = COALESCE($16, rental_late_fine_per_day_paisa),
         loyalty_earn_rs = COALESCE($17, loyalty_earn_rs),
         loyalty_point_value_rs = COALESCE($18, loyalty_point_value_rs),
         low_stock_default = COALESCE($19, low_stock_default),
         waiter_commission_mode = COALESCE($20, waiter_commission_mode),
         waiter_commission_value = COALESCE($21, waiter_commission_value),
         waiter_service_paisa = COALESCE($22, waiter_service_paisa),
         lucky_draw_enabled = COALESCE($23, lucky_draw_enabled),
         lucky_draw_min_bill_paisa = COALESCE($24, lucky_draw_min_bill_paisa),
         lucky_draw_day = COALESCE($25, lucky_draw_day),
         lucky_draw_time = COALESCE($26, lucky_draw_time),
         lucky_draw_prize_kind = COALESCE($27, lucky_draw_prize_kind),
         lucky_draw_prize_text = COALESCE($28, lucky_draw_prize_text),
         lucky_draw_deal_legacy_id = CASE WHEN $29 THEN $30 ELSE lucky_draw_deal_legacy_id END,
         best_staff_min_ratings = COALESCE($31, best_staff_min_ratings),
         updated_at = now() WHERE id = true`,
      [b.collegeName ?? null, b.jazzcashNumber ?? null, b.easypaisaNumber ?? null, b.raastInfo ?? null,
       b.wholesaleMinPieces ?? null, b.wholesaleMinKg ?? null,
       b.shopOpen === undefined ? null : b.shopOpen, b.closedContactNumber ?? null,
       tableCount,
       b.hasCanteen === undefined ? null : b.hasCanteen,
       b.retailType !== undefined, b.retailType ?? null,
       b.setupDone === undefined ? null : b.setupDone,
       boardColor,
       b.rentalsEnabled === undefined ? null : b.rentalsEnabled,
       b.rentalLateFinePerDay === undefined ? null : Math.max(0, Math.round(Number(b.rentalLateFinePerDay) || 0)) * 100,
       b.loyaltyEarnRs === undefined ? null : Math.max(0, Math.round(Number(b.loyaltyEarnRs) || 0)),
       b.loyaltyPointValueRs === undefined ? null : Math.max(0, Math.round(Number(b.loyaltyPointValueRs) || 0)),
       b.lowStockDefault === undefined ? null : Math.max(0, Math.round(Number(b.lowStockDefault) || 0)),
       b.waiterCommissionMode === undefined ? null : (b.waiterCommissionMode === "fixed" ? "fixed" : "percent"),
       b.waiterCommissionValue === undefined ? null : Math.max(0, Number(b.waiterCommissionValue) || 0),
       b.waiterServiceRs === undefined ? null : Math.max(0, Math.round(Number(b.waiterServiceRs) || 0)) * 100,
       b.luckyDrawEnabled === undefined ? null : b.luckyDrawEnabled,
       b.luckyDrawMinBill === undefined ? null : Math.max(0, Math.round(Number(b.luckyDrawMinBill) || 0)) * 100,
       b.luckyDrawDay ?? null, b.luckyDrawTime ?? null,
       b.luckyDrawPrizeKind === undefined ? null : (b.luckyDrawPrizeKind === "deal" ? "deal" : "gift"),
       b.luckyDrawPrizeText ?? null,
       b.luckyDrawDealId !== undefined, b.luckyDrawDealId ?? null,
       (b as { bestStaffMinRatings?: number }).bestStaffMinRatings == null ? null : Math.max(1, Math.round(Number((b as { bestStaffMinRatings?: number }).bestStaffMinRatings) || 5))]
    );
    // Business Setup confirm: a retail type was chosen → us template ka
    // seed try karein (guard andar hai: data save ho chuka ho to sirf
    // view badalta hai, catalogue ko haath nahi lagta).
    if (b.setupDone === true && typeof b.retailType === "string" && b.retailType) {
      template = await applyRetailTemplate(c, b.retailType);
    }
    // Keep dining_tables in sync with the count: activate/create 1..N for
    // the canteen, DEACTIVATE (never delete) tables above N — past orders
    // and bills keep their historical table rows untouched.
    if (tableCount !== null) {
      await c.query(
        `INSERT INTO dining_tables (shop_id, table_no, label, is_active)
         SELECT s.id, g, 'Table ' || g, true
         FROM shops s CROSS JOIN generate_series(1, $1::int) AS g
         WHERE s.kind = 'canteen'
         ON CONFLICT (shop_id, table_no) DO UPDATE SET is_active = true, updated_at = now()`,
        [tableCount]
      );
      await c.query(
        `UPDATE dining_tables SET is_active = false, updated_at = now()
         WHERE shop_id = (SELECT id FROM shops WHERE kind = 'canteen') AND table_no > $1`,
        [tableCount]
      );
    }
    if (b.canteenName) await c.query("UPDATE shops SET display_name = $1, updated_at = now() WHERE kind = 'canteen'", [b.canteenName]);
    if (b.groceryName) await c.query("UPDATE shops SET display_name = $1, updated_at = now() WHERE kind = 'grocery'", [b.groceryName]);
    await emit(c, "settings.changed", "settings", null, {});
    if (template?.applied) await emit(c, "catalog.changed", "catalog", null, {});
    await audit(c, { type: "staff", staffId: staff.id }, "settings.update", "settings", null, b as Record<string, unknown>);
  });
  return ok({ settings: await shopSettingsDTO(), ...(template ? { template } : {}) });
});
