import { handler, ok, body } from "@/server/http";
import { getStaff, requireOwner } from "@/server/auth";
import { getCounterCustomerDetail, updateCounterCustomer } from "@/server/services/counterCustomers";

export const dynamic = "force-dynamic";

// GET /api/v1/owner/counter-customers/:id — customer + us ke saare bills.
export const GET = handler(async (req, ctx: { params: Promise<{ customerId: string }> }) => {
  requireOwner(await getStaff(req));
  const { customerId } = await ctx.params;
  return ok(await getCounterCustomerDetail(customerId));
});

// PATCH /api/v1/owner/counter-customers/:id — naam ya permanent-customer
// special discount % (0–100) tabdeel karein.
export const PATCH = handler(async (req, ctx: { params: Promise<{ customerId: string }> }) => {
  requireOwner(await getStaff(req));
  const { customerId } = await ctx.params;
  const input = await body<{ name?: string; mobile?: string; discountPct?: number }>(req);
  return ok({ customer: await updateCounterCustomer(customerId, input) });
});
