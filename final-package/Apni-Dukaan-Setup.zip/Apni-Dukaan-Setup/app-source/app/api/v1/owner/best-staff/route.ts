import { handler, ok } from "@/server/http";
import { getStaff, requireOwner } from "@/server/auth";
import { bestStaffLeaderboard, listRewards } from "@/server/services/bestStaff";

export const dynamic = "force-dynamic";

// GET /api/v1/owner/best-staff?month=YYYY-MM — leaderboard + reward history.
export const GET = handler(async (req) => {
  requireOwner(await getStaff(req));
  const url = new URL(req.url);
  const month = url.searchParams.get("month") || new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Karachi" }).slice(0, 7);
  const [rows, history] = await Promise.all([bestStaffLeaderboard(month), listRewards()]);
  return ok({ month, rows, history });
});
