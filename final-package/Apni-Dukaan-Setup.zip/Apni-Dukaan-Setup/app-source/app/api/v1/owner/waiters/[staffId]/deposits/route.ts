import { handler, ok, body } from "@/server/http";
import { getStaff, requireStaff } from "@/server/auth";
import { recordWaiterDeposit } from "@/server/services/waiters";

export const dynamic = "force-dynamic";

// POST /api/v1/owner/waiters/:staffId/deposits — cashier/owner ne waiter
// se cash wasool kar liya (full ya partial).
export const POST = handler(async (req, ctx: { params: Promise<{ staffId: string }> }) => {
  const staff = requireStaff(await getStaff(req), "canteen");
  const { staffId } = await ctx.params;
  const b = await body<{ amount: number }>(req);
  return ok(await recordWaiterDeposit(staffId, { amountRs: b.amount }, staff));
});
