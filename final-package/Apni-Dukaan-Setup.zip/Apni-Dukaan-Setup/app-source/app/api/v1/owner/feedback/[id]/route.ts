import { handler, ok, body } from "@/server/http";
import { getStaff, requireOwner } from "@/server/auth";
import { markFeedbackSeen, markFeedbackDone, deleteFeedback } from "@/server/services/feedback";

export const dynamic = "force-dynamic";

// PATCH { seen: true } | { done: true } — owner only.
export const PATCH = handler(async (req, ctx: { params: Promise<{ id: string }> }) => {
  const staff = requireOwner(await getStaff(req));
  const { id } = await ctx.params;
  const b = await body<{ seen?: boolean; done?: boolean }>(req);
  if (b.done) return ok(await markFeedbackDone(id, staff));
  return ok(await markFeedbackSeen(id, staff));
});

// DELETE — owner only.
export const DELETE = handler(async (req, ctx: { params: Promise<{ id: string }> }) => {
  const staff = requireOwner(await getStaff(req));
  const { id } = await ctx.params;
  return ok(await deleteFeedback(id, staff));
});
