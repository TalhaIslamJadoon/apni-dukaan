import { handler, ok } from "@/server/http";
import { getStaff, requireOwner } from "@/server/auth";
import { listEntries, listDraws } from "@/server/services/luckyDraw";

export const dynamic = "force-dynamic";

// GET /api/v1/owner/lucky-draw?from&to — pool ki entries + draw history.
export const GET = handler(async (req) => {
  requireOwner(await getStaff(req));
  const u = new URL(req.url);
  const from = u.searchParams.get("from") ?? "0001-01-01";
  const to = u.searchParams.get("to") ?? "9999-12-31";
  let entries: Awaited<ReturnType<typeof listEntries>> = [];
  let entriesError = "";
  try { entries = await listEntries(from, to); } catch (e) { entriesError = e instanceof Error ? e.message : ""; }
  return ok({ entries, entriesError, draws: await listDraws() });
});
