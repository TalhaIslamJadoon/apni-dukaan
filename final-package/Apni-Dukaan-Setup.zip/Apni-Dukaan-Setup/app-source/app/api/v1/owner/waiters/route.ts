import { handler, ok } from "@/server/http";
import { ApiError } from "@/server/db";
import { getStaff, requireStaff } from "@/server/auth";
import { waiterSummaries } from "@/server/services/waiters";

export const dynamic = "force-dynamic";

// GET /api/v1/owner/waiters?from=YYYY-MM-DD&to=YYYY-MM-DD — har waiter ka
// hisaab (service + commission + tankhwah + cash-jama). Default: kul.
// Owner + canteen staff (QR Orders screen ko pending-jama lines chahiye).
export const GET = handler(async (req) => {
  const s = requireStaff(await getStaff(req));
  if (!s.isOwner && !s.tabs.includes("canteen") && !s.tabs.includes("owner")) {
    throw new ApiError(403, "FORBIDDEN", "Is ka access nahi hai");
  }
  const u = new URL(req.url);
  const from = u.searchParams.get("from") ?? "0001-01-01";
  const to = u.searchParams.get("to") ?? "9999-12-31";
  return ok({ waiters: await waiterSummaries({ from, to }) });
});
