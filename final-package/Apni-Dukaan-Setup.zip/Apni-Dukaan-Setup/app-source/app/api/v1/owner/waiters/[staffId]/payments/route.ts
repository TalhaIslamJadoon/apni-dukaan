import { handler, ok, body } from "@/server/http";
import { getStaff, requireOwner } from "@/server/auth";
import { recordWaiterPayment } from "@/server/services/waiters";

export const dynamic = "force-dynamic";

// POST /api/v1/owner/waiters/:staffId/payments — commission / service /
// tankhwah adaigi (owner only). Commission+Tankhwah par Expense bhi banta
// hai; Service pass-through hai, expense NAHI.
export const POST = handler(async (req, ctx: { params: Promise<{ staffId: string }> }) => {
  const staff = requireOwner(await getStaff(req));
  const { staffId } = await ctx.params;
  const b = await body<{ kind: "commission" | "salary" | "service"; amount: number; method?: string; monthLabel?: string }>(req);
  return ok(await recordWaiterPayment(staffId, { kind: b.kind, amountRs: b.amount, method: b.method, monthLabel: b.monthLabel }, staff));
});
