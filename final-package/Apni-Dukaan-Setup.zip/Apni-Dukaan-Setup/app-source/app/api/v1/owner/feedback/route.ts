import { handler, ok } from "@/server/http";
import { getStaff, requireOwner } from "@/server/auth";
import { listFeedback } from "@/server/services/feedback";

export const dynamic = "force-dynamic";

// GET /api/v1/owner/feedback — list + per-category averages + counts.
export const GET = handler(async (req) => {
  requireOwner(await getStaff(req));
  return ok(await listFeedback());
});
