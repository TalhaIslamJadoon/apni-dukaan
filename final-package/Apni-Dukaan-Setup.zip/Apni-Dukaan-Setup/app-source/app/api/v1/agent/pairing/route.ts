import { handler, ok, body } from "@/server/http";
import { createPairingRequest } from "@/server/services/pairing";

export const dynamic = "force-dynamic";

// POST /api/v1/agent/pairing { machineName, version? } — BINA auth ke:
// yehi pairing ka pehla step hai (agent ke pas token abhi hai hi nahi).
// Jawab mein requestId milta hai jo is PC ka secret hai.
export const POST = handler(async (req) => {
  const b = await body<{ machineName?: string; version?: string }>(req).catch(() => ({} as { machineName?: string; version?: string }));
  const r = await createPairingRequest(b.machineName ?? "", b.version);
  return ok({ requestId: r.id, status: r.status }, 201);
});
