import { handler, ok } from "@/server/http";
import { pollPairingRequest } from "@/server/services/pairing";

export const dynamic = "force-dynamic";

// GET /api/v1/agent/pairing/:id — agent ki poll. Approved ho to token
// sirf ek dafa milta hai (us ke baad status 'collected' ho jata hai).
export const GET = handler(async (_req, ctx: { params: Promise<{ requestId: string }> }) => {
  const { requestId } = await ctx.params;
  const r = await pollPairingRequest(requestId);
  return ok(r);
});
