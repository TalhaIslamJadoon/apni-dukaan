import { handler, ok } from "@/server/http";
import { getStaff, requireStaff } from "@/server/auth";
import { deleteHeldBill } from "@/server/services/heldBills";

export const dynamic = "force-dynamic";

// DELETE /api/v1/staff/held-bills/:id — hold bill khatam karna (recall bhi
// isi ko call karta hai: bill wapas khulne ke baad hold list se nikal jata
// hai). Khatam karna koi sale asar nahi rakhta — held bill kabhi sale tha
// hi nahi.
export const DELETE = handler(async (req, ctx: { params: Promise<{ id: string }> }) => {
  requireStaff(await getStaff(req));
  const { id } = await ctx.params;
  return ok(await deleteHeldBill(id));
});
