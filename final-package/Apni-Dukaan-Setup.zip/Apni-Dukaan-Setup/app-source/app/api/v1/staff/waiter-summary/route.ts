import { handler, ok } from "@/server/http";
import { getStaff, requireStaff } from "@/server/auth";
import { waiterSummaryFor } from "@/server/services/waiters";

export const dynamic = "force-dynamic";

// GET /api/v1/staff/waiter-summary — logged-in waiter ka apna hisaab
// (optional shared-tablet serving screen ke liye).
export const GET = handler(async (req) => {
  const staff = requireStaff(await getStaff(req));
  return ok({ summary: await waiterSummaryFor(staff.id) });
});
