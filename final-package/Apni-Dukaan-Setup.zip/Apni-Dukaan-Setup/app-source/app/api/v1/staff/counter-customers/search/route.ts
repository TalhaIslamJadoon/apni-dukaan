import { handler, ok } from "@/server/http";
import { getStaff, requireStaff } from "@/server/auth";
import { searchCounterCustomers } from "@/server/services/counterCustomers";

export const dynamic = "force-dynamic";

// GET /api/v1/staff/counter-customers/search?q=... — Sell checkout ka
// customer picker: naam ya mobile ka partial match, har suggestion ke
// sath bills count aur special discount % (koi bhi logged-in staff).
export const GET = handler(async (req) => {
  requireStaff(await getStaff(req));
  const q = new URL(req.url).searchParams.get("q") ?? "";
  return ok({ suggestions: await searchCounterCustomers(q) });
});
