import { handler, ok, body } from "@/server/http";
import { getStaff, requireStaff } from "@/server/auth";
import { createReturn, listReturns, type ReturnLineInput } from "@/server/services/returns";

export const dynamic = "force-dynamic";

// GET /api/v1/staff/returns?orderId= — ek bill ki purani returns (return
// modal remaining-qty hisaab ke liye).
export const GET = handler(async (req) => {
  requireStaff(await getStaff(req));
  const orderId = new URL(req.url).searchParams.get("orderId") ?? undefined;
  return ok({ returns: await listReturns(orderId) });
});

// POST /api/v1/staff/returns { orderId, lines: [{ lineId, qty }] } —
// cleared bill ki sale return: stock exactly-once wapas, refund bill ke
// apne payment method par (Udhaar → khata adjustment). Koi bhi logged-in
// staff jise bill dikhta hai (owner + cashier roles, tab grants ke mutabiq
// UI gate hota hai).
export const POST = handler(async (req) => {
  const staff = requireStaff(await getStaff(req));
  const input = await body<{ orderId: string; lines: ReturnLineInput[] }>(req);
  return ok({ return: await createReturn(input, staff) }, 201);
});
