import { handler, ok, body } from "@/server/http";
import { getStaff, requireStaff } from "@/server/auth";
import { listHeldBills, createHeldBill } from "@/server/services/heldBills";

export const dynamic = "force-dynamic";

// GET /api/v1/staff/held-bills?mode=canteen|grocery — counter ke hold bills
// (Bill Hold / Suspend-Recall, FIXED-13). Mode dein to sirf usi screen ke.
export const GET = handler(async (req) => {
  requireStaff(await getStaff(req));
  const mode = new URL(req.url).searchParams.get("mode") ?? undefined;
  return ok({ heldBills: await listHeldBills(mode) });
});

// POST /api/v1/staff/held-bills { mode, label, itemCount, total, payload }
// — bill rok kar rakhna. Held bill koi sale NAHI hai (koi order/stock asar
// nahi). Per mode cap 20 — full ho to 409 HELD_BILLS_FULL.
export const POST = handler(async (req) => {
  const staff = requireStaff(await getStaff(req));
  const input = await body<{ mode?: string; label?: string; itemCount?: number; total?: number; payload?: unknown }>(req);
  return ok({ heldBill: await createHeldBill(staff, input) }, 201);
});
