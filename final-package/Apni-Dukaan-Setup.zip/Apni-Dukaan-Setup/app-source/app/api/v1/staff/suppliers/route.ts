import { handler, ok } from "@/server/http";
import { getStaff, requireStaff } from "@/server/auth";
import { listSuppliers } from "@/server/services/suppliers";

export const dynamic = "force-dynamic";

// GET /api/v1/staff/suppliers — stock-in form ke dropdown ke liye (naam +
// mobile; baqaya bhi sath ata hai, form sirf naam/mobile istemal karta hai).
export const GET = handler(async (req) => {
  requireStaff(await getStaff(req));
  return ok({ suppliers: await listSuppliers() });
});
