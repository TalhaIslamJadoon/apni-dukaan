"use client";

import { useMemo, useState } from "react";
import { hasRetail, isPaymentCleared, loadOrders, loadMenu, loadGrocery, useShop } from "@/lib/store";

// ── Reports (B9 Cashier Report + B10 Top Sellers / Slow Movers) ───────────
// Cleared orders se hisaab (wahi set jo P&L istemal karta hai). Period
// presets P&L jaisi: Aaj / Is Hafta / Is Mahina / Custom.
const money = (n: number) => `Rs ${Math.round(n).toLocaleString()}`;
type Preset = "today" | "week" | "month" | "custom";

const pktDate = (iso: string) => new Date(iso).toLocaleDateString("en-CA", { timeZone: "Asia/Karachi" });
const todayPKT = () => new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Karachi" });

function rangeOf(preset: Preset, custom: { from: string; to: string }): { from: string; to: string } {
  const today = todayPKT();
  if (preset === "today") return { from: today, to: today };
  if (preset === "week") {
    const d = new Date(); d.setDate(d.getDate() - 6);
    return { from: d.toLocaleDateString("en-CA", { timeZone: "Asia/Karachi" }), to: today };
  }
  if (preset === "month") return { from: `${today.slice(0, 8)}01`, to: today };
  return custom;
}

export default function ReportsSection() {
  const shop = useShop();
  const [preset, setPreset] = useState<Preset>("today");
  const [custom, setCustom] = useState({ from: todayPKT(), to: todayPKT() });
  const range = rangeOf(preset, custom);

  const data = useMemo(() => {
    // Shop-type scoping: band dukaan ke orders reports mein nahi ginte.
    const modeOn = (m?: string) => (m === "grocery" ? hasRetail(shop) : shop.hasCanteen);
    const orders = loadOrders().filter((o) => isPaymentCleared(o) && modeOn(o.mode) && pktDate(o.createdAt) >= range.from && pktDate(o.createdAt) <= range.to);
    // B9 — cashier wise
    const byCashier = new Map<string, { name: string; bills: number; total: number; byMethod: Record<string, number> }>();
    // B10 — item wise
    const byItem = new Map<string, { key: string; name: string; qty: number; amount: number }>();
    for (const o of orders) {
      const cname = o.cashier ?? "Counter";
      const c = byCashier.get(cname) ?? { name: cname, bills: 0, total: 0, byMethod: {} as Record<string, number> };
      c.bills += 1; c.total += o.total;
      c.byMethod[o.payment] = (c.byMethod[o.payment] ?? 0) + o.total;
      byCashier.set(cname, c);
      for (const l of o.lines) {
        const it = byItem.get(l.itemId) ?? { key: l.itemId, name: l.name, qty: 0, amount: 0 };
        it.qty += l.qty; it.amount += l.price * l.qty;
        byItem.set(l.itemId, it);
      }
    }
    const cashiers = [...byCashier.values()].sort((a, b) => b.total - a.total);
    const items = [...byItem.values()];
    const byQty = [...items].sort((a, b) => b.qty - a.qty).slice(0, 15);
    const byAmount = [...items].sort((a, b) => b.amount - a.amount).slice(0, 15);
    // Slow movers: stock mein hai, is period mein ZERO bika.
    const soldIds = new Set(items.map((i) => i.key));
    const slow: { name: string; stock: number; unit: string }[] = [];
    if (shop.hasCanteen) for (const m of loadMenu()) if ((m.stock ?? 0) > 0 && !soldIds.has(m.id)) slow.push({ name: m.name, stock: m.stock ?? 0, unit: "pcs" });
    if (hasRetail(shop)) for (const g of loadGrocery()) if (g.stock > 0 && !soldIds.has(g.id)) slow.push({ name: g.name, stock: g.stock, unit: g.unit });
    return { orders, cashiers, byQty, byAmount, slow };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [preset, custom.from, custom.to, shop.hasCanteen]);

  const presetBtn = (p: Preset, label: string) => (
    <button key={p} onClick={() => setPreset(p)} data-testid={`reports-preset-${p}`}
      className="rounded-xl px-4 py-2 font-black text-sm"
      style={preset === p ? { background: "#0F172A", color: "#fff" } : { background: "#F5F5F4", color: "#44403C" }}>
      {label}
    </button>
  );

  return (
    <section className="rounded-3xl bg-white shadow p-4 sm:p-5 mb-5" data-testid="reports-section">
      <h3 className="font-black text-lg mb-1">📋 Reports — Cashier & Top Sellers</h3>
      <p className="text-[13px] font-bold text-stone-500 mb-3">
        Sirf cleared bills ginay jate hain (proof pending/rejected nahi). Note: report system mein load shuda recent orders par banti hai.
      </p>
      <div className="flex flex-wrap items-end gap-2 mb-4">
        {presetBtn("today", "Aaj")}
        {presetBtn("week", "Is Hafta")}
        {presetBtn("month", "Is Mahina")}
        {presetBtn("custom", "Custom")}
        {preset === "custom" && (
          <>
            <label className="block">
              <span className="block text-[11px] font-bold uppercase tracking-wide text-stone-500 mb-0.5">From</span>
              <input type="date" value={custom.from} onChange={(e) => setCustom({ ...custom, from: e.target.value })} className="rounded-xl border-2 border-stone-200 px-3 py-2 outline-none focus:border-orange-500" />
            </label>
            <label className="block">
              <span className="block text-[11px] font-bold uppercase tracking-wide text-stone-500 mb-0.5">To</span>
              <input type="date" value={custom.to} onChange={(e) => setCustom({ ...custom, to: e.target.value })} className="rounded-xl border-2 border-stone-200 px-3 py-2 outline-none focus:border-orange-500" />
            </label>
          </>
        )}
        <span className="ml-auto font-black text-sm">{range.from} → {range.to} · {data.orders.length} bills</span>
      </div>

      <h4 className="font-extrabold mb-2">🧑‍💼 Cashier Report (B9)</h4>
      {data.cashiers.length === 0 ? <div className="font-bold text-stone-400 text-sm mb-4">Is period mein koi cleared bill nahi.</div> : (
        <div className="overflow-x-auto mb-5" data-testid="cashier-report">
          <table className="w-full text-sm min-w-[520px]">
            <thead>
              <tr className="text-left text-[11px] uppercase tracking-wide text-stone-500 border-b-2 border-stone-200">
                <th className="py-1.5 pr-2">Cashier</th><th className="py-1.5 pr-2 text-right">Bills</th>
                <th className="py-1.5 pr-2 text-right">Kul Bikri</th><th className="py-1.5 text-right">Payment Tafseel</th>
              </tr>
            </thead>
            <tbody>
              {data.cashiers.map((c) => (
                <tr key={c.name} className="border-b border-stone-100" data-testid={`cashier-row-${c.name}`}>
                  <td className="py-1.5 pr-2 font-bold">{c.name}</td>
                  <td className="py-1.5 pr-2 text-right font-bold">{c.bills}</td>
                  <td className="py-1.5 pr-2 text-right font-black">{money(c.total)}</td>
                  <td className="py-1.5 text-right font-bold text-stone-500">{Object.entries(c.byMethod).map(([m, v]) => `${m}: ${money(v)}`).join(" · ")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <h4 className="font-extrabold mb-2">🏆 Top Sellers — Qty ke hisaab se (B10)</h4>
          {data.byQty.length === 0 ? <div className="font-bold text-stone-400 text-sm">Kuch nahi bika.</div> : (
            <ol className="space-y-1" data-testid="top-sellers-qty">
              {data.byQty.map((i, ix) => (
                <li key={i.key} className="flex items-center gap-2 rounded-xl bg-stone-50 px-3 py-1.5 text-sm">
                  <span className="font-black text-stone-400 w-6">{ix + 1}.</span>
                  <span className="flex-1 font-bold leading-snug">{i.name}</span>
                  <span className="font-black">× {i.qty}</span>
                  <span className="font-bold text-stone-500">{money(i.amount)}</span>
                </li>
              ))}
            </ol>
          )}
        </div>
        <div>
          <h4 className="font-extrabold mb-2">💰 Top Sellers — Raqam ke hisaab se</h4>
          {data.byAmount.length === 0 ? <div className="font-bold text-stone-400 text-sm">Kuch nahi bika.</div> : (
            <ol className="space-y-1" data-testid="top-sellers-amount">
              {data.byAmount.map((i, ix) => (
                <li key={i.key} className="flex items-center gap-2 rounded-xl bg-stone-50 px-3 py-1.5 text-sm">
                  <span className="font-black text-stone-400 w-6">{ix + 1}.</span>
                  <span className="flex-1 font-bold leading-snug">{i.name}</span>
                  <span className="font-black">{money(i.amount)}</span>
                  <span className="font-bold text-stone-500">× {i.qty}</span>
                </li>
              ))}
            </ol>
          )}
        </div>
      </div>

      <h4 className="font-extrabold mt-5 mb-2">🐢 Slow Movers — stock hai, is period mein nahi bika</h4>
      {data.slow.length === 0 ? <div className="font-bold text-stone-400 text-sm">Koi slow mover nahi — sab stock bika hai.</div> : (
        <div className="flex flex-wrap gap-1.5" data-testid="slow-movers">
          {data.slow.slice(0, 40).map((s) => (
            <span key={s.name} className="text-xs font-bold px-2.5 py-1.5 rounded-full bg-amber-50 border border-amber-200 text-amber-900">
              {s.name} — stock {s.stock} {s.unit}
            </span>
          ))}
          {data.slow.length > 40 && <span className="text-xs font-bold text-stone-400 px-2 py-1.5">+{data.slow.length - 40} aur…</span>}
        </div>
      )}
    </section>
  );
}
