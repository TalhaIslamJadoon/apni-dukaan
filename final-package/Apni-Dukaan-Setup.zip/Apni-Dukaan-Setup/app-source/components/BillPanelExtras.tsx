"use client";

import { useState } from "react";
import type { CounterCustomerSuggestion, HeldBill } from "@/lib/store";
import CustomerPicker from "@/components/CustomerPicker";

// ── FIXED-13 (Talha, 20 Nov 2026) — counter bill panel ke teen naye hisse:
// 1) CustomerStrip — bill panel ke upar customer ki halat (Walk-in ya
//    select shuda customer: naam, mobile, Kul Bills, Kul Khareed, discount)
// 2) HeldBillsPopup — hold kiye hue bills ki list (Recall / Khatam)
// 3) ShortcutsPopup — F-key list (F1)
// 4) CustomerPickerPopup — F2 / strip se khulne wala wohi purana picker
// Teeno ka data hamesha page ke apne state se ata hai — doosra customer
// system NAHI hai; strip, F2 popup aur payment popup ek hi state dekhte hain.

/** Button par chhota key hint (F10 / F12 waghera) — reference terminal ki
 *  tarah staff dekh kar seekh jata hai. */
export function KeyHint({ k }: { k: string }) {
  return (
    <span className="ml-1.5 align-middle inline-block rounded-md bg-black/25 px-1.5 py-0.5 text-[10px] font-black tracking-wide text-white">
      {k}
    </span>
  );
}

// ── 1) Customer strip ───────────────────────────────────────────────────────
export function CustomerStrip({ selectedCust, custName, custMobile, onOpenPicker, onClear }: {
  selectedCust: CounterCustomerSuggestion | null;
  custName: string;
  custMobile: string;
  onOpenPicker: () => void;
  onClear: () => void;
}) {
  const typedOnly = !selectedCust && (custName.trim() !== "" || custMobile.trim() !== "");
  return (
    <div className="rounded-2xl border-2 border-stone-200 bg-stone-50 px-3 py-2" data-testid="cust-strip">
      {selectedCust ? (
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-lg">👤</span>
          <span className="flex-1 min-w-0">
            <span className="block font-black leading-tight" data-testid="cust-strip-name">{selectedCust.name}</span>
            <span className="block text-xs font-bold text-stone-500">
              {selectedCust.mobile} · Kul Bills: {selectedCust.bills} · Kul Khareed: Rs {(selectedCust.totalSpent ?? 0).toLocaleString()}
            </span>
          </span>
          {selectedCust.discountPct > 0 && (
            <span className="shrink-0 text-xs font-black rounded-full px-2 py-1 text-white" style={{ background: "#D97706" }} data-testid="cust-strip-discount">
              ⭐ {selectedCust.discountPct}% OFF
            </span>
          )}
          <button onClick={onOpenPicker} data-testid="cust-strip-change" className="shrink-0 rounded-lg px-2.5 py-1.5 text-xs font-black bg-white border-2 border-stone-200">
            Badlein
          </button>
          <button onClick={onClear} data-testid="cust-strip-clear" className="shrink-0 rounded-lg px-2.5 py-1.5 text-xs font-black text-white" style={{ background: "#DC2626" }}>
            Hatayein ✕
          </button>
        </div>
      ) : typedOnly ? (
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-lg">👤</span>
          <span className="flex-1 min-w-0">
            <span className="block font-black leading-tight">{custName.trim() || "Naya Customer"}</span>
            <span className="block text-xs font-bold text-stone-500">
              {custMobile.trim()} · Bill complete hone par is ka record ban jayega
            </span>
          </span>
          <button onClick={onOpenPicker} data-testid="cust-strip-change" className="shrink-0 rounded-lg px-2.5 py-1.5 text-xs font-black bg-white border-2 border-stone-200">
            Badlein
          </button>
          <button onClick={onClear} data-testid="cust-strip-clear" className="shrink-0 rounded-lg px-2.5 py-1.5 text-xs font-black text-white" style={{ background: "#DC2626" }}>
            Hatayein ✕
          </button>
        </div>
      ) : (
        <div className="flex items-center gap-2">
          <span className="text-lg">👤</span>
          <span className="flex-1 font-black text-stone-500" data-testid="cust-strip-walkin">Walk-in Customer</span>
          <button onClick={onOpenPicker} data-testid="cust-strip-add" className="shrink-0 rounded-lg px-3 py-2 text-xs font-black text-white" style={{ background: "#0F172A" }}>
            Customer Lagayein<KeyHint k="F2" />
          </button>
        </div>
      )}
    </div>
  );
}

// ── 2) Held bills popup ─────────────────────────────────────────────────────
function linesSummary(b: HeldBill): string[] {
  const p = b.payload;
  const out: string[] = [];
  if (Array.isArray(p.cart)) {
    for (const l of p.cart as { item?: { name?: string }; qty?: number }[]) out.push(`${l.item?.name ?? "Item"} × ${l.qty ?? 1}`);
  }
  if (Array.isArray(p.dealCart)) {
    for (const l of p.dealCart as { deal?: { name?: string }; qty?: number }[]) out.push(`🎁 ${l.deal?.name ?? "Deal"} × ${l.qty ?? 1}`);
  }
  if (Array.isArray(p.groceryCart)) {
    for (const l of p.groceryCart as { item?: { name?: string }; qty?: number; packing?: { label?: string }; variant?: string }[]) {
      out.push(`${l.item?.name ?? "Item"}${l.variant ? ` (${l.variant})` : ""}${l.packing ? ` (${l.packing.label})` : ""} × ${l.qty ?? 1}`);
    }
  }
  return out;
}

export function HeldBillsPopup({ bills, onRecall, onDelete, onClose }: {
  bills: HeldBill[];
  onRecall: (b: HeldBill) => void;
  onDelete: (b: HeldBill) => void;
  onClose: () => void;
}) {
  const [confirmId, setConfirmId] = useState<string | null>(null);
  return (
    <div className="fixed inset-0 bg-black/60 flex items-end sm:items-center justify-center z-50 p-3" data-testid="held-bills-popup">
      <div className="bg-white rounded-3xl w-full max-w-2xl p-5 max-h-[92vh] overflow-y-auto pop-in">
        <div className="flex items-center justify-between mb-1">
          <h3 className="text-xl font-extrabold">📂 Hold Bills ({bills.length})</h3>
          <button onClick={onClose} data-testid="held-bills-close" className="text-2xl font-bold text-stone-400">✕</button>
        </div>
        <p className="text-sm font-bold text-stone-500 mb-3">
          Ye bills sirf ROKE hue hain — sale nahi hue. Koi bill wapas kholein to wohi lines, discount aur customer ke sath bill mein aa jayega.
        </p>
        {bills.length === 0 && (
          <p className="text-stone-400 text-center py-8 font-bold">Abhi koi bill hold nahi hai.</p>
        )}
        <div>
          {bills.map((b) => {
            const lines = linesSummary(b);
            return (
              <div key={b.id} className="py-3 border-b-2 border-stone-200" data-testid={`held-bill-row-${b.id}`}>
                <div className="flex items-start gap-2 flex-wrap">
                  <div className="flex-1 min-w-0">
                    <div className="font-black leading-tight">⏸ {b.label}</div>
                    <div className="text-xs font-bold text-stone-500">
                      {new Date(b.createdAt).toLocaleString("en-PK", { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" })}
                      {b.staffName ? ` · Cashier: ${b.staffName}` : ""}
                    </div>
                    <div className="text-sm font-semibold text-stone-600 leading-snug mt-0.5">
                      {lines.slice(0, 4).join(" · ")}{lines.length > 4 ? ` · +${lines.length - 4} aur` : ""}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-lg font-black" style={{ color: "#F97316" }}>Rs {Math.round(b.total).toLocaleString()}</div>
                  </div>
                </div>
                {confirmId === b.id ? (
                  <div className="flex items-center gap-2 mt-2 rounded-xl bg-red-50 border border-red-200 px-3 py-2" data-testid={`held-delete-confirm-row-${b.id}`}>
                    <span className="flex-1 text-sm font-black" style={{ color: "#991B1B" }}>Pakka khatam karein? Ye bill wapas nahi ayega.</span>
                    <button onClick={() => { setConfirmId(null); onDelete(b); }} data-testid={`held-delete-confirm-${b.id}`}
                      className="rounded-lg px-3 py-2 text-sm font-black text-white" style={{ background: "#DC2626" }}>Haan, Khatam</button>
                    <button onClick={() => setConfirmId(null)} data-testid={`held-delete-cancel-${b.id}`}
                      className="rounded-lg px-3 py-2 text-sm font-black bg-white border-2 border-stone-200">Nahi</button>
                  </div>
                ) : (
                  <div className="flex gap-2 mt-2">
                    <button onClick={() => onRecall(b)} data-testid={`held-recall-${b.id}`}
                      className="flex-1 rounded-xl py-2.5 font-black text-white" style={{ background: "#16A34A" }}>↩ Wapas Kholein (Recall)</button>
                    <button onClick={() => setConfirmId(b.id)} data-testid={`held-delete-${b.id}`}
                      className="rounded-xl px-4 py-2.5 font-black border-2" style={{ borderColor: "#DC2626", color: "#DC2626" }}>🗑️ Khatam Karein</button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ── 3) F-key shortcuts popup (F1) ───────────────────────────────────────────
const SHORTCUT_ROWS: { key: string; text: string }[] = [
  { key: "F1", text: "Ye shortcuts wali list kholein" },
  { key: "F2", text: "Customer lagayein / badlein (purana customer search)" },
  { key: "F3", text: "Product search par focus — naam likh kar item dhundein" },
  { key: "F8", text: "Aakhri line hatao (bill ki sab se neeche wali line)" },
  { key: "F9", text: "Poora bill saaf karein (pehle confirm ayega)" },
  { key: "F10", text: "Bill Hold Karein — bill rok kar dusre customer ko serve karein" },
  { key: "F11", text: "Quick Cash — payment khule, Cash select ho, amount wali jagah focus" },
  { key: "F12", text: "Payments — payment wala panel kholein" },
];

export function ShortcutsPopup({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black/60 flex items-end sm:items-center justify-center z-50 p-3" data-testid="shortcuts-popup">
      <div className="bg-white rounded-3xl w-full max-w-lg p-5 max-h-[92vh] overflow-y-auto pop-in">
        <div className="flex items-center justify-between mb-1">
          <h3 className="text-xl font-extrabold">⌨️ Keyboard Shortcuts</h3>
          <button onClick={onClose} data-testid="shortcuts-close" className="text-2xl font-bold text-stone-400">✕</button>
        </div>
        <p className="text-sm font-bold text-stone-500 mb-2">Counter par tez kaam ke liye — mouse chhoye baghair bill banayein.</p>
        <div>
          {SHORTCUT_ROWS.map((r) => (
            <div key={r.key} className="flex items-center gap-3 py-2.5 border-b border-stone-200">
              <span className="shrink-0 w-12 text-center rounded-lg py-1.5 font-black text-white" style={{ background: "#0F172A" }}>{r.key}</span>
              <span className="font-bold text-sm">{r.text}</span>
            </div>
          ))}
        </div>
        <p className="text-xs font-bold text-stone-400 mt-3">Koi key browser ki wajah se na chale to screen par wahi button hamesha maujood hai.</p>
      </div>
    </div>
  );
}

// ── 4) Customer picker popup (F2 / strip) ───────────────────────────────────
// Payment popup wala HI picker hai — wahi state, wahi handlers. Sirf ek
// alag khidki mein khulta hai taake cashier bill banate waqt hi customer
// laga sake; payment ke waqt wohi customer wahan bhi nazar ayega.
export function CustomerPickerPopup({ name, mobile, onNameChange, onMobileChange, onSelect, search, mobileInvalid, selectedCust, specialApplied, onClose }: {
  name: string;
  mobile: string;
  onNameChange: (v: string) => void;
  onMobileChange: (v: string) => void;
  onSelect: (c: CounterCustomerSuggestion) => void;
  search: (q: string) => Promise<CounterCustomerSuggestion[]>;
  mobileInvalid: boolean;
  selectedCust: CounterCustomerSuggestion | null;
  specialApplied: boolean;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 bg-black/60 flex items-end sm:items-center justify-center z-50 p-3" data-testid="cust-picker-popup">
      <div className="bg-white rounded-3xl w-full max-w-lg p-5 max-h-[92vh] overflow-y-auto pop-in">
        <div className="flex items-center justify-between mb-1">
          <h3 className="text-xl font-extrabold">👤 Customer Lagayein</h3>
          <button onClick={onClose} data-testid="cust-picker-close" className="text-2xl font-bold text-stone-400">✕</button>
        </div>
        <p className="text-sm font-bold text-stone-500 mb-3">
          Purana customer ho to naam ya mobile likhte hi neeche record aa jayega — select kar lein. Naya ho to naam + mobile likh dein, bill complete hone par record ban jayega.
        </p>
        <CustomerPicker
          name={name} mobile={mobile}
          onNameChange={onNameChange} onMobileChange={onMobileChange}
          onSelect={onSelect} search={search} idPrefix="stripcust"
        />
        {mobileInvalid && (
          <div className="mt-2 rounded-xl px-3 py-2 font-black text-sm text-white" style={{ background: "#DC2626" }} data-testid="cust-mobile-warn">
            ⚠️ Mobile number theek nahi lag raha — is par customer record NAHI banega. Poora number likhein (e.g. 03001234567) ya field khaali kar dein.
          </div>
        )}
        {specialApplied && selectedCust && (
          <div className="mt-2 rounded-xl px-3 py-2 font-black text-sm text-white pop-in" style={{ background: "#D97706" }} data-testid="cust-special-banner">
            ⭐ Permanent Customer — {selectedCust.name} ki Special Discount {selectedCust.discountPct}% laga diya hai
          </div>
        )}
        {selectedCust && !specialApplied && (
          <div className="mt-2 text-xs font-black" style={{ color: "#16A34A" }} data-testid="cust-attached-note">
            ✓ {selectedCust.name} is bill par laga hai — 🧾 {selectedCust.bills} purane bills is record mein hain
          </div>
        )}
        <button onClick={onClose} data-testid="cust-picker-done" className="w-full mt-4 rounded-2xl py-3.5 font-black text-white" style={{ background: "#16A34A" }}>
          ✓ Ho Gaya — Bill par wapas
        </button>
      </div>
    </div>
  );
}

// ── 5) Void-sale confirm popup (F9) ─────────────────────────────────────────
export function VoidSaleConfirm({ onConfirm, onClose }: { onConfirm: () => void; onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4" data-testid="void-sale-confirm">
      <div className="bg-white rounded-3xl w-full max-w-md p-5 pop-in">
        <div className="text-4xl mb-2">🧾</div>
        <h3 className="text-lg font-black mb-1">Poora bill saaf karein?</h3>
        <p className="text-sm font-semibold text-stone-600 mb-4">
          Bill ki saari lines khatam ho jayengi. Agar ye bill baad mein chahiye to pehle <b>Hold</b> kar lein — hold wala bill wapas khul sakta hai.
        </p>
        <div className="space-y-2">
          <button onClick={onConfirm} data-testid="void-sale-yes" className="w-full rounded-2xl py-3.5 font-black text-white" style={{ background: "#DC2626" }}>
            Haan, Poora Bill Saaf Karein
          </button>
          <button onClick={onClose} data-testid="void-sale-no" className="w-full rounded-2xl py-3 font-black bg-stone-100 text-stone-700">
            Nahi, Bill Rehne Dein
          </button>
        </div>
      </div>
    </div>
  );
}
