"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { apiGet, apiPost, apiPatch, ApiClientError } from "@/lib/api";
import type { Order } from "@/lib/store";
import Receipt from "@/components/Receipt";
import WhatsAppBillButton from "@/components/WhatsAppBillButton";
import UdhaarStatementModal, { StatementEntry } from "@/components/UdhaarStatement";
import SaleReturnModal from "@/components/SaleReturnModal";

// ── Customers — counter (walk-in) customers ka mukammal record ─────────────
// Ek record per mobile: dono dukaanon ke bills + rental bookings ek hi
// history mein. Owner yahan naam/mobile aur permanent-customer special
// discount % set karta hai. Online accounts is se alag hain — ye sirf
// counter par bane naam+mobile wale record hain (koi login nahi).
export interface CounterCustomerRow {
  id: string;
  name: string;
  mobile: string;
  discountPct: number;
  pointsBalance: number;
  createdAt: string;
  updatedAt: string;
  bills: number;
  totalSpent: number;
  lastBillAt: string | null;
}

interface BookingLite {
  bookingNo: string;
  itemName: string;
  pickupDate: string;
  returnDate: string;
  rentTotal: number;
  status: string;
  createdAt: string;
}

interface Detail {
  customer: CounterCustomerRow;
  bills: Order[];
  bookings: BookingLite[];
  totals: { bills: number; totalSpent: number };
}

const money = (n: number) => `Rs ${Math.round(n).toLocaleString()}`;
const fmtDate = (iso: string) =>
  new Date(iso).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "2-digit", hour: "2-digit", minute: "2-digit" });
const labelCls = "block text-xs font-black uppercase tracking-wide text-stone-500 mb-1";
const inputCls = "w-full rounded-xl border-2 border-stone-200 px-3 py-2.5 font-bold outline-none focus:border-orange-500 bg-white";

export default function CounterCustomersSection() {
  const [rows, setRows] = useState<CounterCustomerRow[]>([]);
  const [search, setSearch] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [detail, setDetail] = useState<Detail | null>(null);
  const [loadErr, setLoadErr] = useState("");
  const [msg, setMsg] = useState("");
  const [viewOrder, setViewOrder] = useState<Order | null>(null);
  const [returnOrder, setReturnOrder] = useState<Order | null>(null);
  const [stmt, setStmt] = useState<{ entries: StatementEntry[]; totalCharged: number; totalPaid: number; balance: number } | null>(null);

  // Udhaar statement (B3): is customer ke udhaar bills ka khata — server ke
  // udhaar accounts mein mobile se match mile to poora ledger (wasooli
  // समेत), warna sirf charges wala statement.
  async function openStatement() {
    if (!detail) return;
    const charges = detail.bills.filter((o) => o.payment === "Udhaar");
    try {
      const a = await apiGet<{ accounts: { id: string; name?: string; mobile: string | null; balance: number; totalCharged: number; totalPaid: number }[] }>("/owner/udhaar/accounts");
      const acc = a.accounts.find((x) => x.mobile && x.mobile.replace(/\D/g, "") === detail.customer.mobile)
        ?? a.accounts.find((x) => (x.name ?? "").trim().toLowerCase() === detail.customer.name.trim().toLowerCase());
      if (acc) {
        const l = await apiGet<{ entries: { at: string; type: string; amount: number; balanceAfter: number; billNo: string | null; method: string | null }[] }>(`/owner/udhaar/accounts/${acc.id}/ledger`);
        setStmt({
          entries: l.entries.map((e) => ({
            at: e.at,
            label: e.type === "charge" ? `🧾 Udhaar Charge${e.billNo ? ` — Bill ${e.billNo}` : ""}` : e.type === "payment" ? `💰 Wasooli${e.method ? ` — ${e.method}` : ""}` : e.type === "reversal" ? "↩️ Reversal" : "🛠️ Adjustment",
            amount: e.amount, balanceAfter: e.balanceAfter,
          })),
          totalCharged: acc.totalCharged, totalPaid: acc.totalPaid, balance: acc.balance,
        });
        return;
      }
    } catch { /* fallback neeche */ }
    let bal = 0;
    const entries = [...charges].sort((x, y) => (x.createdAt < y.createdAt ? -1 : 1)).map((o) => {
      bal += o.total;
      return { at: o.createdAt, label: `🧾 Udhaar Charge — Bill ${o.billNo ?? ""}`, amount: o.total, balanceAfter: bal };
    });
    setStmt({ entries, totalCharged: bal, totalPaid: 0, balance: bal });
  }
  // Add form
  const [addForm, setAddForm] = useState({ name: "", mobile: "", discountPct: "" });
  const [addErr, setAddErr] = useState("");
  // Edit form (selected customer)
  const [editForm, setEditForm] = useState({ name: "", mobile: "", discountPct: "" });
  const [editErr, setEditErr] = useState("");
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    try {
      const d = await apiGet<{ customers: CounterCustomerRow[] }>("/owner/counter-customers");
      setRows(d.customers);
      setLoadErr("");
    } catch (e) { setLoadErr(e instanceof ApiClientError ? e.message : "Customers load nahi hue"); }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const openDetail = useCallback(async (id: string) => {
    setSelectedId(id);
    setDetail(null);
    setEditErr("");
    try {
      const d = await apiGet<Detail>(`/owner/counter-customers/${id}`);
      setDetail(d);
      setEditForm({ name: d.customer.name, mobile: d.customer.mobile, discountPct: String(d.customer.discountPct || "") });
    } catch (e) { setLoadErr(e instanceof ApiClientError ? e.message : "Customer ki tafseel nahi mili"); }
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter((r) => r.name.toLowerCase().includes(q) || r.mobile.includes(q.replace(/\D/g, "")) || r.mobile.includes(q));
  }, [rows, search]);

  async function addCustomer() {
    setAddErr(""); setMsg("");
    try {
      const r = await apiPost<{ customer: CounterCustomerRow }>("/owner/counter-customers", {
        name: addForm.name.trim(),
        mobile: addForm.mobile.trim(),
        discountPct: addForm.discountPct === "" ? 0 : Number(addForm.discountPct),
      });
      setAddForm({ name: "", mobile: "", discountPct: "" });
      setMsg(`✓ ${r.customer.name} ka record ban gaya`);
      await load();
    } catch (e) {
      // 409 DUPLICATE_MOBILE — server ka message maujooda customer ka naam kehta hai.
      setAddErr(e instanceof ApiClientError ? e.message : "Record nahi bana");
    }
  }

  async function saveEdit() {
    if (!detail) return;
    setEditErr(""); setMsg(""); setSaving(true);
    try {
      const r = await apiPatch<{ customer: CounterCustomerRow }>(`/owner/counter-customers/${detail.customer.id}`, {
        name: editForm.name.trim(),
        mobile: editForm.mobile.trim(),
        discountPct: editForm.discountPct === "" ? 0 : Number(editForm.discountPct),
      });
      await load();
      await openDetail(detail.customer.id);
      setMsg(`✓ ${r.customer.name} ka record update ho gaya`);
    } catch (e) {
      setEditErr(e instanceof ApiClientError ? e.message : "Update nahi hua");
    } finally { setSaving(false); }
  }

  // Bills + bookings ek chronological history mein (type label ke sath).
  const history = useMemo(() => {
    if (!detail) return [] as ({ kind: "bill"; at: string; order: Order } | { kind: "booking"; at: string; booking: BookingLite })[];
    const items: ({ kind: "bill"; at: string; order: Order } | { kind: "booking"; at: string; booking: BookingLite })[] = [
      ...detail.bills.map((o) => ({ kind: "bill" as const, at: o.createdAt, order: o })),
      ...detail.bookings.map((b) => ({ kind: "booking" as const, at: b.createdAt, booking: b })),
    ];
    return items.sort((a, b) => (a.at < b.at ? 1 : -1));
  }, [detail]);

  return (
    <div className="space-y-4">
      <section className="bg-white rounded-2xl border border-orange-100 shadow-sm p-4">
        <h2 className="font-extrabold mb-1">👥 Customers — Counter Record</h2>
        <p className="text-sm font-semibold text-stone-500 mb-3">
          Walk-in customers ke naam+mobile wale record — dono dukaanon ke bills aur rental bookings ek hi jagah.
          Koi account/login nahi banta. <b>Special Discount %</b> yahin set hota hai — wo customer bill par select ho to discount khud lag jata hai.
        </p>
        {loadErr && <div className="rounded-xl bg-red-100 border border-red-300 px-3 py-2 text-sm font-black mb-3" style={{ color: "#DC2626" }}>{loadErr}</div>}
        {msg && <div className="rounded-xl bg-green-50 border border-green-200 px-3 py-2 text-sm font-black mb-3" style={{ color: "#16A34A" }} data-testid="cust-msg">{msg}</div>}
        <div className="mb-3">
          <label className={labelCls} htmlFor="cust-search">Customer dhoondein — naam ya mobile</label>
          <input id="cust-search" data-testid="cust-search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="🔍 Naam ya mobile likhein…"
            className={inputCls} />
        </div>
        {filtered.length === 0 && <p className="text-stone-400 font-bold text-sm">Abhi koi customer record nahi — pehla bill naam+mobile ke sath bante hi record yahan aa jayega.</p>}
        <div className="space-y-1.5" data-testid="cust-list">
          {filtered.map((r) => (
            <button key={r.id} onClick={() => void openDetail(r.id)} data-testid={`cust-row-${r.mobile}`}
              className={`w-full flex items-center gap-3 rounded-xl border-2 px-3 py-2.5 text-left transition ${selectedId === r.id ? "border-orange-400 bg-orange-50" : "border-stone-100 bg-white hover:bg-orange-50/50"}`}>
              <span className="text-2xl">👤</span>
              <span className="flex-1 min-w-0">
                <span className="block font-extrabold leading-tight">{r.name}</span>
                <span className="block text-xs font-bold text-stone-500">{r.mobile} · 🧾 {r.bills} bills{r.lastBillAt ? ` · Akhri bill: ${fmtDate(r.lastBillAt)}` : ""}</span>
              </span>
              {r.discountPct > 0 && <span className="shrink-0 text-xs font-black rounded-full px-2 py-1 text-white" style={{ background: "#D97706" }}>⭐ {r.discountPct}%</span>}
              {r.pointsBalance > 0 && <span className="shrink-0 text-xs font-black rounded-full px-2 py-1" style={{ background: "#FEF3C7", color: "#92400E" }} data-testid={`cust-points-${r.mobile}`}>⭐ {r.pointsBalance} pts</span>}
              <span className="text-right shrink-0">
                <span className="block font-black" style={{ color: "#F97316" }}>{money(r.totalSpent)}</span>
                <span className="block text-[10px] font-bold text-stone-400">KUL KHAREED</span>
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* Naya record haath se */}
      <section className="bg-white rounded-2xl border border-orange-100 shadow-sm p-4">
        <h3 className="font-extrabold mb-3">➕ Naya Customer Record</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className={labelCls} htmlFor="cust-add-name">Customer Name</label>
            <input id="cust-add-name" data-testid="cust-add-name" value={addForm.name} onChange={(e) => setAddForm({ ...addForm, name: e.target.value })} placeholder="e.g. Ahmed Khan" className={inputCls} />
          </div>
          <div>
            <label className={labelCls} htmlFor="cust-add-mobile">Mobile Number</label>
            <input id="cust-add-mobile" data-testid="cust-add-mobile" value={addForm.mobile} onChange={(e) => setAddForm({ ...addForm, mobile: e.target.value })} placeholder="03XX-XXXXXXX" inputMode="tel" className={inputCls} />
          </div>
          <div>
            <label className={labelCls} htmlFor="cust-add-pct">Special Discount % (Permanent)</label>
            <input id="cust-add-pct" data-testid="cust-add-pct" value={addForm.discountPct} onChange={(e) => setAddForm({ ...addForm, discountPct: e.target.value })} placeholder="0" inputMode="decimal" className={inputCls} />
          </div>
        </div>
        {addErr && <div className="rounded-xl bg-red-100 border border-red-300 px-3 py-2 text-sm font-black mt-3" style={{ color: "#DC2626" }} data-testid="cust-add-err">{addErr}</div>}
        <button onClick={() => void addCustomer()} data-testid="cust-add-btn" className="mt-3 rounded-2xl px-5 py-3 font-black text-white" style={{ background: "#16A34A" }}>✓ Record Banayein</button>
      </section>

      {/* Tafseel + edit + history */}
      {selectedId && (
        <section className="bg-white rounded-2xl border-2 border-orange-200 shadow-sm p-4" data-testid="cust-detail">
          {!detail ? <p className="font-bold text-stone-400">Load ho raha hai…</p> : (<>
            <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
              <div>
                <h3 className="text-lg font-black">👤 {detail.customer.name}</h3>
                <div className="text-sm font-bold text-stone-500">{detail.customer.mobile}</div>
              </div>
              <div className="flex gap-4 text-center">
                <div><div className="text-xl font-black" style={{ color: "#F97316" }}>{detail.totals.bills}</div><div className="text-[10px] font-bold text-stone-400">KUL BILLS</div></div>
                <div><div className="text-xl font-black" style={{ color: "#16A34A" }}>{money(detail.totals.totalSpent)}</div><div className="text-[10px] font-bold text-stone-400">KUL KHAREED (BILLS)</div></div>
                <div><div className="text-xl font-black" style={{ color: "#7E22CE" }}>{detail.bookings.length}</div><div className="text-[10px] font-bold text-stone-400">RENTAL BOOKINGS</div></div>
                <div><div className="text-xl font-black" style={{ color: "#D97706" }} data-testid="cust-detail-points">{detail.customer.pointsBalance}</div><div className="text-[10px] font-bold text-stone-400">LOYALTY POINTS</div></div>
              </div>
            </div>

            <div className="rounded-2xl border-2 border-stone-100 bg-stone-50 p-3 mb-4">
              <div className="font-black mb-2">✏️ Record Edit Karein</div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className={labelCls} htmlFor="cust-edit-name">Customer Name</label>
                  <input id="cust-edit-name" data-testid="cust-edit-name" value={editForm.name} onChange={(e) => setEditForm({ ...editForm, name: e.target.value })} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls} htmlFor="cust-edit-mobile">Mobile Number</label>
                  <input id="cust-edit-mobile" data-testid="cust-edit-mobile" value={editForm.mobile} onChange={(e) => setEditForm({ ...editForm, mobile: e.target.value })} inputMode="tel" className={inputCls} />
                </div>
                <div>
                  <label className={labelCls} htmlFor="cust-edit-pct">Special Discount % (Permanent)</label>
                  <input id="cust-edit-pct" data-testid="cust-edit-pct" value={editForm.discountPct} onChange={(e) => setEditForm({ ...editForm, discountPct: e.target.value })} inputMode="decimal" placeholder="0" className={inputCls} />
                </div>
              </div>
              {editErr && <div className="rounded-xl bg-red-100 border border-red-300 px-3 py-2 text-sm font-black mt-3" style={{ color: "#DC2626" }} data-testid="cust-edit-err">{editErr}</div>}
              <button onClick={() => void saveEdit()} disabled={saving} data-testid="cust-edit-save" className="mt-3 rounded-2xl px-5 py-2.5 font-black text-white disabled:opacity-40" style={{ background: "#0F172A" }}>💾 Save</button>
              <span className="ml-2 text-xs font-bold text-stone-400">Discount % badalne se purane bills nahi badalte — sirf aane wale bills par lagta hai.</span>
            </div>

            {detail.bills.some((o) => o.payment === "Udhaar") && (
              <button onClick={() => void openStatement()} data-testid="cust-statement-btn"
                className="mb-3 rounded-xl px-4 py-2.5 font-black text-white text-sm" style={{ background: "#0F172A" }}>
                📄 Udhaar Statement dekhein (is customer ke udhaar bills + wasooli)
              </button>
            )}

            <h4 className="font-extrabold mb-2">🧾 Poori History — Bills + Bookings</h4>
            {history.length === 0 && <p className="text-stone-400 font-bold text-sm">Abhi is customer ki koi history nahi.</p>}
            <div className="space-y-1.5" data-testid="cust-history">
              {history.map((h) => h.kind === "bill" ? (
                <button key={`b-${h.order.id}`} onClick={() => setViewOrder(h.order)} data-testid={`cust-bill-${h.order.billNo}`}
                  className="w-full flex items-center gap-3 rounded-xl border border-stone-100 px-3 py-2 text-left hover:bg-orange-50/60">
                  <span className="shrink-0 text-[10px] font-black rounded-full px-2 py-1 text-white" style={{ background: h.order.mode === "grocery" ? "#16A34A" : "#F97316" }}>
                    {h.order.mode === "grocery" ? "🛒 SELL BILL" : "🍽️ CANTEEN BILL"}
                  </span>
                  <span className="flex-1 min-w-0">
                    <span className="block font-extrabold text-sm">{h.order.billNo ?? ""} · {money(h.order.total)}</span>
                    <span className="block text-xs font-bold text-stone-500">{fmtDate(h.order.createdAt)} · {h.order.payment}{(h.order.discount ?? 0) > 0 ? ` · Discount −${money(h.order.discount!)}` : ""}</span>
                  </span>
                  <span className="text-xs font-black text-stone-400">View / Print →</span>
                </button>
              ) : (
                <div key={`r-${h.booking.bookingNo}`} data-testid={`cust-booking-${h.booking.bookingNo}`}
                  className="w-full flex items-center gap-3 rounded-xl border border-stone-100 px-3 py-2">
                  <span className="shrink-0 text-[10px] font-black rounded-full px-2 py-1 text-white" style={{ background: "#7E22CE" }}>👰 RENTAL</span>
                  <span className="flex-1 min-w-0">
                    <span className="block font-extrabold text-sm">{h.booking.bookingNo} · {h.booking.itemName} · {money(h.booking.rentTotal)}</span>
                    <span className="block text-xs font-bold text-stone-500">{fmtDate(h.at)} · Pickup {h.booking.pickupDate} → Wapsi {h.booking.returnDate} · Status: {h.booking.status}</span>
                  </span>
                </div>
              ))}
            </div>
          </>)}
        </section>
      )}

      {stmt && detail && (
        <UdhaarStatementModal
          name={detail.customer.name}
          mobile={detail.customer.mobile}
          entries={stmt.entries}
          totalCharged={stmt.totalCharged}
          totalPaid={stmt.totalPaid}
          balance={stmt.balance}
          onClose={() => setStmt(null)}
        />
      )}

      {/* Bill re-view / reprint */}
      {viewOrder && (
        <div className="fixed inset-0 z-50 bg-black/60 overflow-y-auto p-4">
          <div className="max-w-md mx-auto py-4 pop-in">
            <Receipt order={viewOrder} />
            <div className="flex gap-2 mt-4 no-print">
              <button onClick={() => window.print()} className="flex-1 rounded-2xl py-3.5 font-black bg-white text-stone-900 shadow">🖨️ Reprint (80mm)</button>
              <button onClick={() => setViewOrder(null)} className="flex-1 rounded-2xl py-3.5 font-black text-white shadow" style={{ background: "#DC2626" }}>✕ Close</button>
            </div>
            <div className="flex gap-2 mt-2 no-print">
              <WhatsAppBillButton order={viewOrder} />
              {viewOrder.paymentStatus !== "proof_pending" && viewOrder.paymentStatus !== "rejected" && (
                <button onClick={() => setReturnOrder(viewOrder)} data-testid="cust-return-btn"
                  className="flex-1 rounded-2xl py-3 font-black text-white shadow" style={{ background: "#B45309" }}>
                  ↩️ Sale Return
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {returnOrder && (
        <SaleReturnModal order={returnOrder} onClose={() => setReturnOrder(null)} onDone={() => { if (selectedId) void openDetail(selectedId); }} />
      )}
    </div>
  );
}
