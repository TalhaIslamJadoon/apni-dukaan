"use client";

import { useEffect, useState } from "react";
import { fetchWaiterSummaries, payWaiterApi, type WaiterSummaryDTO } from "@/lib/store";

// ─────────────────────────────────────────────────────────────────────────────
// WAITERS HISAB (Owner) — Talha, FIXED-12.
// Teen hisaab alag alag: SERVICE (customer-paid pass-through — adaigi par
// expense NAHI), COMMISSION (shop-paid — adaigi Expense banti hai),
// TANKHWAH (salary khata — adaigi Expense "Tankhwah — <name>").
// Default period: Aaj. Cash-jama (pending deposit) bhi yahin dikhta hai.
// ─────────────────────────────────────────────────────────────────────────────

const rs = (n: number) => `Rs ${Math.round(n).toLocaleString()}`;
const METHODS = ["Cash", "JazzCash", "Easypaisa", "Raast", "Bank"];

type Period = "today" | "week" | "month" | "all";
function rangeOf(p: Period): { from?: string; to?: string } {
  const now = new Date();
  const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const today = iso(now);
  if (p === "today") return { from: today, to: today };
  if (p === "week") { const d = new Date(now); d.setDate(d.getDate() - 6); return { from: iso(d), to: today }; }
  if (p === "month") { return { from: `${today.slice(0, 8)}01`, to: today }; }
  return {};
}

export default function WaitersAdmin() {
  const [period, setPeriod] = useState<Period>("today");
  const [rows, setRows] = useState<WaiterSummaryDTO[]>([]);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");

  async function load(p: Period = period) {
    try {
      const r = rangeOf(p);
      setRows(await fetchWaiterSummaries(r.from, r.to));
      setErr("");
    } catch (e) { setErr(e instanceof Error ? e.message : "Waiter hisaab load nahi ho saka"); }
  }
  useEffect(() => { void load(); }, [period]); // eslint-disable-line react-hooks/exhaustive-deps

  async function pay(s: WaiterSummaryDTO, kind: "commission" | "salary" | "service", amount: number, method: string, monthLabel?: string) {
    setMsg("");
    try {
      await payWaiterApi(s.staffId, kind, amount, method, monthLabel);
      setMsg(`✓ ${s.name} ko ${rs(amount)} ada kar diye`);
      await load();
    } catch (e) { setMsg(`⚠️ ${e instanceof Error ? e.message : "Adaigi save nahi ho saki"}`); }
  }

  if (err) return <section className="bg-white rounded-2xl border border-orange-100 shadow-sm p-4"><h2 className="font-extrabold">🧑‍🍳 Waiters Hisaab</h2><p className="font-bold mt-2" style={{ color: "#DC2626" }}>⚠️ {err}</p></section>;
  if (rows.length === 0) return null;

  return (
    <section className="bg-white rounded-2xl border border-orange-100 shadow-sm p-4" data-testid="waiters-admin">
      <div className="flex items-center gap-2 flex-wrap">
        <h2 className="font-extrabold">🧑‍🍳 Waiters Hisaab — Service · Commission · Tankhwah</h2>
        <span className="ml-auto flex gap-1">
          {(["today", "week", "month", "all"] as Period[]).map((p) => (
            <button key={p} onClick={() => setPeriod(p)} data-testid={`waiters-period-${p}`}
              className="rounded-full px-3 py-1.5 text-xs font-black border-2"
              style={period === p ? { background: "#F97316", borderColor: "#F97316", color: "#fff" } : { background: "#fff", borderColor: "#E7E5E4" }}>
              {p === "today" ? "Aaj" : p === "week" ? "Is Hafta" : p === "month" ? "Is Mahina" : "Kul"}
            </button>
          ))}
        </span>
      </div>
      <p className="text-sm text-stone-500 mb-3">Service customer ke bill se aati hai (dukaan ka kharcha nahi); Commission dukaan deti hai — adaigi par Expense banta hai. Roz ka hisaab Day Close par bhi ada hota hai.</p>
      {msg && <p className="font-bold text-sm mb-2" style={{ color: msg.startsWith("✓") ? "#16A34A" : "#DC2626" }}>{msg}</p>}
      <div className="space-y-3">
        {rows.map((s) => (
          <WaiterRow key={s.staffId} s={s} onPay={pay} />
        ))}
      </div>
    </section>
  );
}

function WaiterRow({ s, onPay }: { s: WaiterSummaryDTO; onPay: (s: WaiterSummaryDTO, kind: "commission" | "salary" | "service", amount: number, method: string, monthLabel?: string) => Promise<void> }) {
  const [commAmt, setCommAmt] = useState("");
  const [svcAmt, setSvcAmt] = useState("");
  const [salAmt, setSalAmt] = useState("");
  const [method, setMethod] = useState("Cash");
  const now = new Date();
  const [monthLabel, setMonthLabel] = useState(now.toLocaleDateString("en-GB", { month: "long", year: "numeric" }));
  const isComm = s.payType === "commission" || s.payType === "both";
  const isSal = s.payType === "salary" || s.payType === "both";
  return (
    <div className="rounded-2xl border-2 border-orange-100 p-3" data-testid={`waiter-row-${s.staffId}`}>
      <div className="flex flex-wrap items-center gap-2">
        <span className="font-black">{s.name}</span>
        <span className="text-[10px] font-black rounded-full px-2 py-0.5 text-white" style={{ background: "#0F172A" }}>
          {s.payType === "salary" ? "Tankhwah" : s.payType === "both" ? "Tankhwah + Commission" : "Commission"}
        </span>
        <span className="text-sm font-bold text-stone-500">Orders (period): {s.ordersPeriod} · Bill: {rs(s.billTotalPeriod)}</span>
        {s.serviceRatingAvg !== null && <span className="text-xs font-black rounded-full px-2 py-0.5" style={{ background: "#FEF3C7", color: "#92400E" }} data-testid={`waiter-rating-${s.staffId}`}>⭐ Service Rating: {s.serviceRatingAvg} ({s.serviceRatingCount})</span>}
        {s.pendingDeposit > 0 && <span className="text-xs font-black rounded-full px-2 py-0.5 text-white" style={{ background: "#D97706" }}>💵 Cashier ko jama baqi: {rs(s.pendingDeposit)}</span>}
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2 text-sm">
        <div className="rounded-xl bg-orange-50 p-2"><div className="text-[11px] font-bold text-stone-500">SERVICE — Period / Baqaya</div><b>{rs(s.servicePeriod)} / {rs(s.serviceBaqaya)}</b></div>
        {isComm && <div className="rounded-xl bg-orange-50 p-2"><div className="text-[11px] font-bold text-stone-500">COMMISSION — Period / Baqaya</div><b>{rs(s.commissionPeriod)} / {rs(s.commissionBaqaya)}</b></div>}
        {isSal && <div className="rounded-xl bg-orange-50 p-2"><div className="text-[11px] font-bold text-stone-500">TANKHWAH — {rs(s.salaryAmount)}/mahina · Kul Ada</div><b>{rs(s.salaryPaidTotal)}</b>{s.salaryLastAt ? <div className="text-[11px] text-stone-500">Aakhri: {new Date(s.salaryLastAt).toLocaleDateString()}</div> : null}</div>}
        <div className="rounded-xl bg-orange-50 p-2"><div className="text-[11px] font-bold text-stone-500">AAJ — Orders / Service{isComm ? " / Commission" : ""}</div><b>{s.ordersToday} / {rs(s.serviceToday)}{isComm ? ` / ${rs(s.commissionToday)}` : ""}</b></div>
      </div>
      <div className="flex flex-wrap gap-2 mt-2 items-end">
        <label className="block"><span className="text-[11px] font-black uppercase text-stone-500">Method</span>
          <select value={method} onChange={(e) => setMethod(e.target.value)} className="block rounded-lg border-2 border-stone-200 px-2 py-2 font-bold bg-white">
            {METHODS.map((m) => <option key={m}>{m}</option>)}
          </select></label>
        {s.serviceBaqaya > 0 && (
          <span className="flex gap-1 items-end">
            <label className="block"><span className="text-[11px] font-black uppercase text-stone-500">Service Ada (Rs)</span>
              <input value={svcAmt} onChange={(e) => setSvcAmt(e.target.value)} inputMode="numeric" placeholder={String(s.serviceBaqaya)} className="block w-28 rounded-lg border-2 border-stone-200 px-2 py-2 font-bold" /></label>
            <button onClick={() => { const n = Number(svcAmt) || s.serviceBaqaya; if (n > 0) void onPay(s, "service", n, method); }} data-testid={`pay-service-${s.staffId}`} className="rounded-lg px-3 py-2 font-black text-white" style={{ background: "#0F172A" }}>Service Ada Karein</button>
          </span>
        )}
        {isComm && s.commissionBaqaya > 0 && (
          <span className="flex gap-1 items-end">
            <label className="block"><span className="text-[11px] font-black uppercase text-stone-500">Commission Ada (Rs)</span>
              <input value={commAmt} onChange={(e) => setCommAmt(e.target.value)} inputMode="numeric" placeholder={String(s.commissionBaqaya)} className="block w-28 rounded-lg border-2 border-stone-200 px-2 py-2 font-bold" /></label>
            <button onClick={() => { const n = Number(commAmt) || s.commissionBaqaya; if (n > 0) void onPay(s, "commission", n, method); }} data-testid={`pay-commission-${s.staffId}`} className="rounded-lg px-3 py-2 font-black text-white" style={{ background: "#16A34A" }}>Commission Ada Karein</button>
          </span>
        )}
        {isSal && (
          <span className="flex gap-1 items-end">
            <label className="block"><span className="text-[11px] font-black uppercase text-stone-500">Tankhwah Ada (Rs)</span>
              <input value={salAmt} onChange={(e) => setSalAmt(e.target.value)} inputMode="numeric" placeholder={String(s.salaryAmount)} className="block w-28 rounded-lg border-2 border-stone-200 px-2 py-2 font-bold" /></label>
            <label className="block"><span className="text-[11px] font-black uppercase text-stone-500">Mahina</span>
              <input value={monthLabel} onChange={(e) => setMonthLabel(e.target.value)} className="block w-36 rounded-lg border-2 border-stone-200 px-2 py-2 font-bold" /></label>
            <button onClick={() => { const n = Number(salAmt); if (n > 0) void onPay(s, "salary", n, method, monthLabel); }} data-testid={`pay-salary-${s.staffId}`} className="rounded-lg px-3 py-2 font-black text-white" style={{ background: "#2563EB" }}>Tankhwah Ada Karein</button>
          </span>
        )}
      </div>
    </div>
  );
}
