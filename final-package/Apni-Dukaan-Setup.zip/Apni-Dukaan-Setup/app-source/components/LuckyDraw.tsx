"use client";

import { useEffect, useMemo, useState } from "react";
import {
  useShop, saveShop, loadShop, loadDeals,
  fetchLuckyDraw, runLuckyDrawApi, markDrawGivenApi,
  type LuckyEntryDTO, type LuckyDrawDTO,
} from "@/lib/store";
import { ApiClientError } from "@/lib/api";

// ─────────────────────────────────────────────────────────────────────────────
// 🎁 LUCKY DRAW (Talha, FIXED-12) — haftawaar draw.
// Entries: cleared bills >= min bill jin par customer ka mobile ho
// (counter / QR / online sab). Prize DRAW ke waqt chuna jata hai:
// active Deal FREE ya Special Gift. Winner ka prize us ke customer
// record par "dena baqi" flag ki tarah rehta hai jab tak De Diya mark
// na ho (status yahin aur Customers mein shared hai).
// ─────────────────────────────────────────────────────────────────────────────

const rs = (n: number) => `Rs ${Math.round(n).toLocaleString()}`;
const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
// Pool ki tareekhein bhi PKT par — orders ke din (dayOf/businessDate)
// Asia/Karachi par gine jate hain; browser ki local tareekh (UTC wagaira)
// istemal ho to raat ke kinare wali entries pool se bahar ho jati theen.
const pktToday = () => new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Karachi" });
type Pool = "week" | "today" | "month" | "custom";
function poolRange(p: Pool, cf: string, ct: string): { from: string; to: string } {
  const today = pktToday();
  if (p === "today") return { from: today, to: today };
  if (p === "month") return { from: `${today.slice(0, 8)}01`, to: today };
  if (p === "custom") return { from: cf || today, to: ct || today };
  const d = new Date(`${today}T12:00:00`); d.setDate(d.getDate() - 6);
  return { from: iso(d), to: today };
}
const maskMobile = (m: string) => (m.length >= 7 ? `${m.slice(0, 4)}***${m.slice(-3)}` : m);
const waNum = (m: string) => { const d = m.replace(/\D/g, ""); return d.startsWith("0") ? `92${d.slice(1)}` : d; };

export default function LuckyDrawSection() {
  const shop = useShop();
  const [pool, setPool] = useState<Pool>("week");
  const [cf, setCf] = useState(pktToday());
  const [ct, setCt] = useState(pktToday());
  const [entries, setEntries] = useState<LuckyEntryDTO[]>([]);
  const [draws, setDraws] = useState<LuckyDrawDTO[]>([]);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [revealName, setRevealName] = useState<string | null>(null);
  const [winner, setWinner] = useState<{ winnerName: string; winnerMobile: string; winnerBillNo: string; prizeDetail: string } | null>(null);
  // Settings form (local)
  const [enabled, setEnabled] = useState(shop.luckyDrawEnabled);
  const [minBill, setMinBill] = useState(shop.luckyDrawMinBill);
  const [day, setDay] = useState(shop.luckyDrawDay);
  const [time, setTime] = useState(shop.luckyDrawTime);
  const [savedMsg, setSavedMsg] = useState("");
  useEffect(() => { setEnabled(shop.luckyDrawEnabled); setMinBill(shop.luckyDrawMinBill); setDay(shop.luckyDrawDay); setTime(shop.luckyDrawTime); }, [shop.luckyDrawEnabled, shop.luckyDrawMinBill, shop.luckyDrawDay, shop.luckyDrawTime]);
  // Prize at draw time — settings wale hint se prefill.
  const deals = useMemo(() => loadDeals().filter((d) => d.active), []);
  const [prizeKind, setPrizeKind] = useState<"deal" | "gift">(shop.luckyDrawPrizeKind);
  const [prizeDealId, setPrizeDealId] = useState(shop.luckyDrawDealId || "");
  const [prizeText, setPrizeText] = useState(shop.luckyDrawPrizeText);
  const range = poolRange(pool, cf, ct);

  async function load() {
    try {
      const r = await fetchLuckyDraw(range.from, range.to);
      setEntries(r.entries); setDraws(r.draws); setErr(r.entriesError ?? "");
    } catch (e) { setErr(e instanceof ApiClientError ? e.message : "Entries load nahi ho sakin"); }
  }
  useEffect(() => { void load(); }, [pool, cf, ct, shop.luckyDrawEnabled, shop.luckyDrawMinBill]); // eslint-disable-line react-hooks/exhaustive-deps

  function saveSettings() {
    saveShop({ ...loadShop(), luckyDrawEnabled: enabled, luckyDrawMinBill: Math.max(0, Math.round(minBill) || 0), luckyDrawDay: day, luckyDrawTime: time, luckyDrawPrizeKind: prizeKind, luckyDrawPrizeText: prizeText.trim() || "Special Gift", luckyDrawDealId: prizeDealId });
    setSavedMsg("✓ Settings save ho gayi");
    setTimeout(() => void load(), 600);
  }

  async function draw() {
    const detail = prizeKind === "deal"
      ? (deals.find((d) => d.id === prizeDealId)?.name ? `${deals.find((d) => d.id === prizeDealId)!.name} — FREE` : "")
      : prizeText.trim();
    if (!detail) { setErr("Prize chunein — deal select karein ya gift likhein"); return; }
    setBusy(true); setErr(""); setWinner(null);
    try {
      const w = await runLuckyDrawApi(range.from, range.to, prizeKind, detail, prizeKind === "deal" ? prizeDealId : undefined);
      // Chhoti si reveal: entries ke naam tezi se badalte hain, phir winner.
      const names = entries.map((e) => e.name || "Customer");
      let i = 0;
      const iv = setInterval(() => { setRevealName(names.length ? names[i % names.length] : w.winnerName); i += 1; }, 90);
      setTimeout(() => { clearInterval(iv); setRevealName(null); setWinner(w); setBusy(false); void load(); }, 1500);
    } catch (e) {
      setBusy(false);
      setErr(e instanceof ApiClientError ? e.message : "Draw nahi ho saka");
    }
  }

  async function given(id: string) {
    try { await markDrawGivenApi(id); void load(); } catch (e) { setErr(e instanceof Error ? e.message : "Mark nahi ho saka"); }
  }

  const shopName = shop.hasCanteen ? shop.canteenName : shop.groceryName;

  return (
    <section className="bg-white rounded-2xl border border-orange-100 shadow-sm p-4" data-testid="lucky-draw-section">
      <h2 className="font-extrabold mb-1">🎁 Lucky Draw — Haftawaar Inaam</h2>
      <p className="text-sm text-stone-500 mb-3">Har hafta ek customer jeet-ta hai. <b>Rs {shop.luckyDrawMinBill.toLocaleString()}+</b> ke har cleared bill par — jis par customer ka mobile ho — ek entry banti hai. Baghair mobile wale (anonymous) bill entry nahi ban sakte.</p>

      {/* Settings */}
      <div className="rounded-2xl border-2 border-amber-200 bg-amber-50/60 p-3 mb-4">
        <div className="flex flex-wrap items-end gap-3">
          <label className="flex items-center gap-2 font-black cursor-pointer">
            <input type="checkbox" checked={enabled} onChange={(e) => setEnabled(e.target.checked)} data-testid="ld-enabled" className="w-5 h-5 accent-orange-500" />
            Lucky Draw ON
          </label>
          <label className="block"><span className="text-[11px] font-black uppercase text-stone-500">Minimum Bill (Rs) — entry ke liye</span>
            <input type="number" min={0} value={minBill} onChange={(e) => setMinBill(Number(e.target.value))} data-testid="ld-min-bill" className="block w-36 rounded-xl border-2 border-stone-200 px-3 py-2 font-bold bg-white" /></label>
          <label className="block"><span className="text-[11px] font-black uppercase text-stone-500">Draw ka Din</span>
            <select value={day} onChange={(e) => setDay(e.target.value)} data-testid="ld-day" className="block rounded-xl border-2 border-stone-200 px-3 py-2 font-bold bg-white">
              {["Peer (Monday)", "Mangal (Tuesday)", "Budh (Wednesday)", "Jumeraat (Thursday)", "Jumma (Friday)", "Hafta (Saturday)", "Itwaar (Sunday)"].map((d) => <option key={d} value={d}>{d}</option>)}
            </select></label>
          <label className="block"><span className="text-[11px] font-black uppercase text-stone-500">Draw ka Waqt</span>
            <input value={time} onChange={(e) => setTime(e.target.value)} data-testid="ld-time" placeholder="8:00 PM" className="block w-32 rounded-xl border-2 border-stone-200 px-3 py-2 font-bold bg-white" /></label>
          <button onClick={saveSettings} data-testid="ld-save-settings" className="rounded-xl px-4 py-2.5 font-black text-white" style={{ background: "#16A34A" }}>Save Settings</button>
          {savedMsg && <span className="font-bold text-sm" style={{ color: "#16A34A" }}>{savedMsg}</span>}
        </div>
        <p className="text-xs text-stone-500 mt-2">Din + waqt Menu Board / Products Board ki upar wali strip par customers ko dikhta hai. Prize har draw par neeche se chuna jata hai — yahan wali settings sirf board ke announcement ke liye hain.</p>
      </div>

      {/* Pool */}
      <div className="flex flex-wrap items-center gap-2 mb-2">
        <span className="font-black">Pool:</span>
        {(["week", "today", "month", "custom"] as Pool[]).map((p) => (
          <button key={p} onClick={() => setPool(p)} data-testid={`ld-pool-${p}`} className="rounded-full px-3 py-1.5 text-xs font-black border-2"
            style={pool === p ? { background: "#F97316", borderColor: "#F97316", color: "#fff" } : { background: "#fff", borderColor: "#E7E5E4" }}>
            {p === "week" ? "Is Hafta" : p === "today" ? "Aaj" : p === "month" ? "Is Mahina" : "Custom"}
          </button>
        ))}
        {pool === "custom" && (<>
          <input type="date" value={cf} onChange={(e) => setCf(e.target.value)} className="rounded-lg border-2 border-stone-200 px-2 py-1.5 font-bold" />
          <input type="date" value={ct} onChange={(e) => setCt(e.target.value)} className="rounded-lg border-2 border-stone-200 px-2 py-1.5 font-bold" />
        </>)}
      </div>
      <div className="rounded-2xl text-center py-4 mb-3" style={{ background: "#0F172A" }}>
        <div className="text-5xl font-black text-white" data-testid="ld-entries-count">{entries.length}</div>
        <div className="font-bold" style={{ color: "#FDBA74" }}>Entries — {range.from} se {range.to} tak (jeeti hui entries shamil nahi)</div>
      </div>
      {entries.length > 0 && (
        <div className="max-h-44 overflow-y-auto mb-3 rounded-xl border border-stone-100" data-testid="ld-entries-list">
          {entries.map((e) => (
            <div key={e.orderId} className="flex justify-between px-3 py-1.5 text-sm border-b border-stone-100">
              <span className="font-bold">{e.name || "Customer"} <span className="text-stone-400">{maskMobile(e.mobile)}</span></span>
              <span className="font-bold">{e.billNo} · {rs(e.total)}</span>
            </div>
          ))}
        </div>
      )}

      {/* Prize + Draw */}
      <div className="flex flex-wrap items-end gap-3 mb-3">
        <label className="block"><span className="text-[11px] font-black uppercase text-stone-500">Prize ki Qisam</span>
          <select value={prizeKind} onChange={(e) => setPrizeKind(e.target.value as "deal" | "gift")} data-testid="ld-prize-kind" className="block rounded-xl border-2 border-stone-200 px-3 py-2 font-bold bg-white">
            <option value="deal">🎁 Deal FREE</option>
            <option value="gift">🎀 Special Gift</option>
          </select></label>
        {prizeKind === "deal" ? (
          <label className="block"><span className="text-[11px] font-black uppercase text-stone-500">Deal chunein (active deals)</span>
            <select value={prizeDealId} onChange={(e) => setPrizeDealId(e.target.value)} data-testid="ld-prize-deal" className="block rounded-xl border-2 border-stone-200 px-3 py-2 font-bold bg-white">
              <option value="">— Deal chunein —</option>
              {deals.map((d) => <option key={d.id} value={d.id}>{d.name} ({rs(d.price)})</option>)}
            </select></label>
        ) : (
          <label className="block flex-1 min-w-[200px]"><span className="text-[11px] font-black uppercase text-stone-500">Gift ki Tafseel</span>
            <input value={prizeText} onChange={(e) => setPrizeText(e.target.value)} data-testid="ld-prize-text" placeholder="e.g. Ek Zinger Burger Free" className="block w-full rounded-xl border-2 border-stone-200 px-3 py-2 font-bold bg-white" /></label>
        )}
        <button onClick={() => void draw()} disabled={busy || entries.length === 0 || !shop.luckyDrawEnabled} data-testid="ld-draw-btn"
          className="rounded-2xl px-6 py-3 font-black text-white text-lg disabled:opacity-50" style={{ background: "#F97316" }}>
          {busy ? "🎲 Draw ho raha hai…" : "🎲 Draw Nikalein"}
        </button>
      </div>
      {!shop.luckyDrawEnabled && <p className="font-bold text-sm mb-2" style={{ color: "#DC2626" }}>Lucky Draw OFF hai — pehle upar se ON karke Save karein.</p>}
      {err && <p className="font-bold text-sm mb-2" style={{ color: "#DC2626" }} role="alert">⚠️ {err}</p>}
      {revealName && <div className="text-center py-6 font-black text-3xl" data-testid="ld-reveal">🎲 {revealName} …</div>}
      {winner && (
        <div className="rounded-2xl p-4 text-center mb-3 pop-in" style={{ background: "#F0FDF4", border: "2px solid #16A34A" }} data-testid="ld-winner">
          <div className="text-4xl mb-1">🏆</div>
          <div className="text-2xl font-black">{winner.winnerName || "Customer"}</div>
          <div className="font-bold text-stone-600">Bill {winner.winnerBillNo} · {winner.winnerMobile} · Inaam: <b>{winner.prizeDetail}</b></div>
          <a href={`https://wa.me/${waNum(winner.winnerMobile)}?text=${encodeURIComponent(`🎉 Mubarak ho ${winner.winnerName}! Aap ${shopName} ke Lucky Draw mein jeet gaye hain. Inaam: ${winner.prizeDetail}. Counter par aakar apna inaam le jayein. Shukriya!`)}`}
            target="_blank" rel="noreferrer" data-testid="ld-whatsapp"
            className="inline-block mt-3 rounded-xl px-5 py-2.5 font-black text-white" style={{ background: "#16A34A" }}>📱 WhatsApp par Mubarakbaad</a>
        </div>
      )}

      {/* History */}
      <h3 className="font-black mt-4 mb-2">🏆 Draw History</h3>
      {draws.length === 0 ? <p className="font-bold text-stone-400 text-sm">Abhi koi draw nahi hua.</p> : (
        <div className="space-y-1.5" data-testid="ld-history">
          {draws.map((d) => (
            <div key={d.id} className="flex flex-wrap items-center gap-2 rounded-xl border-2 border-stone-100 px-3 py-2 text-sm">
              <span className="font-black">{d.winnerName}</span>
              <span className="font-bold text-stone-500">{maskMobile(d.winnerMobile)} · Bill {d.winnerBillNo}</span>
              <span className="font-bold">🎁 {d.prizeDetail}</span>
              <span className="text-xs font-bold text-stone-400">{new Date(d.createdAt).toLocaleDateString()}</span>
              {d.status === "pending"
                ? <><span className="text-[10px] font-black rounded-full px-2 py-0.5 text-white" style={{ background: "#D97706" }}>DENA BAQI</span>
                  <button onClick={() => void given(d.id)} data-testid={`ld-given-${d.id}`} className="ml-auto rounded-lg px-3 py-1.5 font-black text-white text-xs" style={{ background: "#16A34A" }}>✓ De Diya</button></>
                : <span className="text-[10px] font-black rounded-full px-2 py-0.5 text-white ml-auto" style={{ background: "#16A34A" }}>✓ DE DIYA</span>}
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
