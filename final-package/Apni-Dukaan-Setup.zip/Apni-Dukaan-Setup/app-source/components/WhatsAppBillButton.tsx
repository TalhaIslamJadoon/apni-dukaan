"use client";

import { Order, useShop, whatsappBillUrl } from "@/lib/store";

// 📲 WhatsApp par Bill bhejein (B2) — bill par customer mobile ho tab hi
// button ata hai. wa.me hand-off hai: link khulta hai, cashier khud
// WhatsApp mein Send dabata hai (koi auto-send nahi hota).
export default function WhatsAppBillButton({ order, className }: { order: Order; className?: string }) {
  const shop = useShop();
  const url = whatsappBillUrl(order, shop);
  if (!url) return null;
  return (
    <a href={url} target="_blank" rel="noreferrer" data-testid="whatsapp-bill-btn"
      className={className ?? "flex-1 rounded-2xl py-3.5 font-black text-white shadow text-center"}
      style={{ background: "#25D366", color: "#07351B" }}>
      📲 WhatsApp par Bill bhejein
    </a>
  );
}
