"use client";

import { useState } from "react";
import { Order, SaleReturn, useShop } from "@/lib/store";
import { apiPost, ApiClientError } from "@/lib/api";

// ── Sale Return (B6) ───────────────────────────────────────────────────────
// Cleared bill ki lines wapas: qty stepper (max = sold − pehle wapas),
// server stock exactly-once wapas karta hai; Udhaar bill par khata
// adjustment. Mukammal hone par return slip (printable).
const money = (n: number) => `Rs ${Math.round(n).toLocaleString()}`;

export default function SaleReturnModal(props: { order: Order; onClose: () => void; onDone?: () => void }) {
  const shop = useShop();
  const { order } = props;
  const [qtys, setQtys] = useState<Record<string, number>>({});
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [done, setDone] = useState<SaleReturn | null>(null);

  const remaining = (l: Order["lines"][number]) => Math.max(0, l.qty - (l.returnedQty ?? 0));
  const total = order.lines.reduce((s, l) => s + (qtys[l.lineId ?? ""] ?? 0) * l.price, 0);

  async function submit() {
    const lines = order.lines
      .filter((l) => l.lineId && (qtys[l.lineId] ?? 0) > 0)
      .map((l) => ({ lineId: l.lineId as string, qty: qtys[l.lineId as string] }));
    if (!lines.length) { setErr("⚠️ Kam az kam ek line ki qty select karein"); return; }
    setBusy(true); setErr("");
    try {
      const d = await apiPost<{ return: SaleReturn }>("/staff/returns", { orderId: order.id, lines });
      setDone(d.return);
      props.onDone?.();
    } catch (e) {
      setErr(e instanceof ApiClientError ? `⚠️ ${e.message}` : "⚠️ Return nahi ho saka — dobara koshish karein");
    } finally { setBusy(false); }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/60 overflow-y-auto p-4">
      <div className="max-w-lg mx-auto py-4 pop-in" data-testid="return-modal">
        {!done ? (
          <div className="bg-white rounded-2xl shadow-xl p-5 text-stone-900">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-2xl">↩️</span>
              <h3 className="font-black text-lg">Sale Return — Bill {order.billNo ?? ""}</h3>
              <button onClick={props.onClose} className="ml-auto rounded-lg px-3 py-1.5 font-bold bg-stone-100 text-sm">✕</button>
            </div>
            <p className="text-[13px] font-bold text-stone-500 mb-3">
              Wapas wali lines ki qty select karein — stock khud wapas ho jayega. Refund <b>{order.payment}</b> par hoga
              {order.payment === "Udhaar" ? " (khata baqaya kam ho jayega)" : ""}.
            </p>
            <div className="space-y-2">
              {order.lines.map((l) => {
                const rem = remaining(l);
                const key = l.lineId ?? "";
                const q = qtys[key] ?? 0;
                return (
                  <div key={key || l.name} className="flex items-center gap-2 rounded-xl border-2 border-stone-100 px-3 py-2">
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-sm leading-snug">{l.name}</div>
                      <div className="text-xs font-bold text-stone-400">
                        Bika: {l.qty} · {money(l.price)}{(l.returnedQty ?? 0) > 0 ? ` · Pehle wapas: ${l.returnedQty}` : ""} · Baqi wapas ho sakta: {rem}
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button disabled={rem <= 0} onClick={() => setQtys((s) => ({ ...s, [key]: Math.max(0, q - 1) }))} className="w-8 h-8 rounded-lg bg-stone-100 font-black disabled:opacity-40">−</button>
                      <span className="w-8 text-center font-black" data-testid={`return-qty-${key}`}>{q}</span>
                      <button disabled={rem <= 0} onClick={() => setQtys((s) => ({ ...s, [key]: Math.min(rem, q + 1) }))} className="w-8 h-8 rounded-lg bg-stone-100 font-black disabled:opacity-40">+</button>
                    </div>
                  </div>
                );
              })}
            </div>
            {err && <div className="mt-3 rounded-xl bg-red-50 border border-red-200 px-3 py-2 text-sm font-bold text-red-700">{err}</div>}
            <div className="flex items-center gap-2 mt-4">
              <span className="font-black">Refund: {money(total)}</span>
              <button onClick={() => void submit()} disabled={busy || total <= 0} data-testid="return-submit"
                className="ml-auto rounded-xl px-5 py-3 font-black text-white disabled:opacity-50" style={{ background: "#DC2626" }}>
                {busy ? "Ho raha hai…" : "↩️ Return Confirm karein"}
              </button>
            </div>
          </div>
        ) : (
          <div>
            <div id="thermal-bill" className="bg-white text-black mx-auto p-4 shadow-xl" style={{ width: "80mm", fontFamily: "ui-monospace, monospace" }} data-testid="return-slip">
              <div className="text-center">
                <div className="font-black text-lg">{done.mode === "grocery" ? shop.groceryName : shop.canteenName}</div>
                <div className="font-black">↩️ SALE RETURN SLIP</div>
                <div className="text-xs">Original Bill: {done.billNo} · {new Date(done.createdAt).toLocaleString("en-GB")}</div>
                <div className="text-xs">Cashier: {done.byName}</div>
              </div>
              <div className="border-t border-dashed border-black my-2" />
              {done.lines.map((l, i) => (
                <div key={i} className="flex justify-between text-sm">
                  <span>{l.name} × {l.qty}</span><b>{money(l.total)}</b>
                </div>
              ))}
              <div className="border-t border-dashed border-black my-2" />
              <div className="flex justify-between font-black"><span>REFUND ({done.refundMethod})</span><span>{money(done.total)}</span></div>
              <div className="text-center text-xs mt-2">Stock wapas kar diya gaya hai.</div>
            </div>
            <div className="flex gap-2 mt-4 no-print max-w-md mx-auto">
              <button onClick={() => window.print()} className="flex-1 rounded-2xl py-3 font-black bg-white text-stone-900 shadow">🖨️ Slip Print</button>
              <button onClick={props.onClose} className="flex-1 rounded-2xl py-3 font-black text-white shadow" style={{ background: "#16A34A" }}>✓ Done</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
