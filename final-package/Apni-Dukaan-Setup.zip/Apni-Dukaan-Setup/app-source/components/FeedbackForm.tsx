"use client";
import { useEffect, useState } from "react";
import { submitFeedback, fetchPublicWaiters } from "@/lib/store";

// ── FIXED-12: Table-QR Feedback / Shikayat / Tajweez form ───────────────
// Same table QR ka doosra kaam: bina account ke feedback. 6 categories ki
// alag star rows (sab optional), waiter dropdown (session/order se
// pre-selected), complaint/suggestion par text lazmi, menu request par
// item ka naam lazmi.
const CATS: { key: "taste" | "service" | "cleanliness" | "speed" | "rates" | "behaviour"; label: string }[] = [
  { key: "taste", label: "🍽️ Khane ka Taste" },
  { key: "service", label: "🛎️ Waiter ki Service" },
  { key: "cleanliness", label: "🧹 Safai" },
  { key: "speed", label: "⚡ Order Milne ki Speed" },
  { key: "rates", label: "💰 Rates" },
  { key: "behaviour", label: "🤝 Behaviour (Bartao)" },
];

export default function FeedbackForm(props: {
  tableNo?: number | null;
  prefillName?: string;
  prefillMobile?: string;
  preselectWaiterId?: string;
  orderId?: string;
  testidPrefix?: string;
}) {
  const p = props.testidPrefix ?? "fb";
  const [open, setOpen] = useState(false);
  const [done, setDone] = useState(false);
  const [kind, setKind] = useState<"feedback" | "complaint" | "suggestion">("feedback");
  const [sub, setSub] = useState<"general" | "menu_item">("general");
  const [itemName, setItemName] = useState("");
  const [ratings, setRatings] = useState<Record<string, number>>({});
  const [waiters, setWaiters] = useState<{ id: string; name: string }[]>([]);
  const [waiterId, setWaiterId] = useState(props.preselectWaiterId ?? "");
  const [name, setName] = useState(props.prefillName ?? "");
  const [mobile, setMobile] = useState(props.prefillMobile ?? "");
  const [comment, setComment] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => { if (open) fetchPublicWaiters().then(setWaiters); }, [open ]);
  useEffect(() => { if (props.preselectWaiterId) setWaiterId(props.preselectWaiterId); }, [props.preselectWaiterId]);
  useEffect(() => { if (props.prefillName && !name) setName(props.prefillName); }, [props.prefillName]);
  useEffect(() => { if (props.prefillMobile && !mobile) setMobile(props.prefillMobile); }, [props.prefillMobile]);

  if (done) {
    return (
      <div className="bg-emerald-600/20 border border-emerald-400/40 rounded-2xl p-4 text-center" data-testid={`${p}-thanks`}>
        <div className="text-3xl">🙏</div>
        <p className="font-black text-emerald-300 mt-1">Shukriya! Aap ki ray mil gayi</p>
        <p className="text-xs text-stone-300">Aap ki feedback se hamari service behtar hogi.</p>
      </div>
    );
  }
  if (!open) {
    return (
      <button onClick={() => setOpen(true)} data-testid={`${p}-open`}
        className="w-full bg-white/10 hover:bg-white/15 border border-white/20 text-white font-bold py-3 rounded-2xl">
        📝 Feedback Dein — Ray / Shikayat / Tajweez
      </button>
    );
  }
  const inputCls = "w-full bg-white/10 border border-white/25 rounded-xl px-3 py-2 text-white placeholder:text-stone-400 outline-none focus:border-orange-400";
  const labelCls = "block text-[11px] font-bold uppercase tracking-wide text-stone-300 mb-1";
  async function submit() {
    setErr("");
    const anyRating = CATS.some((c) => (ratings[c.key] ?? 0) > 0);
    if (kind === "complaint" && !comment.trim()) { setErr("Shikayat ke liye tafseel likhna lazmi hai"); return; }
    if (kind === "suggestion" && sub !== "menu_item" && !comment.trim()) { setErr("Tajweez ke liye tafseel likhna lazmi hai"); return; }
    if (kind === "suggestion" && sub === "menu_item" && !itemName.trim()) { setErr("Item ka naam likhein jo menu mein add karwana hai"); return; }
    if (kind === "feedback" && !anyRating && !comment.trim()) { setErr("Kam az kam ek rating dein ya kuch likhein"); return; }
    setBusy(true);
    try {
      await submitFeedback({
        kind,
        taste: ratings.taste || null, service: ratings.service || null,
        cleanliness: ratings.cleanliness || null, speed: ratings.speed || null,
        rates: ratings.rates || null, behaviour: ratings.behaviour || null,
        comment: comment.trim(), source: "table", tableNo: props.tableNo ?? null,
        orderId: props.orderId, customerName: name.trim(), customerMobile: mobile.trim(),
        waiterId: waiterId || undefined,
        suggestionType: kind === "suggestion" ? sub : "general",
        itemName: kind === "suggestion" && sub === "menu_item" ? itemName.trim() : undefined,
      });
      setDone(true);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Feedback nahi gaya — dobara koshish karein");
    } finally { setBusy(false); }
  }
  return (
    <div className="bg-white/5 border border-white/15 rounded-2xl p-4" data-testid={`${p}-form`}>
      <div className="flex items-center justify-between">
        <h3 className="font-black text-white">📝 Feedback Dein</h3>
        <button className="text-stone-400 text-sm" onClick={() => setOpen(false)}>✕ Band</button>
      </div>
      <div className="grid grid-cols-3 gap-2 mt-3">
        {([["feedback", "💬 Ray"], ["complaint", "🚨 Shikayat"], ["suggestion", "💡 Tajweez"]] as const).map(([k, label]) => (
          <button key={k} data-testid={`${p}-kind-${k}`} onClick={() => setKind(k)}
            className={`py-2 rounded-xl font-bold text-sm border ${kind === k ? (k === "complaint" ? "bg-red-600 border-red-400 text-white" : "bg-orange-500 border-orange-300 text-white") : "bg-white/10 border-white/20 text-stone-200"}`}>
            {label}
          </button>
        ))}
      </div>
      {kind === "suggestion" && (
        <div className="grid grid-cols-2 gap-2 mt-2">
          <button data-testid={`${p}-sub-general`} onClick={() => setSub("general")}
            className={`py-2 rounded-xl font-bold text-sm border ${sub === "general" ? "bg-sky-600 border-sky-300 text-white" : "bg-white/10 border-white/20 text-stone-200"}`}>💡 Aam Tajweez</button>
          <button data-testid={`${p}-sub-menu`} onClick={() => setSub("menu_item")}
            className={`py-2 rounded-xl font-bold text-sm border ${sub === "menu_item" ? "bg-purple-600 border-purple-300 text-white" : "bg-white/10 border-white/20 text-stone-200"}`}>🍔 Nayi Cheez Menu Mein</button>
        </div>
      )}
      {kind === "suggestion" && sub === "menu_item" && (
        <label className="block mt-3">
          <span className={labelCls}>Konsi cheez menu mein add ho? (lazmi)</span>
          <input className={inputCls} value={itemName} onChange={(e) => setItemName(e.target.value)}
            placeholder="e.g. Chicken Shawarma" data-testid={`${p}-item-name`} />
        </label>
      )}
      <label className="block mt-3">
        <span className={labelCls}>Aap ko kis waiter ne serve kiya?</span>
        <select className={`${inputCls} [&>option]:text-slate-900`} value={waiterId} onChange={(e) => setWaiterId(e.target.value)} data-testid={`${p}-waiter`}>
          <option value="">Pata nahi / koi nahi</option>
          {waiters.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
        </select>
      </label>
      <div className="mt-3 space-y-2">
        {CATS.map((c) => (
          <div key={c.key} className="flex items-center justify-between gap-2">
            <span className="text-sm text-stone-200 font-semibold">{c.label}</span>
            <span className="flex gap-0.5">
              {[1, 2, 3, 4, 5].map((n) => (
                <button key={n} data-testid={`${p}-star-${c.key}-${n}`}
                  onClick={() => setRatings((r) => ({ ...r, [c.key]: r[c.key] === n ? 0 : n }))}
                  className={`text-2xl leading-none ${(ratings[c.key] ?? 0) >= n ? "text-amber-400" : "text-stone-600"}`}>★</button>
              ))}
            </span>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-2 mt-3">
        <label className="block">
          <span className={labelCls}>Aap ka Naam</span>
          <input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} data-testid={`${p}-name`} />
        </label>
        <label className="block">
          <span className={labelCls}>Mobile Number</span>
          <input className={inputCls} value={mobile} onChange={(e) => setMobile(e.target.value)} inputMode="tel" data-testid={`${p}-mobile`} />
        </label>
      </div>
      <label className="block mt-3">
        <span className={labelCls}>{kind === "complaint" ? "Tafseel (lazmi)" : "Tafseel (ikhtiyari)"}</span>
        <textarea className={inputCls} rows={3} value={comment} onChange={(e) => setComment(e.target.value)}
          maxLength={1000} placeholder="Apni ray, shikayat ya tajweez likhein…" data-testid={`${p}-comment`} />
      </label>
      {err && <p className="text-red-300 text-sm font-semibold mt-2" data-testid={`${p}-error`}>⚠️ {err}</p>}
      <button disabled={busy} onClick={submit} data-testid={`${p}-submit`}
        className="w-full mt-3 bg-orange-500 hover:bg-orange-600 disabled:opacity-50 text-white font-black py-3 rounded-2xl">
        {busy ? "Bhej raha hai…" : "📩 Bhej Dein"}
      </button>
    </div>
  );
}
