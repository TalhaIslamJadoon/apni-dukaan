"use client";

import { useState } from "react";

// ─────────────────────────────────────────────────────────────────────────────
// EmojiPicker — shared emoji chunne wala popup (Talha, 19 Nov 2026:
// "emoji bhi saare show ho jayein jo canteen mein hote hain").
// Item forms ke emoji field ke sath lagta hai: button dabane par grid
// khulta hai, emoji par tap = select. Haath se likhna/paste karna bhi
// chalta rehta hai — ye sirf chunne ki sahulat hai.
// Pehla hissa: canteen ka khana-peena (90). Doosra: aam emoji jo
// catalogue/boards mein istemal hote hain (48).
// ─────────────────────────────────────────────────────────────────────────────

export const FOOD_EMOJIS = [
  "🍔", "🍕", "🍟", "🌭", "🥪", "🌮", "🌯", "🥙", "🧆", "🥗",
  "🍜", "🍝", "🍛", "🍲", "🍣", "🍱", "🥟", "🍤", "🍙", "🍚",
  "🍘", "🍥", "🍢", "🍡", "🍧", "🍨", "🍦", "🧁", "🍰", "🍮",
  "🍭", "🍬", "🍫", "🍩", "🍪", "☕", "🍵", "🧃", "🥤", "🥛",
  "🧋", "🍺", "🥂", "🍷", "🍸", "🍹", "🧊", "🍳", "🥞", "🧇",
  "🥓", "🍞", "🥐", "🥖", "🧀", "🥚", "🍗", "🍖", "🥩", "🍿",
  "🥜", "🍯", "🫖", "🥄", "🍴", "🍽️", "🥢", "🥡", "🍎", "🍐",
  "🍊", "🍋", "🍉", "🍇", "🍓", "🍒", "🍑", "🥭", "🍍", "🥝",
  "🍅", "🥑", "🥦", "🥒", "🌶️", "🌽", "🥕", "🥔", "🍠", "🥥",
];

export const GENERAL_EMOJIS = [
  "⭐", "❤️", "🔥", "👍", "🎉", "✨", "💯", "🆕", "🏆", "👑",
  "💰", "🏷️", "📦", "🚚", "⏰", "📞", "✅", "❌", "⚠️", "🎁",
  "👗", "👔", "👞", "👠", "💍", "🧕", "📱", "💊", "🧴", "🧼",
  "🧺", "🛒", "🏪", "🌙", "☀️", "❄️", "🔔", "📌", "📍", "🕌",
  "🩺", "⚕️", "👶", "🍼", "🎂", "📚", "✏️", "⚽",
];

export default function EmojiPicker({ onPick, testid = "emoji-picker" }: { onPick: (emoji: string) => void; testid?: string }) {
  const [open, setOpen] = useState(false);
  return (
    <span className="relative inline-block shrink-0">
      <button type="button" data-testid={`${testid}-open`} onClick={() => setOpen((o) => !o)}
        title="Emoji list se chunein"
        className="rounded-xl border-2 border-stone-200 bg-white px-2.5 py-2.5 text-lg leading-none transition hover:border-orange-300 active:scale-95">
        😀
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div data-testid={`${testid}-panel`}
            className="absolute right-0 z-50 mt-1 w-[324px] max-w-[86vw] max-h-[336px] overflow-y-auto rounded-2xl border-2 border-orange-100 bg-white p-2.5 shadow-2xl">
            <div className="text-[11px] font-black tracking-wide text-stone-500 mb-1">🍔 KHANA PEENA — CANTEEN</div>
            <div className="grid grid-cols-8 gap-0.5">
              {FOOD_EMOJIS.map((e) => (
                <button type="button" key={e} data-emoji={e}
                  onClick={() => { onPick(e); setOpen(false); }}
                  className="rounded-lg p-1.5 text-[22px] leading-none transition hover:bg-orange-50 active:scale-90">
                  {e}
                </button>
              ))}
            </div>
            <div className="text-[11px] font-black tracking-wide text-stone-500 mt-2.5 mb-1">✨ AAM EMOJI</div>
            <div className="grid grid-cols-8 gap-0.5">
              {GENERAL_EMOJIS.map((e) => (
                <button type="button" key={e} data-emoji={e}
                  onClick={() => { onPick(e); setOpen(false); }}
                  className="rounded-lg p-1.5 text-[22px] leading-none transition hover:bg-orange-50 active:scale-90">
                  {e}
                </button>
              ))}
            </div>
            <p className="mt-2 text-[11px] font-bold text-stone-400">Emoji par tap karein — ya field mein khud likh/paste bhi sakte hain.</p>
          </div>
        </>
      )}
    </span>
  );
}
