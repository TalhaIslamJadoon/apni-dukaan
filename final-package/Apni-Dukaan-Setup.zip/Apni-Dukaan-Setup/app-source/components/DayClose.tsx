"use client";

import { useCallback, useEffect, useState } from "react";
import { DayCloseFigures, DayCloseRecord, SaleReturn, useShop } from "@/lib/store";
import { apiGet, apiPost, ApiClientError } from "@/lib/api";

// ── Day Close / Z-Report (B5) + Returns list (B6) ─────────────────────────
// Figures server gin ta hai. Save = sirf record (paisa move nahi hota).
// Expected cash = cash bikri + cash wasooli − cash kharchay − cash refunds.
const money = (n: number) => `Rs ${Math.round(n).toLocaleString()}`;
const todayPKT = () => new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Karachi" });

function FiguresTable({ f }: { f: DayCloseFigures }) {
  const rows: [string, string][] = [
    ["🧾 Bills (cleared)", String(f.billsCount)],
    ...Object.entries(f.byMethod).map(([m, v]) => [`Bikri — ${m}`, money(v)] as [string, string]),
    ["💵 Cash Bikri", money(f.cashSales)],
    ["💰 Cash Wasooli (Udhaar)", money(f.cashWasooli)],
    ["🧾 Kharchay (cash)", `− ${money(f.cashExpenses)}`],
    ["↩️ Cash Refunds (returns)", `− ${money(f.cashRefunds)}`],
    ["📒 Udhaar diya (aaj)", money(f.udhaarGiven)],
    ["📗 Udhaar wasooli (kul)", money(f.udhaarReceived)],
    ["↩️ Returns (kul)", money(f.returnsTotal)],
  ];
  return (
    <table className="w-full text-sm">
      <tbody>
        {rows.map(([k, v]) => (
          <tr key={k} className="border-b border-stone-100">
            <td className="py-1.5 pr-2 font-bold text-stone-600">{k}</td>
            <td className="py-1.5 text-right font-extrabold">{v}</td>
          </tr>
        ))}
        <tr>
          <td className="py-2 pr-2 font-black">💵 Expected Cash (gallay mein hona chahiye)</td>
          <td className="py-2 text-right font-black text-base">{money(f.expectedCash)}</td>
        </tr>
      </tbody>
    </table>
  );
}

export default function DayCloseSection() {
  const shop = useShop();
  const [date, setDate] = useState(todayPKT());
  const [figures, setFigures] = useState<DayCloseFigures | null>(null);
  const [counted, setCounted] = useState("");
  const [history, setHistory] = useState<DayCloseRecord[]>([]);
  const [returns, setReturns] = useState<SaleReturn[]>([]);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const [printRec, setPrintRec] = useState<DayCloseRecord | null>(null);

  const load = useCallback(async (d: string) => {
    try {
      const [f, h, r] = await Promise.all([
        apiGet<{ figures: DayCloseFigures }>(`/owner/day-closes?date=${d}`),
        apiGet<{ closes: DayCloseRecord[] }>("/owner/day-closes"),
        apiGet<{ returns: SaleReturn[] }>("/owner/returns"),
      ]);
      setFigures(f.figures); setHistory(h.closes); setReturns(r.returns);
    } catch { setMsg("⚠️ Figures load nahi ho sakay"); }
  }, []);
  useEffect(() => { void load(date); }, [load, date]);

  const countedNum = parseInt(counted, 10) || 0;
  const farq = figures ? countedNum - figures.expectedCash : 0;

  async function save() {
    if (!figures) return;
    setBusy(true); setMsg("");
    try {
      const d = await apiPost<{ close: { farq: number } }>("/owner/day-closes", { date, countedCash: countedNum });
      setMsg(`✓ Day Close save ho gaya — Farq: ${money(d.close.farq)}`);
      void load(date);
    } catch (e) {
      setMsg(e instanceof ApiClientError ? `⚠️ ${e.message}` : "⚠️ Save nahi ho saka");
    } finally { setBusy(false); }
  }

  return (
    <section className="rounded-3xl bg-white shadow p-4 sm:p-5 mb-5" data-testid="dayclose-section">
      <div className="flex flex-wrap items-center gap-2 mb-1">
        <h3 className="font-black text-lg">🌙 Day Close — Z Report</h3>
        <span className="text-[11px] font-black px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800">SIRF REPORT — PAISA MOVE NAHI HOTA</span>
      </div>
      <p className="text-[13px] font-bold text-stone-500 mb-3">
        Din ke aakhir par gallay ka cash gin kar yahan likhein — system bata dega kitna farq hai. Kharchay hamesha cash-out ginay jate hain.
      </p>
      <div className="flex flex-wrap items-end gap-2 mb-3">
        <label className="block">
          <span className="block text-[11px] font-bold uppercase tracking-wide text-stone-500 mb-0.5">Business Date</span>
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} data-testid="dayclose-date"
            className="rounded-xl border-2 border-stone-200 px-3 py-2.5 outline-none focus:border-orange-500" />
        </label>
        <label className="block w-48">
          <span className="block text-[11px] font-bold uppercase tracking-wide text-stone-500 mb-0.5">Gina Hua Cash (Rs)</span>
          <input value={counted} onChange={(e) => setCounted(e.target.value.replace(/[^0-9]/g, ""))} placeholder="0" inputMode="numeric" data-testid="dayclose-counted"
            className="w-full rounded-xl border-2 border-stone-200 px-3 py-2.5 outline-none focus:border-orange-500" />
        </label>
        {figures && counted !== "" && (
          <div className="rounded-xl px-4 py-2.5 font-black" data-testid="dayclose-farq"
            style={{ background: farq === 0 ? "#DCFCE7" : "#FEE2E2", color: farq === 0 ? "#166534" : "#991B1B" }}>
            Farq: {farq > 0 ? "+" : ""}{money(farq)}{farq === 0 ? " ✓ Barabar" : ""}
          </div>
        )}
        <button onClick={() => void save()} disabled={busy || !figures || counted === ""} data-testid="dayclose-save"
          className="rounded-xl px-5 py-2.5 font-black text-white disabled:opacity-50" style={{ background: "#0F172A" }}>
          {busy ? "Save ho raha…" : "💾 Day Close Save karein"}
        </button>
      </div>
      {msg && <div className="mb-3 rounded-xl bg-stone-50 border border-stone-200 px-3 py-2 text-sm font-bold">{msg}</div>}
      {figures ? <FiguresTable f={figures} /> : <div className="font-bold text-stone-400">Figures load ho rahe hain…</div>}

      <h4 className="font-extrabold mt-5 mb-2">🕐 Purani Day Closes</h4>
      {history.length === 0 ? <div className="font-bold text-stone-400 text-sm">Abhi koi day close save nahi hua.</div> : (
        <div className="space-y-1.5" data-testid="dayclose-history">
          {history.map((h) => (
            <div key={h.id} className="flex flex-wrap items-center gap-2 rounded-xl border-2 border-stone-100 px-3 py-2 text-sm">
              <b>{h.date}</b>
              <span className="font-bold text-stone-500">{h.cashierName}</span>
              <span>Expected: <b>{money(h.expectedCash)}</b></span>
              <span>Gina: <b>{money(h.countedCash)}</b></span>
              <span className="font-black" style={{ color: h.farq === 0 ? "#16A34A" : "#DC2626" }}>Farq: {h.farq > 0 ? "+" : ""}{money(h.farq)}</span>
              <button onClick={() => setPrintRec(h)} className="ml-auto rounded-lg px-3 py-1.5 font-bold bg-stone-100 text-xs">🖨️ Report dekhein / Print</button>
            </div>
          ))}
        </div>
      )}

      <h4 className="font-extrabold mt-5 mb-2">↩️ Sale Returns</h4>
      {returns.length === 0 ? <div className="font-bold text-stone-400 text-sm">Abhi koi return nahi hua.</div> : (
        <div className="space-y-1.5" data-testid="returns-list">
          {returns.slice(0, 30).map((r) => (
            <div key={r.id} className="rounded-xl border-2 border-stone-100 px-3 py-2 text-sm">
              <div className="flex flex-wrap gap-2 items-center">
                <b>Bill {r.billNo}</b>
                <span className="text-[10px] font-black px-1.5 py-0.5 rounded-full bg-stone-100">{r.mode === "grocery" ? "🛒 Grocery" : "🍔 Canteen"}</span>
                <span className="font-bold text-stone-500">{new Date(r.createdAt).toLocaleString("en-GB")}</span>
                <span>Refund ({r.refundMethod}): <b style={{ color: "#DC2626" }}>{money(r.total)}</b></span>
                <span className="font-bold text-stone-400">{r.byName}</span>
              </div>
              <div className="text-xs font-bold text-stone-500 mt-0.5">{r.lines.map((l) => `${l.name} × ${l.qty}`).join(" · ")}</div>
            </div>
          ))}
        </div>
      )}

      {printRec && (
        <div className="fixed inset-0 z-50 bg-black/60 overflow-y-auto p-4">
          <div className="max-w-2xl mx-auto py-4 pop-in">
            <div id="print-sheet" className="bg-white rounded-2xl shadow-xl p-5 text-stone-900">
              <div className="text-center mb-3">
                <div className="text-xl font-black">🌙 Day Close — Z Report</div>
                <div className="font-bold">{shop.canteenName} · {printRec.date}</div>
                <div className="text-sm text-stone-500">Cashier: {printRec.cashierName} · Save: {new Date(printRec.createdAt).toLocaleString("en-GB")}</div>
              </div>
              <FiguresTable f={printRec} />
              <div className="mt-3 space-y-1 text-sm">
                <div className="flex justify-between"><span className="font-bold text-stone-500">Gina Hua Cash</span><b>{money(printRec.countedCash)}</b></div>
                <div className="flex justify-between text-base border-t-2 border-stone-200 pt-1.5">
                  <span className="font-black">Farq</span>
                  <b style={{ color: printRec.farq === 0 ? "#16A34A" : "#DC2626" }}>{printRec.farq > 0 ? "+" : ""}{money(printRec.farq)}</b>
                </div>
              </div>
            </div>
            <div className="flex gap-2 mt-4 no-print">
              <button onClick={() => window.print()} className="flex-1 rounded-2xl py-3 font-black bg-white text-stone-900 shadow">🖨️ Print</button>
              <button onClick={() => setPrintRec(null)} className="flex-1 rounded-2xl py-3 font-black text-white shadow" style={{ background: "#DC2626" }}>✕ Close</button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
