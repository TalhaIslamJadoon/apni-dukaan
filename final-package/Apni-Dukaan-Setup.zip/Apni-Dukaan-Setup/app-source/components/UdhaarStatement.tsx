"use client";

import { intlMobile, normalizeMobile, useShop } from "@/lib/store";

// ── Udhaar Statement (B3) ──────────────────────────────────────────────────
// Ek customer ke saare udhaar charges + wasooli, tareekh ke hisaab se,
// running baqaya ke sath. Print (A4 sheet) + WhatsApp share (mobile ho to).
export interface StatementEntry {
  at: string;
  label: string;
  amount: number; // signed: charge +, wasooli −
  balanceAfter: number;
}

const money = (n: number) => `Rs ${Math.round(n).toLocaleString()}`;
const fmtDate = (iso: string) =>
  new Date(iso).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "2-digit", hour: "2-digit", minute: "2-digit" });

export function statementText(args: {
  shopName: string; name: string; entries: StatementEntry[];
  totalCharged: number; totalPaid: number; balance: number;
}): string {
  const lines: string[] = [
    `📄 *Udhaar Statement — ${args.shopName}*`,
    `Customer: ${args.name}`,
    "——————————",
    ...args.entries.map((e) =>
      `${new Date(e.at).toLocaleDateString("en-GB")} · ${e.label} · ${e.amount >= 0 ? "+" : "−"} Rs ${Math.abs(Math.round(e.amount)).toLocaleString()} · Baqaya: Rs ${Math.round(e.balanceAfter).toLocaleString()}`
    ),
    "——————————",
    `Kul Udhaar: Rs ${Math.round(args.totalCharged).toLocaleString()}`,
    `Kul Wasooli: Rs ${Math.round(args.totalPaid).toLocaleString()}`,
    `*Baqaya: Rs ${Math.round(args.balance).toLocaleString()}*`,
  ];
  return lines.join("\n");
}

export default function UdhaarStatementModal(props: {
  name: string;
  mobile?: string | null;
  entries: StatementEntry[];
  totalCharged: number;
  totalPaid: number;
  balance: number;
  onClose: () => void;
}) {
  const shop = useShop();
  const shopName = shop.canteenName || "Apni Dukaan";
  const wa = props.mobile && normalizeMobile(props.mobile)
    ? `https://wa.me/${intlMobile(props.mobile)}?text=${encodeURIComponent(statementText({ shopName, ...props }))}`
    : null;
  return (
    <div className="fixed inset-0 z-50 bg-black/60 overflow-y-auto p-4">
      <div className="max-w-2xl mx-auto py-4 pop-in">
        <div id="print-sheet" className="bg-white rounded-2xl shadow-xl p-5 text-stone-900" data-testid="udhaar-statement">
          <div className="text-center mb-3">
            <div className="text-xl font-black">📄 Udhaar Statement</div>
            <div className="font-bold">{shopName}</div>
            <div className="text-sm text-stone-500">Customer: <b className="text-stone-800">{props.name}</b>{props.mobile ? ` · ${props.mobile}` : ""}</div>
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] uppercase tracking-wide text-stone-500 border-b-2 border-stone-200">
                <th className="py-1.5 pr-2">Tareekh</th>
                <th className="py-1.5 pr-2">Tafseel</th>
                <th className="py-1.5 pr-2 text-right">Raqam</th>
                <th className="py-1.5 text-right">Baqaya</th>
              </tr>
            </thead>
            <tbody>
              {props.entries.length === 0 && (
                <tr><td colSpan={4} className="py-3 text-center font-bold text-stone-400">Koi entry nahi.</td></tr>
              )}
              {props.entries.map((e, i) => (
                <tr key={i} className="border-b border-stone-100">
                  <td className="py-1.5 pr-2 whitespace-nowrap text-stone-500">{fmtDate(e.at)}</td>
                  <td className="py-1.5 pr-2">{e.label}</td>
                  <td className="py-1.5 pr-2 text-right font-extrabold whitespace-nowrap" style={{ color: e.amount >= 0 ? "#D97706" : "#16A34A" }}>
                    {e.amount >= 0 ? "+" : "−"} {money(Math.abs(e.amount))}
                  </td>
                  <td className="py-1.5 text-right font-bold whitespace-nowrap">{money(e.balanceAfter)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="mt-3 space-y-1 text-sm">
            <div className="flex justify-between"><span className="font-bold text-stone-500">Kul Udhaar</span><b>{money(props.totalCharged)}</b></div>
            <div className="flex justify-between"><span className="font-bold text-stone-500">Kul Wasooli</span><b style={{ color: "#16A34A" }}>{money(props.totalPaid)}</b></div>
            <div className="flex justify-between text-base border-t-2 border-stone-200 pt-1.5"><span className="font-black">Baqaya</span><b style={{ color: props.balance > 0 ? "#DC2626" : "#16A34A" }}>{money(props.balance)}</b></div>
          </div>
        </div>
        <div className="flex gap-2 mt-4 no-print">
          <button onClick={() => window.print()} className="flex-1 rounded-2xl py-3.5 font-black bg-white text-stone-900 shadow">🖨️ Print Statement</button>
          {wa && (
            <a href={wa} target="_blank" rel="noreferrer" data-testid="statement-whatsapp"
              className="flex-1 rounded-2xl py-3.5 font-black shadow text-center" style={{ background: "#25D366", color: "#07351B" }}>
              📲 WhatsApp par Statement bhejein
            </a>
          )}
          <button onClick={props.onClose} className="flex-1 rounded-2xl py-3.5 font-black text-white shadow" style={{ background: "#DC2626" }}>✕ Close</button>
        </div>
      </div>
    </div>
  );
}
