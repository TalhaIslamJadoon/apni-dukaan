"use client";

import type { ShopSettings } from "@/lib/store";

// ─────────────────────────────────────────────────────────────────────────────
// 🎁 LUCKY DRAW announcement strip — boards ke SAB SE UPAR, har slide
// par (header ka hissa, rotating slide NAHI). Sirf tab jab draw ON ho.
// Doosri line: aakhri winner ki mubarakbaad (agle draw tak rehti hai).
// ─────────────────────────────────────────────────────────────────────────────
export default function LuckyDrawStrip({ shop }: { shop: ShopSettings }) {
  if (!shop.luckyDrawEnabled) return null;
  return (
    <div className="shrink-0 text-center px-4 py-2" style={{ background: "#0F172A", color: "#fff" }} data-testid="lucky-draw-strip">
      <div className="font-black leading-tight" style={{ fontSize: "clamp(0.95rem, 1.8vw, 1.5rem)", color: "#FDBA74" }}>
        🎁 LUCKY DRAW — Har {shop.luckyDrawDay} {shop.luckyDrawTime} draw hoga! Rs {shop.luckyDrawMinBill.toLocaleString()}+ ke bill par entry — Inaam: {shop.luckyDrawPrizeHint || shop.luckyDrawPrizeText}
      </div>
      {shop.luckyDrawWinnerName && (
        <div className="font-extrabold leading-tight mt-0.5" style={{ fontSize: "clamp(0.85rem, 1.5vw, 1.25rem)" }}>
          🏆 Pichlay Winner: {shop.luckyDrawWinnerName} — Mubarak ho!
        </div>
      )}
    </div>
  );
}
