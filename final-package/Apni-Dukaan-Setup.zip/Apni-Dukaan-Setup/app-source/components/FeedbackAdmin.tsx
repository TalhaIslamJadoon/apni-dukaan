"use client";

import { useCallback, useEffect, useState } from "react";
import {
  fetchBestStaff, recordBestStaffReward,
  type BestStaffRowDTO, type StaffRewardDTO, type ShopSettings,
} from "@/lib/store";
import { apiGet, apiPatch, apiDelete, ApiClientError } from "@/lib/api";

// ─────────────────────────────────────────────────────────────────────────────
// 📝 FEEDBACK / 🚨 SHIKAYAT / 💡 TAJWEEZ (Owner) — Talha, FIXED-12.
// Table QR se aayi customer ki ray. Paanch categories ki alag averages
// upar; list newest-first; filters: Sab / Kam Rating / Shikayatein /
// Tajweezein / Menu Requests. Menu request par "➕ Menu Mein Add Karein"
// Dashboard → Menu ka form prefilled khol deta hai (sessionStorage
// hand-off: pos-menu-prefill) — item save ho to suggestion ✓ Add Ho Gayi.
// ─────────────────────────────────────────────────────────────────────────────

export interface FeedbackItem {
  id: string; kind: "feedback" | "complaint" | "suggestion";
  taste: number | null; service: number | null; cleanliness: number | null;
  speed: number | null; rates: number | null; behaviour: number | null;
  comment: string; source: string; tableNo: number | null;
  customerName: string; customerMobile: string;
  waiterName: string | null; seen: boolean;
  suggestionType: string; requestedItemName: string; done: boolean;
  createdAt: string;
}
interface FeedbackData {
  items: FeedbackItem[];
  averages: { taste: number | null; service: number | null; cleanliness: number | null; speed: number | null; rates: number | null; behaviour: number | null };
  total: number; unseenComplaints: number; unseenTotal: number;
}

type Filter = "all" | "low" | "complaint" | "suggestion" | "menu";
const stars = (n: number | null) => (n ? "⭐".repeat(n) : "—");
const CATS: { key: keyof FeedbackData["averages"]; label: string }[] = [
  { key: "taste", label: "🍽️ Taste" },
  { key: "service", label: "🛎️ Service" },
  { key: "cleanliness", label: "🧹 Safai" },
  { key: "speed", label: "⚡ Speed" },
  { key: "rates", label: "💰 Rates" },
  { key: "behaviour", label: "🤝 Behaviour" },
];

export async function fetchFeedbackData(): Promise<FeedbackData> {
  return await apiGet<FeedbackData>("/owner/feedback");
}

export default function FeedbackSection() {
  const [data, setData] = useState<FeedbackData | null>(null);
  const [filter, setFilter] = useState<Filter>("all");
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");

  async function load() {
    try { setData(await fetchFeedbackData()); setErr(""); }
    catch (e) { setErr(e instanceof ApiClientError ? e.message : "Feedback load nahi ho saka"); }
  }
  useEffect(() => { void load(); }, []);

  async function seen(id: string) {
    try { await apiPatch(`/owner/feedback/${id}`, { seen: true }); void load(); }
    catch (e) { setMsg(e instanceof Error ? e.message : "Mark nahi ho saka"); }
  }
  async function remove(id: string) {
    if (!window.confirm("Ye feedback delete kar dein?")) return;
    try { await apiDelete(`/owner/feedback/${id}`); void load(); }
    catch (e) { setMsg(e instanceof Error ? e.message : "Delete nahi ho saka"); }
  }
  function addToMenu(item: FeedbackItem) {
    try {
      sessionStorage.setItem("pos-menu-prefill", JSON.stringify({ name: item.requestedItemName, feedbackId: item.id }));
    } catch { /* ignore */ }
    window.dispatchEvent(new CustomEvent("pos-open-menu-add"));
  }

  const items = (data?.items ?? []).filter((i) => {
    if (filter === "low") return [i.taste, i.service, i.cleanliness, i.speed, i.rates, i.behaviour].some((v) => v !== null && v <= 2);
    if (filter === "complaint") return i.kind === "complaint";
    if (filter === "suggestion") return i.kind === "suggestion" && i.suggestionType !== "menu_item";
    if (filter === "menu") return i.suggestionType === "menu_item";
    return true;
  });

  return (
    <section className="bg-white rounded-2xl border border-orange-100 shadow-sm p-4" data-testid="feedback-section">
      <h2 className="font-extrabold mb-1">📝 Feedback — Customers ki Ray, Shikayat aur Tajweez</h2>
      <p className="text-sm text-stone-500 mb-3">Table QR scan karke customers yahi sab bhejte hain — koi account nahi chahiye. Shikayat hamesha pehle sambhalein.</p>
      {err && <p className="font-bold mb-2" style={{ color: "#DC2626" }}>⚠️ {err}</p>}
      {msg && <p className="font-bold mb-2 text-sm" style={{ color: "#DC2626" }}>{msg}</p>}
      {data && (
        <div className="flex flex-wrap gap-2 mb-3" data-testid="feedback-averages">
          <span className="rounded-xl bg-orange-50 px-3 py-2 font-black">Kul: {data.total}</span>
          {CATS.map((c) => (
            <span key={c.key} className="rounded-xl bg-orange-50 px-3 py-2 font-black" data-testid={`fb-avg-${c.key}`}>
              {c.label}: {data.averages[c.key] !== null ? `⭐ ${data.averages[c.key]}` : "—"}
            </span>
          ))}
          {data.unseenComplaints > 0 && <span className="rounded-xl px-3 py-2 font-black text-white" style={{ background: "#DC2626" }}>🚨 {data.unseenComplaints} nayi shikayatein</span>}
        </div>
      )}
      <div className="flex flex-wrap gap-1.5 mb-3">
        {([["all", "Sab"], ["low", "⚠️ Kam Rating (1–2★)"], ["complaint", "🚨 Shikayatein"], ["suggestion", "💡 Tajweezein"], ["menu", "🍔 Menu Requests"]] as [Filter, string][]).map(([f, label]) => (
          <button key={f} onClick={() => setFilter(f)} data-testid={`fb-filter-${f}`} className="rounded-full px-3 py-1.5 text-xs font-black border-2"
            style={filter === f ? { background: "#F97316", borderColor: "#F97316", color: "#fff" } : { background: "#fff", borderColor: "#E7E5E4" }}>{label}</button>
        ))}
      </div>
      {items.length === 0 && <p className="font-bold text-stone-400 text-sm">Is filter mein kuch nahi hai.</p>}
      <div className="space-y-2" data-testid="feedback-list">
        {items.map((i) => (
          <div key={i.id} className={`rounded-2xl border-2 p-3 ${i.seen ? "border-stone-100" : "border-orange-200 bg-orange-50/40"}`} data-testid="feedback-item">
            <div className="flex flex-wrap items-center gap-2">
              {i.kind === "complaint" && <span className="text-[10px] font-black rounded-full px-2 py-0.5 text-white" style={{ background: "#DC2626" }}>🚨 SHIKAYAT</span>}
              {i.kind === "suggestion" && i.suggestionType !== "menu_item" && <span className="text-[10px] font-black rounded-full px-2 py-0.5 text-white" style={{ background: "#2563EB" }}>💡 TAJWEEZ</span>}
              {i.suggestionType === "menu_item" && <span className="text-[10px] font-black rounded-full px-2 py-0.5 text-white" style={{ background: "#7E22CE" }}>🍔 MENU REQUEST</span>}
              <span className="font-black">{i.source === "table" ? `Table ${i.tableNo ?? "—"}` : "🌐 Online"}</span>
              <span className="font-bold text-stone-500 text-sm">{i.customerName || "Customer"}{i.customerMobile ? ` · ${i.customerMobile}` : ""}</span>
              {i.waiterName && <span className="text-xs font-bold text-stone-500">Waiter: {i.waiterName}</span>}
              <span className="text-xs font-bold text-stone-400 ml-auto">{new Date(i.createdAt).toLocaleString("en-GB")}</span>
              {!i.seen && <span className="text-[10px] font-black rounded-full px-2 py-0.5 text-white" style={{ background: "#F59E0B" }}>NAYA</span>}
            </div>
            <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-1 text-sm font-bold">
              <span>🍽️ {stars(i.taste)}</span><span>🛎️ {stars(i.service)}</span><span>🧹 {stars(i.cleanliness)}</span><span>⚡ {stars(i.speed)}</span><span>💰 {stars(i.rates)}</span><span>🤝 {stars(i.behaviour)}</span>
            </div>
            {i.suggestionType === "menu_item" && <div className="mt-1 font-black">🍔 Menu mein add karein: <span style={{ color: "#F97316" }}>{i.requestedItemName}</span></div>}
            {i.comment && <p className="mt-1 text-sm font-semibold text-stone-700">“{i.comment}”</p>}
            <div className="flex gap-2 mt-2">
              {i.suggestionType === "menu_item" && !i.done && (
                <button onClick={() => addToMenu(i)} data-testid={`fb-add-menu-${i.id}`} className="rounded-lg px-3 py-1.5 font-black text-white text-xs" style={{ background: "#F97316" }}>➕ Menu Mein Add Karein</button>
              )}
              {i.suggestionType === "menu_item" && i.done && <span className="text-xs font-black rounded-full px-2 py-1 text-white" style={{ background: "#16A34A" }}>✓ Add Ho Gayi</span>}
              {!i.seen && <button onClick={() => void seen(i.id)} data-testid={`fb-seen-${i.id}`} className="rounded-lg px-3 py-1.5 font-black text-white text-xs" style={{ background: "#16A34A" }}>✓ Dekh Liya</button>}
              <button onClick={() => void remove(i.id)} data-testid={`fb-delete-${i.id}`} className="rounded-lg px-3 py-1.5 font-black text-white text-xs" style={{ background: "#DC2626" }}>🗑️ Delete</button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

// ── FIXED-12: 🏆 Mahine ka Behtareen Staff ──────────────────────────────
export function BestStaffSection({ shop, onSaveMin }: { shop: ShopSettings; onSaveMin: (n: number) => void }) {
  const nowMonth = new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Karachi" }).slice(0, 7);
  const [month, setMonth] = useState(nowMonth);
  const [rows, setRows] = useState<BestStaffRowDTO[]>([]);
  const [history, setHistory] = useState<StaffRewardDTO[]>([]);
  const [minLocal, setMinLocal] = useState(String(shop.bestStaffMinRatings || 5));
  const [kind, setKind] = useState<"cash" | "gift">("cash");
  const [amount, setAmount] = useState("2000");
  const [gift, setGift] = useState("");
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const load = useCallback(async () => {
    try {
      const d = await fetchBestStaff(month);
      setRows(d.rows); setHistory(d.history);
    } catch { /* section optional */ }
  }, [month]);
  useEffect(() => { load(); }, [load]);
  const min = Math.max(1, Math.round(Number(minLocal) || 5));
  const qualified = rows.filter((r) => r.count >= min);
  const top = qualified.length ? qualified[0] : null;
  async function give() {
    if (!top) return;
    setErr(""); setMsg("");
    try {
      await recordBestStaffReward({
        month, staffId: top.staffId, category: top.category, avgRating: top.avg,
        ratingsCount: top.count, rewardKind: kind,
        amountRs: kind === "cash" ? Number(amount) || 0 : undefined,
        giftText: kind === "gift" ? gift : undefined,
      });
      setMsg(`🎁 Inaam record ho gaya — ${top.staffName}${kind === "cash" ? " (Expense mein bhi darj)" : ""}`);
      load();
    } catch (e) {
      setErr(e instanceof ApiClientError ? e.message : "Inaam record nahi ho saka");
    }
  }
  const inputCls = "border border-orange-200 rounded-lg px-2 py-1.5 text-sm bg-white";
  return (
    <div className="bg-white rounded-2xl shadow p-4 mt-4" data-testid="best-staff-section">
      <h3 className="font-bold text-slate-800">🏆 Mahine ka Behtareen Staff</h3>
      <p className="text-xs text-slate-500 mt-0.5">
        Ratings feedback se aati hain — Service + Behaviour waiter ki, Taste kitchen (ready karne wale) ki, Speed bill banane wale ki.
      </p>
      <div className="flex flex-wrap items-end gap-2 mt-3">
        <label className="block">
          <span className="block text-[11px] font-semibold uppercase tracking-wide text-slate-500 mb-1">Mahina</span>
          <input type="month" className={inputCls} value={month} onChange={(e) => setMonth(e.target.value)} data-testid="bs-month" />
        </label>
        <label className="block">
          <span className="block text-[11px] font-semibold uppercase tracking-wide text-slate-500 mb-1">Qualify — kam az kam ratings</span>
          <span className="flex gap-1">
            <input type="number" min={1} className={`${inputCls} w-20`} value={minLocal}
              onChange={(e) => setMinLocal(e.target.value)} data-testid="bs-min" />
            <button className="bg-slate-700 text-white text-xs font-bold px-2.5 py-1.5 rounded-lg"
              onClick={() => { onSaveMin(min); setMsg("✔ Min ratings save ho gayi"); }} data-testid="bs-min-save">Save</button>
          </span>
        </label>
      </div>
      {rows.length === 0 ? (
        <p className="text-sm text-slate-400 mt-3">Is mahine abhi koi attributed rating nahi aayi.</p>
      ) : (
        <table className="w-full text-sm mt-3">
          <thead>
            <tr className="text-left text-slate-500 text-xs uppercase">
              <th className="py-1 pr-2">Staff</th><th className="py-1 pr-2">Category</th>
              <th className="py-1 pr-2 text-right">Ratings</th><th className="py-1 text-right">Average</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => {
              const isTop = top && r.staffId === top.staffId && r.category === top.category;
              const blocked = r.count < min;
              return (
                <tr key={r.staffId + r.category} data-testid={`bs-row-${r.staffId}`}
                  className={isTop ? "bg-amber-50 font-bold" : blocked ? "text-slate-400" : ""}>
                  <td className="py-1.5 pr-2">{isTop ? "🏆 " : ""}{r.staffName}</td>
                  <td className="py-1.5 pr-2">{r.category}</td>
                  <td className="py-1.5 pr-2 text-right">{r.count}{blocked ? ` (kam az kam ${min} chahiye)` : ""}</td>
                  <td className="py-1.5 text-right">⭐ {r.avg.toFixed(1)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
      {top && (
        <div className="mt-3 bg-amber-50 border border-amber-200 rounded-xl p-3">
          <p className="text-sm font-bold text-amber-800">🎁 Inaam Dein — {top.staffName} (⭐ {top.avg.toFixed(1)} · {top.count} ratings)</p>
          <div className="flex flex-wrap items-end gap-2 mt-2">
            <label className="block">
              <span className="block text-[11px] font-semibold uppercase tracking-wide text-slate-500 mb-1">Inaam ki Qisam</span>
              <select className={inputCls} value={kind} onChange={(e) => setKind(e.target.value as "cash" | "gift")} data-testid="bs-kind">
                <option value="cash">💵 Cash</option>
                <option value="gift">🎁 Gift</option>
              </select>
            </label>
            {kind === "cash" ? (
              <label className="block">
                <span className="block text-[11px] font-semibold uppercase tracking-wide text-slate-500 mb-1">Raqam (Rs)</span>
                <input type="number" min={0} className={`${inputCls} w-28`} value={amount} onChange={(e) => setAmount(e.target.value)} data-testid="bs-amount" />
              </label>
            ) : (
              <label className="block flex-1 min-w-[180px]">
                <span className="block text-[11px] font-semibold uppercase tracking-wide text-slate-500 mb-1">Gift ki Tafseel</span>
                <input className={`${inputCls} w-full`} value={gift} onChange={(e) => setGift(e.target.value)} placeholder="e.g. Naya jora" data-testid="bs-gift" />
              </label>
            )}
            <button className="bg-amber-500 hover:bg-amber-600 text-white font-bold px-4 py-2 rounded-lg text-sm"
              onClick={give} data-testid="bs-give">🎁 De Diya</button>
          </div>
          {err && <p className="text-xs text-red-600 font-semibold mt-2">{err}</p>}
          {msg && <p className="text-xs text-emerald-700 font-semibold mt-2" data-testid="bs-msg">{msg}</p>}
        </div>
      )}
      {history.length > 0 && (
        <div className="mt-3">
          <p className="text-xs font-bold text-slate-500 uppercase">📜 Mahina-Waar Inaam History</p>
          <ul className="text-sm mt-1 space-y-1" data-testid="bs-history">
            {history.map((h) => (
              <li key={h.id} className="flex flex-wrap gap-x-2">
                <span className="font-semibold">{h.month}</span>
                <span>🏆 {h.staffName}</span>
                <span className="text-slate-500">{h.category} · ⭐ {Number(h.avgRating).toFixed(1)} ({h.ratingsCount})</span>
                <span>{h.rewardKind === "cash" ? `💵 Rs ${h.amount.toLocaleString()}` : `🎁 ${h.giftText}`}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
