"use client";

import { useEffect, useRef, useState } from "react";
import type { CounterCustomerSuggestion } from "@/lib/store";

// ── Counter Customer picker (Talha, 18 Nov 2026) ────────────────────────────
// Billing ke waqt cashier naam ya mobile likhta hai — purane customers
// as-you-type suggestions mein ate hain (naam / mobile, partial match).
// Ek suggestion select karne se wohi customer is bill/booking par lag
// jata hai (naam+mobile bhar jate hain; Sell/Canteen par us ki special
// discount % parent auto-lagata hai). Koi match na mile to jo likha hai
// wahi bill mukammal hone par NAYA record ban jata hai — account kabhi
// nahi banta (koi password/login nahi).
interface Props {
  name: string;
  mobile: string;
  onNameChange: (v: string) => void;
  onMobileChange: (v: string) => void;
  onSelect: (c: CounterCustomerSuggestion) => void;
  search: (q: string) => Promise<CounterCustomerSuggestion[]>;
  idPrefix?: string;
}

export default function CustomerPicker({ name, mobile, onNameChange, onMobileChange, onSelect, search, idPrefix = "cust" }: Props) {
  const [suggestions, setSuggestions] = useState<CounterCustomerSuggestion[]>([]);
  const [open, setOpen] = useState(false);
  const justSelected = useRef(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (justSelected.current) { justSelected.current = false; setSuggestions([]); setOpen(false); return; }
    const q = mobile.replace(/\D/g, "").length >= 3 ? mobile : name.trim().length >= 2 ? name.trim() : "";
    if (!q) { setSuggestions([]); setOpen(false); return; }
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      void search(q).then((r) => { setSuggestions(r); setOpen(r.length > 0); }).catch(() => setSuggestions([]));
    }, 250);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [name, mobile]);

  return (
    <div className="relative">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-black uppercase tracking-wide text-stone-500 mb-1" htmlFor={`${idPrefix}-name`}>Customer Name (ikhtiyari)</label>
          <input id={`${idPrefix}-name`} data-testid={`${idPrefix}-name`} value={name}
            onChange={(e) => onNameChange(e.target.value)}
            onFocus={() => { if (suggestions.length) setOpen(true); }}
            placeholder="e.g. Ahmed Khan"
            className="w-full rounded-xl border-2 border-stone-200 px-4 py-3 text-base outline-none focus:border-orange-500 bg-white" />
        </div>
        <div>
          <label className="block text-xs font-black uppercase tracking-wide text-stone-500 mb-1" htmlFor={`${idPrefix}-mobile`}>Mobile Number (ikhtiyari)</label>
          <input id={`${idPrefix}-mobile`} data-testid={`${idPrefix}-mobile`} value={mobile}
            onChange={(e) => onMobileChange(e.target.value)}
            onFocus={() => { if (suggestions.length) setOpen(true); }}
            placeholder="03XX-XXXXXXX" inputMode="tel"
            className="w-full rounded-xl border-2 border-stone-200 px-4 py-3 text-base outline-none focus:border-orange-500 bg-white" />
        </div>
      </div>
      <p className="text-[11px] font-bold text-stone-400 mt-1">Purana customer ho to naam ya number likhte hi neeche us ka record aa jayega — select kar lein. Mobile likhne par hi record banta/bachta hai; baghair mobile ke koi record nahi banta.</p>
      {open && suggestions.length > 0 && (
        <div className="absolute left-0 right-0 top-full mt-1 z-40 rounded-2xl border-2 border-orange-200 bg-white shadow-xl overflow-hidden" data-testid={`${idPrefix}-suggestions`}>
          <div className="px-3 py-1.5 text-[11px] font-black uppercase tracking-wide text-stone-400 bg-orange-50">Purane Customers — select karein</div>
          {suggestions.map((s) => (
            <button key={s.id} type="button" data-testid={`${idPrefix}-suggestion-${s.mobile}`}
              onClick={() => { justSelected.current = true; setOpen(false); setSuggestions([]); onSelect(s); }}
              className="w-full flex items-center gap-3 px-3 py-2.5 text-left hover:bg-orange-50 border-t border-stone-100">
              <span className="text-xl">👤</span>
              <span className="flex-1 min-w-0">
                <span className="block font-extrabold leading-tight">{s.name}</span>
                <span className="block text-xs font-bold text-stone-500">{s.mobile} · 🧾 {s.bills} bills{s.pointsBalance > 0 ? ` · ⭐ ${s.pointsBalance} points` : ""}</span>
              </span>
              {s.discountPct > 0 && (
                <span className="shrink-0 text-xs font-black rounded-full px-2 py-1 text-white" style={{ background: "#D97706" }}>⭐ {s.discountPct}% OFF</span>
              )}
              {s.pendingPrize && (
                <span className="shrink-0 text-xs font-black rounded-full px-2 py-1 text-white" style={{ background: "#16A34A" }} data-testid="picker-prize-flag">🎁 Lucky Draw Winner — {s.pendingPrize.prizeDetail} dena baqi hai</span>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Duplicate-number guard ──────────────────────────────────────────────────
// Typed mobile pehle se kisi AUR naam par registered ho to ye dialogue
// rok kar batata hai — duplicate record kabhi nahi banta (mobile hi
// pehchan hai). Cashier ya to wohi purana customer is bill par lagaye,
// ya baghair customer ke aage barhe.
export function DuplicateCustomerDialog({ customer, typedName, onAttach, onWithout, onClose }: {
  customer: CounterCustomerSuggestion;
  typedName: string;
  onAttach: () => void;
  onWithout: () => void;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-[60] bg-black/60 flex items-center justify-center p-4" data-testid="dup-customer-dialog">
      <div className="bg-white rounded-3xl w-full max-w-md p-5 pop-in">
        <div className="text-4xl mb-2">📱</div>
        <h3 className="text-lg font-black mb-1">Ye number pehle se registered hai</h3>
        <p className="text-sm font-semibold text-stone-600 mb-1">
          Ye number pehle se <b style={{ color: "#B45309" }}>{customer.name}</b> ke naam par registered hai ({customer.mobile}) — 🧾 {customer.bills} bills pehle se is record mein hain.
        </p>
        {typedName.trim() && typedName.trim().toLowerCase() !== customer.name.toLowerCase() && (
          <p className="text-sm font-semibold text-stone-500 mb-1">Aap ne naam <b>“{typedName.trim()}”</b> likha hai — duplicate record nahi banega.</p>
        )}
        {customer.discountPct > 0 && (
          <p className="text-sm font-black mb-1" style={{ color: "#D97706" }}>⭐ Is customer ki special discount {customer.discountPct}% hai — select karne par is bill par auto lag jayegi (jahan lagu hoti hai).</p>
        )}
        <div className="space-y-2 mt-4">
          <button onClick={onAttach} data-testid="dup-attach" className="w-full rounded-2xl py-3.5 font-black text-white" style={{ background: "#16A34A" }}>
            ✓ {customer.name} ko is bill par lagayein
          </button>
          <button onClick={onWithout} data-testid="dup-without" className="w-full rounded-2xl py-3.5 font-black bg-stone-100 text-stone-700">
            Baghair customer ke aage barhein
          </button>
          <button onClick={onClose} data-testid="dup-close" className="w-full rounded-2xl py-2.5 font-bold text-stone-400">
            ✕ Wapas — naam/number theek karna hai
          </button>
        </div>
      </div>
    </div>
  );
}
