"use client";

import { useCallback, useEffect, useState } from "react";
import { apiGet, apiPost, ApiClientError } from "@/lib/api";

// ── Supplier Khata (B7) ────────────────────────────────────────────────────
// Udhaar pattern ki mirror: suppliers ki list (baqaya ke sath), click par
// khata (khareed + payments, running baqaya), "Payment dein" form, aur
// naya supplier add. Khareed stock-in entries se khud ati hai.
const money = (n: number) => `Rs ${Math.round(n).toLocaleString()}`;

interface SupplierRow { id: string; name: string; mobile: string; createdAt?: string; balance: number; totalPurchases: number; purchasesCount: number }
interface LedgerEntry { at: string; label: string; amount: number; balanceAfter: number }

export function PayablesCard() {
  const [total, setTotal] = useState<number | null>(null);
  useEffect(() => {
    apiGet<{ suppliers: SupplierRow[] }>("/owner/suppliers")
      .then((d) => setTotal(d.suppliers.reduce((s, x) => s + Math.max(0, x.balance), 0)))
      .catch(() => setTotal(null));
  }, []);
  if (total === null) return null;
  return (
    <div className="rounded-2xl border-2 border-red-200 bg-red-50 p-3" data-testid="overview-payables">
      <div className="text-[11px] font-black uppercase tracking-wide text-red-500">🚚 Suppliers ko dena hai (Payables)</div>
      <div className="text-2xl font-black" style={{ color: "#DC2626" }}>{money(total)}</div>
      <div className="text-xs font-bold text-stone-500">Dashboard → Suppliers mein tafseel</div>
    </div>
  );
}

export default function SuppliersSection() {
  const [suppliers, setSuppliers] = useState<SupplierRow[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [ledger, setLedger] = useState<LedgerEntry[]>([]);
  const [balance, setBalance] = useState(0);
  const [form, setForm] = useState({ amount: "", method: "cash", note: "" });
  const [addForm, setAddForm] = useState({ name: "", mobile: "" });
  const [query, setQuery] = useState("");
  const [msg, setMsg] = useState("");

  const load = useCallback(async () => {
    try {
      const d = await apiGet<{ suppliers: SupplierRow[] }>("/owner/suppliers");
      setSuppliers(d.suppliers);
    } catch { /* ignore */ }
  }, []);
  useEffect(() => { void load(); }, [load]);

  const loadLedger = useCallback(async (id: string) => {
    try {
      const d = await apiGet<{ entries: LedgerEntry[]; balance: number }>(`/owner/suppliers/${id}/ledger`);
      setLedger(d.entries); setBalance(d.balance);
    } catch { setLedger([]); }
  }, []);
  useEffect(() => { if (selectedId) void loadLedger(selectedId); }, [selectedId, loadLedger]);

  const selected = suppliers.find((s) => s.id === selectedId) ?? null;
  const totalPayables = suppliers.reduce((s, x) => s + Math.max(0, x.balance), 0);
  // Newest FIRST — naya supplier hamesha pehli row mein (Talha, FIXED-12).
  const sortedSuppliers = [...suppliers].sort((a, b) => String(b.createdAt ?? "").localeCompare(String(a.createdAt ?? "")));
  const visibleSuppliers = sortedSuppliers.filter((s) => {
    const q = query.trim().toLowerCase();
    return !q || s.name.toLowerCase().includes(q) || (s.mobile ?? "").includes(q);
  });

  async function addSupplier() {
    if (!addForm.name.trim()) { setMsg("⚠️ Supplier ka naam likhein"); return; }
    try {
      await apiPost("/owner/suppliers", { name: addForm.name.trim(), mobile: addForm.mobile.trim() || undefined });
      setAddForm({ name: "", mobile: "" }); setMsg("✓ Supplier add ho gaya");
      void load();
    } catch (e) { setMsg(e instanceof ApiClientError ? `⚠️ ${e.message}` : "⚠️ Add nahi ho saka"); }
  }

  async function pay() {
    if (!selected) return;
    const amt = parseInt(form.amount, 10);
    if (isNaN(amt) || amt <= 0) { setMsg("⚠️ Payment ki raqam sahi likhein"); return; }
    try {
      const d = await apiPost<{ balance: number }>(`/owner/suppliers/${selected.id}/payments`, { amount: amt, method: form.method, note: form.note.trim() || undefined });
      setMsg(`✓ Payment darj — naya baqaya ${money(d.balance)}`);
      setForm({ amount: "", method: "cash", note: "" });
      void load(); void loadLedger(selected.id);
    } catch (e) { setMsg(e instanceof ApiClientError ? `⚠️ ${e.message}` : "⚠️ Payment nahi ho saki"); }
  }

  return (
    <section className="rounded-3xl bg-white shadow p-4 sm:p-5 mb-5" data-testid="suppliers-section">
      <div className="flex flex-wrap items-center gap-2 mb-1">
        <h3 className="font-black text-lg">🚚 Suppliers — Khata</h3>
        <span className="ml-auto font-black" style={{ color: totalPayables > 0 ? "#DC2626" : "#16A34A" }}>
          Kul dena hai: {money(totalPayables)}
        </span>
      </div>
      <p className="text-[13px] font-bold text-stone-500 mb-3">
        Jin se maal khareedte hain un ka khata. Khareed Stock screen ki entries se khud ati hai (supplier + kul raqam + abhi ada wahan likhein) — yahan sirf payments darj hoti hain.
      </p>
      {msg && <div className="mb-3 rounded-xl bg-stone-50 border border-stone-200 px-3 py-2 text-sm font-bold">{msg}</div>}

      {/* ── ADD FORM — apni ALAG top row (Talha, FIXED-12): form hamesha
          upar fix, list neeche banti jati hai (newest pehle). ── */}
      <div className="rounded-2xl bg-stone-50 border-2 border-stone-200 p-3 mb-4" data-testid="supplier-add-row">
        <div className="font-extrabold mb-2">➕ Naya Supplier</div>
        <div className="flex flex-wrap items-end gap-2">
          <label className="block flex-1 min-w-[180px]">
            <span className="block text-[11px] font-bold uppercase tracking-wide text-stone-500 mb-0.5">Supplier ka Naam</span>
            <input value={addForm.name} onChange={(e) => setAddForm({ ...addForm, name: e.target.value })} data-testid="supplier-name-input" placeholder="e.g. Lahore Traders"
              className="w-full rounded-xl border-2 border-stone-200 px-3 py-2.5 outline-none focus:border-orange-500 bg-white" />
          </label>
          <label className="block flex-1 min-w-[160px]">
            <span className="block text-[11px] font-bold uppercase tracking-wide text-stone-500 mb-0.5">Mobile Number</span>
            <input value={addForm.mobile} onChange={(e) => setAddForm({ ...addForm, mobile: e.target.value })} data-testid="supplier-mobile-input" placeholder="03XX-XXXXXXX" inputMode="tel"
              className="w-full rounded-xl border-2 border-stone-200 px-3 py-2.5 outline-none focus:border-orange-500 bg-white" />
          </label>
          <button onClick={() => void addSupplier()} data-testid="supplier-add-btn" className="rounded-xl px-4 py-2.5 font-black text-white" style={{ background: "#0F172A" }}>Supplier Add karein</button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="font-extrabold text-sm">🚚 Suppliers ({visibleSuppliers.length})</span>
            <input value={query} onChange={(e) => setQuery(e.target.value)} data-testid="supplier-search" placeholder="🔍 Naam / mobile se dhundein…"
              className="ml-auto w-44 rounded-xl border-2 border-stone-200 px-3 py-1.5 text-sm outline-none focus:border-orange-500" />
          </div>
          <div className="space-y-1.5">
            {suppliers.length === 0 && <div className="font-bold text-stone-400 text-sm">Abhi koi supplier nahi — upar wale form se add karein ya Stock entry par naam likhein.</div>}
            {suppliers.length > 0 && visibleSuppliers.length === 0 && <div className="font-bold text-stone-400 text-sm">Is search par koi supplier nahi mila.</div>}
            {visibleSuppliers.map((s) => (
              <button key={s.id} onClick={() => setSelectedId(s.id)} data-testid={`supplier-row-${s.id}`}
                className={`w-full text-left rounded-2xl border-2 px-3 py-2.5 ${selectedId === s.id ? "border-orange-400 bg-orange-50" : "border-stone-100 bg-white"}`}>
                <div className="flex items-center gap-2">
                  <span className="font-black">{s.name}</span>
                  {s.mobile && <span className="text-xs font-bold text-stone-400">📱 {s.mobile}</span>}
                  <span className="ml-auto font-black" style={{ color: s.balance > 0 ? "#DC2626" : "#16A34A" }}>
                    {s.balance > 0 ? `Dena: ${money(s.balance)}` : "✓ Clear"}
                  </span>
                </div>
                <div className="text-xs font-bold text-stone-400">Khareed: {s.purchasesCount} · Kul {money(s.totalPurchases)}</div>
              </button>
            ))}
          </div>
        </div>

        <div>
          {!selected ? (
            <div className="rounded-2xl border-2 border-dashed border-stone-200 p-4 font-bold text-stone-400 text-sm">Kisi supplier par click karein — us ka khata (khareed + payments) yahan khulega.</div>
          ) : (
            <div className="rounded-2xl border-2 border-dashed border-stone-200 p-3" data-testid="supplier-detail">
              <div className="flex flex-wrap items-center gap-2 mb-3">
                <span className="text-2xl">🚚</span>
                <span className="font-black text-lg">{selected.name}</span>
                {selected.mobile && <span className="text-xs font-bold text-stone-500">📱 {selected.mobile}</span>}
                <span className="ml-auto font-black" style={{ color: balance > 0 ? "#DC2626" : "#16A34A" }}>Baqaya: {money(balance)}</span>
              </div>
              {balance > 0 && (
                <div className="rounded-2xl bg-red-50/70 border border-red-200 p-3 mb-3">
                  <div className="font-extrabold mb-2">💰 Payment dein</div>
                  <div className="flex flex-wrap items-end gap-2">
                    <label className="block w-36">
                      <span className="block text-[11px] font-bold uppercase tracking-wide text-stone-500 mb-0.5">Raqam (Rs)</span>
                      <input value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value.replace(/[^0-9]/g, "") })} data-testid="supplier-pay-amount" inputMode="numeric" placeholder="0"
                        className="w-full rounded-xl border-2 border-stone-200 px-3 py-2.5 outline-none focus:border-orange-500 bg-white" />
                    </label>
                    <label className="block w-36">
                      <span className="block text-[11px] font-bold uppercase tracking-wide text-stone-500 mb-0.5">Method</span>
                      <select value={form.method} onChange={(e) => setForm({ ...form, method: e.target.value })} className="w-full rounded-xl border-2 border-stone-200 px-3 py-2.5 outline-none focus:border-orange-500 bg-white">
                        <option value="cash">Cash</option>
                        <option value="jazzcash">JazzCash</option>
                        <option value="easypaisa">Easypaisa</option>
                        <option value="bank">Bank</option>
                      </select>
                    </label>
                    <label className="block flex-1 min-w-[140px]">
                      <span className="block text-[11px] font-bold uppercase tracking-wide text-stone-500 mb-0.5">Note (optional)</span>
                      <input value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} className="w-full rounded-xl border-2 border-stone-200 px-3 py-2.5 outline-none focus:border-orange-500 bg-white" />
                    </label>
                    <button onClick={() => void pay()} data-testid="supplier-pay-btn" className="rounded-xl px-4 py-2.5 font-black text-white" style={{ background: "#16A34A" }}>Payment Darj</button>
                  </div>
                </div>
              )}
              <div className="font-extrabold mb-1.5">📒 Khata</div>
              <div className="space-y-1 max-h-96 overflow-y-auto pr-1">
                {ledger.length === 0 && <div className="font-bold text-stone-400 text-sm">Abhi koi entry nahi.</div>}
                {[...ledger].reverse().map((e, i) => (
                  <div key={i} className="flex items-start gap-2 rounded-xl bg-stone-50 px-3 py-2 text-sm">
                    <div className="flex-1 min-w-0">
                      <div className="font-bold leading-snug">{e.label}</div>
                      <div className="text-xs font-bold text-stone-400">{new Date(e.at).toLocaleString("en-GB")}</div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-black" style={{ color: e.amount >= 0 ? "#D97706" : "#16A34A" }}>{e.amount >= 0 ? "+" : "−"} {money(Math.abs(e.amount))}</div>
                      <div className="text-xs font-bold text-stone-400">Baqaya {money(e.balanceAfter)}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
