"use strict";
// Canteen POS — Windows Print Agent (plan §1.5)
// Server ki print queue se jobs claim karke asal printers par bhejta hai:
//   receipt / kitchen_ticket / table_card → ESC/POS (80mm)
//   barcode_label                          → TSPL / ZPL / ESC-POS native barcode
// Transports: file (PRINT_TO_FILE test) | tcp 9100 | windows spooler (RAW).
// Chalana:  node agent.js [--config path] [--once] [--to-file]
// Pairing:  AUTO hai — token na ho to agent khud pairing request bhej
// deta hai; Owner Dashboard → Printers & Devices mein "Jor dein" dabata
// hai to token khud config mein save ho jata hai. (Advanced: pair.js se
// code wala purana tareeqa bhi maujood hai.)
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { loadConfig, resolvePrinter } = require("./lib/config");
const { Api } = require("./lib/api");
const { renderReceipt, renderKitchenTicket, renderTableCard } = require("./lib/escpos");
const { renderLabels } = require("./lib/labels");
const { send } = require("./lib/send");
const { discoverPrinters } = require("./lib/printers");

const argv = process.argv.slice(2);
const cfg = loadConfig(argv);
const api = new Api(cfg);
const once = argv.includes("--once");

const log = (...a) => console.log(`[${new Date().toISOString()}]`, ...a);

let settings = null; // shop names (receipt header) — bootstrap se, refresh hota rehta hai
async function refreshSettings() {
  const s = await api.shopNames();
  if (s) settings = s;
}

// Discovered printers — har heartbeat ke saath server ko jate hain (Owner ke
// Devices screen ke dropdowns ke liye). Discovery fail ho to purani list hi
// dobara bhej dete hain; agent is ki wajah se kabhi nahi rukta.
let discovered = [];
async function refreshPrinters() {
  try {
    discovered = await discoverPrinters(cfg);
  } catch (e) {
    log(`printer discovery ✗ ${e.message} (purani list hi bheji jayegi)`);
  }
  return discovered;
}

function render(job, printer) {
  const j = { ...job, __width: printer.paperWidthChars || 48 };
  switch (job.type) {
    case "receipt": return renderReceipt(j, settings);
    case "kitchen_ticket": return renderKitchenTicket(j, settings);
    case "table_card": return renderTableCard(j, settings);
    case "barcode_label": return renderLabels(j, printer.commandLanguage);
    default: throw new Error(`Unknown job type: ${job.type}`);
  }
}

async function processOne() {
  const job = await api.claimNext();
  if (!job) return false;
  const printer = resolvePrinter(cfg, job);
  log(`claim: ${job.type} job=${job.id.slice(0, 8)} bill=${job.payload?.billNo ?? "-"} → ${printer.transport}/${printer.commandLanguage} (${printer.source})`);
  try {
    const buf = render(job, printer);
    const sent = await send(buf, job, printer, cfg);
    await api.complete(job.id);
    log(`printed ✓ job=${job.id.slice(0, 8)} bytes=${sent.bytes} via ${sent.transport} ${sent.detail}`);
  } catch (e) {
    log(`FAILED ✗ job=${job.id.slice(0, 8)}: ${e.message}`);
    try { await api.fail(job.id, e.message); } catch (e2) { log(`fail-report bhi fail: ${e2.message}`); }
  }
  return true;
}

// ── AUTO-PAIRING (Talha, 18 Nov 2026) ────────────────────────────────
// Token na ho to: server ko pairing request (PC ke naam ke sath) →
// Owner Dashboard mein "Jor dein" dabaye → token yahin milta hai aur
// config mein KHUD save ho jata hai. Koi code, koi file edit nahi.
function saveConfigPatch(patch) {
  let cur = {};
  if (fs.existsSync(cfg.configPath)) {
    try { cur = JSON.parse(fs.readFileSync(cfg.configPath, "utf8")); } catch { cur = {}; }
  }
  const next = { ...cur, ...patch };
  fs.writeFileSync(cfg.configPath, JSON.stringify(next, null, 2) + "\n");
}

function installAutoStart() {
  try {
    const startup = process.env.APPDATA
      ? path.join(process.env.APPDATA, "Microsoft", "Windows", "Start Menu", "Programs", "Startup")
      : "";
    if (startup && fs.existsSync(startup)) {
      const bat = "@echo off\r\ncd /d \"" + __dirname + "\"\r\nstart /min \"\" node agent.js\r\n";
      fs.writeFileSync(path.join(startup, "CanteenPOS-PrintAgent.bat"), bat);
    }
  } catch { /* auto-start optional hai */ }
}

async function autoPair() {
  console.log("");
  console.log("Print program chal gaya hai — abhi system se jura nahi hai.");
  console.log("System se judne ke liye Dashboard → Printers & Devices mein 'Jor dein' dabayein.");
  console.log("(Ye window khuli rakhein — judte hi yahan ✔ aa jayega.)");
  const machineName = os.hostname();
  let requestId = "";
  for (let tries = 0; tries < 20 && !requestId; tries++) {
    try {
      const res = await fetch(cfg.serverUrl + "/api/v1/agent/pairing", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ machineName, version: require("./package.json").version }),
        signal: AbortSignal.timeout(10000),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.requestId) requestId = data.requestId;
      else throw new Error(data?.error?.message || `HTTP ${res.status}`);
    } catch (e) {
      if (tries === 0) console.log(`Server se rabta ho raha hai… (${e.message})`);
      await sleep(3000);
    }
  }
  if (!requestId) {
    console.error("✗ Server se rabta nahi ho saka — pehle ye check karein ke system (server) isi PC par chal raha hai, phir ye program dobara chalain.");
    return false;
  }
  const deadline = Date.now() + 10 * 60 * 1000;
  while (Date.now() < deadline) {
    await sleep(3000);
    let data = null;
    try {
      const res = await fetch(`${cfg.serverUrl}/api/v1/agent/pairing/${requestId}`, { signal: AbortSignal.timeout(10000) });
      data = await res.json().catch(() => null);
    } catch { /* network hichki — poll jari */ }
    if (!data) continue;
    if (data.status === "approved" && data.token) {
      saveConfigPatch({ serverUrl: cfg.serverUrl, agentToken: data.token, agentName: data.agentName || cfg.agentName, machineName });
      cfg.agentToken = data.token;
      if (data.agentName) cfg.agentName = data.agentName;
      installAutoStart();
      console.log("");
      console.log("✔ Jud gaya hai — ab print yahan aayega.");
      return true;
    }
    if (data.status === "rejected") {
      console.error("✗ Owner ne judne ki request 'Nahi' kar di hai. Owner se baat karke program dobara chalain — nayi request chali jayegi.");
      return false;
    }
    if (data.status === "expired") {
      console.error("✗ Request ka time khatam ho gaya (Owner ne time par 'Jor dein' nahi dabaya). Program dobara chalain — nayi request chali jayegi.");
      return false;
    }
  }
  console.error("✗ 10 minute tak Owner ne 'Jor dein' nahi dabaya — program dobara chalain.");
  return false;
}

async function main() {
  if (!cfg.agentToken || cfg.agentToken === "PASTE_TOKEN_FROM_PAIRING") {
    const okPaired = await autoPair();
    if (!okPaired) process.exit(2);
  }
  log(`Print agent start — server=${cfg.serverUrl} name="${cfg.agentName}" machine=${os.hostname()} mode=${cfg.forceFile ? "PRINT_TO_FILE" : "live"}`);
  await refreshSettings();
  await refreshPrinters();
  log(`discovered printers=${discovered.length}${discovered.length ? ": " + discovered.map((p) => p.name).join(" | ") : ""}`);
  try {
    const hb = await api.heartbeat(discovered);
    log(`heartbeat ✓ agent=${hb.agent.displayName} assignedPrinters=${hb.printers.length}`);
    for (const p of hb.printers) log(`  printer: ${p.role} "${p.displayName}" ${p.connectionType} ${p.address ?? ""} ${p.commandLanguage ?? ""}`);
  } catch (e) {
    log(`heartbeat ✗ ${e.message} (server chal raha hai? token theek hai?) — polling phir bhi try hogi`);
  }
  const hbTimer = setInterval(async () => {
    await refreshPrinters();
    api.heartbeat(discovered).catch((e) => log(`heartbeat ✗ ${e.message}`));
    refreshSettings();
  }, cfg.heartbeatIntervalMs);

  let backoff = cfg.pollIntervalMs;
  let stopping = false;
  const stop = () => { stopping = true; };
  process.on("SIGINT", stop);
  process.on("SIGTERM", stop);

  while (!stopping) {
    try {
      const did = await processOne();
      backoff = cfg.pollIntervalMs;
      if (once) break;
      if (!did) await sleep(cfg.pollIntervalMs);
    } catch (e) {
      // claim hi fail (server down / network) — backoff ke saath retry
      log(`poll ✗ ${e.message} — ${Math.round(backoff / 1000)}s baad retry`);
      if (once) { clearInterval(hbTimer); throw e; }
      await sleep(backoff);
      backoff = Math.min(backoff * 2, 30000);
    }
  }
  clearInterval(hbTimer);
  log("Print agent band ho raha hai. Allah Hafiz.");
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

main().catch((e) => {
  console.error("✗ Agent ruk gaya:", e.message);
  process.exit(1);
});
