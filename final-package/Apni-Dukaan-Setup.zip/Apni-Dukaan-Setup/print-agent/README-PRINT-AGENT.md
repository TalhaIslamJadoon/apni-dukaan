# Apni Dukaan — Print Agent (Windows)

**Ye kya hai?** Print agent ek chhota sa Node.js program hai jo dukaan ke server
PC par chalta hai. Jab bhi POS mein bill ya barcode label print hota hai, server
uski ek **print job** queue mein daal deta hai. Agent wo job claim karke asal
printer par bhejta hai — receipt **ESC/POS (80mm)**, kitchen ticket ESC/POS, aur
barcode labels printer ki apni **TSPL** (ya ZPL / ESC-POS) barcode command mein —
aur phir server ko bata deta hai ke job `printed` hui ya `failed` (error ke saath).

Browser print hamesha emergency fallback ke tor par mojood rehta hai; asal
production printing isi agent se hoti hai (Phase 2 plan §1.5).

What it does, in one line: **polls the server print queue → claims a job →
renders ESC/POS or TSPL → sends the raw bytes to the printer → reports
printed/failed back to the server.**

---

## Files

| File | Kaam |
|---|---|
| `agent.js` | Main program — claim → render → send → report loop |
| `pair.js` | Advanced pairing helper (sirf khaas halat) — aam tareeqa AUTO hai: agent bina token start ho to khud pairing request bhejta hai, Owner Dashboard mein 'Jor dein' dabata hai, token khud config mein save ho jata hai |
| `selftest.js` | Server/printer ke baghair rendering test (sample receipt + label) |
| `print-agent.config.json` | Saari settings (server URL, token, har printer ki mapping) |
| `raw-print.ps1` | Windows spooler RAW printing helper (USB/shared printers ke liye) |
| `start-print-agent.bat` | Double-click launcher |
| `lib/` | `api.js` (server client), `escpos.js` (receipt/kitchen), `labels.js` (TSPL/ZPL/ESC-POS labels), `code128.js` (app ke `lib/code128.ts` ka port — validation + width estimate), `send.js` (file/tcp/windows transports), `config.js` |

Koi npm dependency NAHI hai — sirf Node.js chahiye (Node 18+, Windows deployment
pack wala Node LTS chalega).

---

## Install (server PC par, deployment day)

1. Ye poori `print-agent` folder server PC par copy karein, masalan
   `C:\CanteenPOS\print-agent\`.
2. Node.js pehle se install hoga (deployment pack ka `01-install-prereqs.ps1`) —
   Command Prompt mein `node --version` se confirm karein.
3. **Pairing** karein (neeche wala section) — token config mein ajayega.
4. `print-agent.config.json` mein har printer ki mapping apni asal printers ke
   mutabiq set karein (neeche "Config" parhein).
5. Pehle test mode mein chalayein: `node agent.js --to-file` — jobs asal printer
   ki bajaye `outbox\` folder mein `.prn` files banengi. Ek bill aur ek label
   print karke files check karein.
6. Sab theek ho to `start-print-agent.bat` double-click karein, ya roz-marra ke
   liye Task Scheduler se Windows start par auto-run lagayein (deployment pack
   ke autostart pattern jaisa hi ek task: program `node.exe`, arguments
   `agent.js`, start-in `C:\CanteenPOS\print-agent`).

## Pairing — token kaisay milta hai

Agent server se ek **bearer token** se pehchana jata hai. Token Owner banata
hai; server par sirf uska hash rehta hai, aur token sirf **ek dafa** milta hai
(kho jaye to dobara pairing — purana token khud band ho jata hai).

Server PC par, Owner ke browser session ke saath:

```bat
node pair.js --server http://192.168.1.10:3100 --cookie "pos_staff_session=XXXX" --name "Counter PC Print Agent"
```

- `--server` = POS server ka LAN address (port 3100).
- Cookie kahan se milegi: Owner browser mein POS khol kar login karein, phir
  F12 → Application → Cookies → `pos_staff_session` ki value copy karein.
  (Ya owner login API ke `set-cookie` header se — pair.js ke top comments mein
  curl wali misaal di hai.)
- Pairing kamyab ho to token `print-agent.config.json` mein khud save ho jata
  hai. **Token kabhi chat, email ya git mein share na karein.** Config ki
  jagah env var bhi chal sakta hai: `PRINT_AGENT_TOKEN`.

## Config — `print-agent.config.json`

| Setting | Matlab |
|---|---|
| `serverUrl` | POS server, masalan `http://192.168.1.10:3100` |
| `agentName` | Naam jo Owner health screen par dikhta hai |
| `agentToken` | Pairing wala token (placeholder shipped hai — asal token kabhi repo mein na rakhein) |
| `pollIntervalMs` | Kitni dair baad nayi job check ho (default 2000) |
| `outboxDir` | PRINT_TO_FILE mode ki files yahan banti hain |
| `printers.receipt` / `.kitchen_ticket` / `.barcode_label` / `.table_card` | Har job type ki physical printer mapping |

Har printer mapping mein:

- `transport`: `file` (test — .prn file), `tcp` (network printer, raw port 9100),
  ya `windows` (Windows spooler — USB/shared printer, naam se).
- `host` / `port`: tcp ke liye printer ka IP aur port (aam tor par 9100).
- `windowsPrinterName`: windows transport ke liye — bilkul wohi naam jo Windows
  **Settings → Printers & scanners** mein dikhta hai.
- `commandLanguage`: receipt/kitchen ke liye `escpos`; label printer ke liye
  uske model ke mutabiq `tspl` (aam), `zpl`, ya `escpos`.
- `paperWidthChars`: 80mm ESC/POS ke liye 48 (default).

Ek hi physical printer do kaam kar sakta hai — masalan receipt wala printer hi
table cards bhi print kare to dono mappings mein wohi host/naam likhein.

Server par Owner → System Health mein printers/agents ki list aur failed jobs
ka count dikhta hai.

### Printer mapping ki tarteeb (Device Setup ke baad)

1. **PRINT_TO_FILE test mode** — hamesha file, sab se upar.
2. **Server assignment** — Dashboard → **🖨️ Printers & Devices** par
   owner ne har role (Bill / Kitchen / Label) ke liye jo printer chuna hai,
   job usi par jati hai (spooler par usi naam par, ya network address par).
   Agent har heartbeat mein apne discovered printers (Windows spooler ke
   naam + config ke endpoints) server ko bhejta hai — dropdown mein wohi
   naam ate hain, kisi ko naam/IP likhna nahi parta.
3. **Local config** — koi server assignment na ho to `printers.<job type>`
   wali mapping hi chalti hai (purani tarteeb).

**Cash drawer:** drawer bill printer ke drawer-port se jurta hai. Agent har
pure-Cash receipt ke saath drawer-kick pulse (ESC p 0) bhejta hai — drawer
khud khul jata hai. JazzCash/Easypaisa/Udhaar par koi pulse nahi jata.

## Roz ka istemal (Daily use)

- Subah server PC on karein; agent auto-start ho to kuch karne ki zaroorat nahi.
  Warna `start-print-agent.bat` chaladein — ek console window khuli rahegi,
  usmein har job ki line ati hai (`printed ✓` / `FAILED ✗` wajah ke saath).
- Window band = agent band. Ghalati se band ho jaye to dobara chaladein —
  queue wali jobs kahin nahi jati; agent dobara claim kar lega.
- Job `failed` ho jaye (printer off, paper jam ke baad, network) to pehle
  printer theek karein, phir Dashboard ki print queue se us job par
  **Retry** dabayein — wohi job dubara ajayegi. Ek aur copy chahiye to
  **Reprint** alag job banata hai (receipt par `*** REPRINT ***` chhapta hai).

## Troubleshooting

| Masla | Check karein |
|---|---|
| Agent start par judne ki line ati hai lekin judta nahi | Dashboard → Printers & Devices mein card par **✔ Jor dein** dabayein (agent window khuli rakhein) |
| `heartbeat ✗ 401` | Token ghalat/purana — dobara pairing karein (purana token band ho jata hai) |
| `poll ✗ fetch failed` | Server PC/server app chal raha hai? `serverUrl` ka IP sahi hai? Router/LAN theek hai? |
| Job claim hoti hai magar `FAILED: connect nahi hua ECONNREFUSED` | Printer off hai, ya IP badal gaya hai — printer ka IP router mein fix (reserve) karein aur config update karein |
| `windows transport` error, printer naam | Naam bilkul wohi likhein jo Windows Printers & scanners mein hai; printer "shared"/online ho |
| Label par barcode scan nahi hota | Label printer ka `commandLanguage` model se match karein (TSPL vs ZPL); `selftest.js` ki sample label file se pehle test karein |
| Receipt par Urdu/ajeeb characters | Thermal printers ASCII code page par hain — app ka text Roman Urdu/English hai; printer ki code page setting (WPC1252/PC437) model ke menu se confirm karein |
| Ek job do dafa print ho gayi | Agent print ke foran baad crash/bijli band hua hoga — system at-least-once hai: crash wali `sent` job 10 minute baad wohi agent dobara claim kar sakta hai taake job kho na jaye |
| Jobs queue mein phansi hain, agent chal raha hai | Owner health screen dekhein — agent ka `last_seen` fresh hai? Printer mapping us job type ki config mein hai? |

Rendering pehle check karni ho to: `node selftest.js` — sample receipt,
kitchen ticket aur TSPL label `outbox\selftest\` mein ban jati hain, server ki
zaroorat nahi.

---

## I
...[truncated 2085 chars]