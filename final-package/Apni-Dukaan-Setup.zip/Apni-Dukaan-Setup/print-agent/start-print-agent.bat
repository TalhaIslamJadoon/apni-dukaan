@echo off
REM Apni Dukaan Print Agent - double-click launcher (server PC).
REM Pairing AUTO hai: pehli dafa Dashboard - Printers and Devices mein Jor dein dabana hoga.
cd /d "%~dp0"
title Apni Dukaan Print Agent
echo Print agent start ho raha hai... band karne ke liye Ctrl+C ya window band karein.
node agent.js
pause
