"use strict";
// Pairing helper — Owner ke session se naya print-agent token banata hai aur
// config mein likh deta hai. Token server par sirf hash ki surat mein rehta
// hai aur yahan sirf EK dafa milta hai; kho jaye to dobara pair karein
// (purana token khud bakhud band ho jata hai).
//
// Chalana (server PC par, Owner browser mein login ho):
//   node pair.js --server http://192.168.1.10:3100 --cookie "pos_staff_session=XXXX" --name "Counter PC Print Agent"
// Cookie kahan se milegi: browser DevTools (F12) → Application → Cookies →
// pos_staff_session ki value. YA owner login API se:
//   curl -s -X POST <server>/api/v1/auth/staff/login -H "content-type: application/json"
//        -d "{\"staffId\":\"owner\",\"pin\":\"....\"}" -i  → set-cookie header
// Phir ye token print-agent.config.json mein save ho jata hai. Token kabhi
// chat/email/git mein share NA karein.
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");

function arg(name) {
  const i = process.argv.indexOf("--" + name);
  return i >= 0 ? process.argv[i + 1] : undefined;
}

async function main() {
  const server = (arg("server") || "http://127.0.0.1:3100").replace(/\/+$/, "");
  const cookie = arg("cookie") || process.env.POS_OWNER_COOKIE || "";
  const name = arg("name") || "Counter PC Print Agent";
  const configPath = arg("config") || path.join(__dirname, "print-agent.config.json");
  if (!cookie) {
    console.error('✗ --cookie "pos_staff_session=..." zaroori hai (owner session). Upar wali hidayat parhein.');
    process.exit(2);
  }
  const res = await fetch(server + "/api/v1/owner/print-agents", {
    method: "POST",
    headers: { "content-type": "application/json", cookie },
    body: JSON.stringify({ displayName: name, machineName: os.hostname(), version: require("./package.json").version }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    console.error(`✗ Pairing fail: HTTP ${res.status} — ${data?.error?.message || "unknown error"} (owner login hai? cookie expire to nahi?)`);
    process.exit(1);
  }
  const cfg = fs.existsSync(configPath) ? JSON.parse(fs.readFileSync(configPath, "utf8")) : {};
  cfg.serverUrl = server;
  cfg.agentName = data.agent.displayName;
  cfg.agentToken = data.token;
  cfg.machineName = os.hostname();
  fs.writeFileSync(configPath, JSON.stringify(cfg, null, 2) + "\n");
  console.log(`✓ Pairing ho gayi: agent "${data.agent.displayName}" (id ${data.agent.id})`);
  console.log(`✓ Token config mein save ho gaya: ${configPath}`);
  console.log("  Ab agent chalana hai: node agent.js");
  // Auto-start: pairing ke baad Windows logon par agent khud chal
  // jaye — current user ke Startup folder mein chhoti si .bat.
  // Ye sirf pairing KE BAAD banti hai, is liye unpaired agent
  // kabhi khud nahi chalta aur na koi error dikhata hai.
  // Fail ho jaye to pairing par koi asar nahi (try/catch).
  try {
    const startup = process.env.APPDATA
      ? path.join(process.env.APPDATA, "Microsoft", "Windows", "Start Menu", "Programs", "Startup")
      : "";
    if (startup && fs.existsSync(startup)) {
      const bat =
        "@echo off\r\ncd /d \"" + __dirname + "\"\r\nstart /min \"\" node agent.js\r\n";
      fs.writeFileSync(path.join(startup, "CanteenPOS-PrintAgent.bat"), bat);
      console.log("✓ Auto-start set ho gaya: Windows logon par print agent khud chalega.");
    }
  } catch { /* auto-start optional hai — pairing fail nahi honi chahiye */ }
}

main().catch((e) => { console.error("✗", e.message); process.exit(1); });
