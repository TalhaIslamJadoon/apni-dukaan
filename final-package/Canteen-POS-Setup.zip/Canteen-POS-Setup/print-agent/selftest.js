"use strict";
// Self-test — server/printer ke baghair rendering ki tasdeeq:
// sample receipt + kitchen ticket + TSPL label banata hai, Code128 widths
// validate karta hai, aur files outbox/selftest/ mein likhta hai.
//   node selftest.js
const fs = require("node:fs");
const path = require("node:path");
const { code128Widths, isEncodable } = require("./lib/code128");
const { renderReceipt, renderKitchenTicket } = require("./lib/escpos");
const { renderTspl } = require("./lib/labels");

const settings = { canteenName: "College Canteen", groceryName: "Campus Grocery Store", collegeName: "" };
const sampleJob = {
  id: "selftest-0000-0000-0000-000000000000",
  type: "receipt",
  isReprint: false,
  __width: 48,
  payload: {
    billNo: "B-1001",
    orders: [{
      mode: "canteen", token: 7, billNo: "B-1001",
      lines: [
        { name: "Chicken Burger", price: 350, qty: 2 },
        { name: "Cold Drink (Can) — Pepsi", price: 80, qty: 2 },
        { name: "French Fries (Large) Extra Special Family Pack", price: 250, qty: 1 },
      ],
      subtotal: 1110, discount: 110, total: 1000,
      cashier: "Canteen Wala", payment: "Cash", tendered: 1000, change: 0,
      source: "counter", createdAt: new Date().toISOString(),
    }],
  },
};

function main() {
  const outDir = path.join(__dirname, "outbox", "selftest");
  fs.mkdirSync(outDir, { recursive: true });

  const receipt = renderReceipt(sampleJob, settings);
  fs.writeFileSync(path.join(outDir, "receipt-sample.prn"), receipt);
  const receiptText = receipt.toString("latin1");
  for (const needle of ["College Canteen", "B-1001", "Chicken Burger", "GRAND TOTAL", "Token No:", "PAY|MERCHANT:DEMO-POS-001|BILL:B-1001|AMOUNT:1000|PKR"]) {
    if (!receiptText.includes(needle)) throw new Error(`Receipt mein missing: ${needle}`);
  }
  console.log(`✓ receipt: ${receipt.length} bytes — header/bill/items/total/token/QR payload sab mojood`);

  const kitchen = renderKitchenTicket({ ...sampleJob, type: "kitchen_ticket" }, settings);
  const kText = kitchen.toString("latin1");
  if (!kText.includes("TOKEN 7") || !kText.includes("Chicken Burger")) throw new Error("Kitchen ticket content missing");
  console.log(`✓ kitchen ticket: ${kitchen.length} bytes`);

  const code = "8960000001210";
  if (!isEncodable(code)) throw new Error("sample code encodable nahi");
  const widths = code128Widths(code);
  const totalModules = widths.reduce((s, x) => s + x, 0);
  console.log(`✓ code128: "${code}" → ${widths.length} runs, ${totalModules} modules (start+data+checksum+stop)`);

  const labelJob = { id: "selftest-label", type: "barcode_label", payload: { labels: [{ name: "Rafhan Custard Powder — Vanilla", price: 450, code, sku: "1210", widthMm: 50, heightMm: 30 }] } };
  const tspl = renderTspl(labelJob);
  fs.writeFileSync(path.join(outDir, "label-sample.prn"), tspl);
  const t = tspl.toString("ascii");
  for (const needle of ["SIZE 50 mm, 30 mm", `BARCODE `, `"128"`, `"${code}"`, "PRINT 1,1"]) {
    if (!t.includes(needle)) throw new Error(`TSPL mein missing: ${needle}`);
  }
  console.log(`✓ TSPL label: ${tspl.length} bytes — SIZE 50x30mm + native BARCODE "128" command`);
  console.log(`Files: ${outDir}`);
  console.log("SELFTEST PASS ✓");
}

main();
