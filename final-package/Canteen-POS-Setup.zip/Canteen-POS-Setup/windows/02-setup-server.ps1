# =====================================================================
#  Canteen POS - Phase 2 - Script 02: Server Setup (Windows)
#  - C:\CanteenPOS layout banata hai, app copy karke build karta hai
#  - PostgreSQL mein database + app user banata hai
#  - App ka password OPERATOR khud type karta hai (koi password is
#    file mein NAHI hai) - wohi password .env mein jata hai aur
#    operator use Secure Vault mein save karta hai
#  - npm run db:setup (migrate + seed) chalata hai
#  - Aakhir mein server ko test ke liye chala kar port check karta hai
#  Admin PowerShell mein chalain. Re-run karna safe hai (idempotent).
#  NOTE: Linux par authored hai - Windows par abhi test nahi hui.
#
#  App source kahan se ayega?
#  Script pehle <is pack ke folder>\app-source\ dekhta hai (deployment
#  USB par app ki files wahan rakhi hongi, node_modules ke baghair).
#  Na mile to script rasta poochta hai.
# =====================================================================

param(
    [string]$SourceDir = ''
)

$ErrorActionPreference = 'Stop'

$Port     = 3100
$Root     = 'C:\CanteenPOS'
$AppDir   = Join-Path $Root 'app'
$BackupDir = Join-Path $Root 'Backups'
$LogDir   = Join-Path $Root 'Logs'
$DbName   = 'canteen_pos'
$DbUser   = 'canteen_pos_app'
$DbHost   = '127.0.0.1'
$DbPort   = 5432

function Test-IsAdmin {
    $identity  = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Find-Psql {
    $base = 'C:\Program Files\PostgreSQL'
    if (Test-Path $base) {
        $dirs = Get-ChildItem $base -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending
        foreach ($d in $dirs) {
            $candidate = Join-Path $d.FullName 'bin\psql.exe'
            if (Test-Path $candidate) { return $candidate }
        }
    }
    $cmd = Get-Command psql.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

function Read-SecurePlain([string]$Prompt) {
    $sec = Read-Host $Prompt -AsSecureString
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}

if (-not (Test-IsAdmin)) {
    Write-Host 'Admin rights chahiye - UAC prompt par Yes dabain...' -ForegroundColor Yellow
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

try {
    Write-Host ''
    Write-Host '===================================================' -ForegroundColor Cyan
    Write-Host ' STEP 2/3 - Canteen POS server setup' -ForegroundColor Cyan
    Write-Host '===================================================' -ForegroundColor Cyan

    # --- 1. Pehle se zaroori cheezein check ---------------------------
    if (-not (Get-Command node.exe -ErrorAction SilentlyContinue)) {
        throw 'Node.js nahi mila - pehle 01-install-prereqs.ps1 chalain.'
    }
    $psql = Find-Psql
    if (-not $psql) { throw 'PostgreSQL (psql) nahi mila - pehle 01-install-prereqs.ps1 chalain.' }

    $svc = Get-Service -Name 'postgresql*' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($svc -and $svc.Status -ne 'Running') {
        Start-Service -Name $svc.Name
        Write-Host ("PostgreSQL service start kar diya: {0}" -f $svc.Name)
    }

    # --- 2. Folder layout ----------------------------------------------
    foreach ($dir in @($Root, $AppDir, $BackupDir, $LogDir)) {
        if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    }
    Write-Host ("Folders tayar hain: {0}" -f $Root) -ForegroundColor Green

    # --- 3. App source copy ---------------------------------------------
    if ($SourceDir -eq '') {
        $defaultSource = Join-Path $PSScriptRoot 'app-source'
        if (Test-Path (Join-Path $defaultSource 'package.json')) {
            $SourceDir = $defaultSource
        } elseif (-not (Test-Path (Join-Path $AppDir 'package.json'))) {
            $SourceDir = Read-Host 'App source ka folder likhein (jahan package.json hai)'
        }
    }
    if ($SourceDir -ne '') {
        if (-not (Test-Path (Join-Path $SourceDir 'package.json'))) {
            throw ("Us folder mein package.json nahi mila: {0}" -f $SourceDir)
        }
        Write-Host ("App copy ho raha hai: {0} -> {1}" -f $SourceDir, $AppDir)
        # .env* is liye exclude hai taake purani/development settings
        # galti se production mein na aa jain; node_modules Windows
        # par fresh bane ga.
        & robocopy $SourceDir $AppDir /E /XD node_modules .next .git screenshots backups /XF '.env*' 'tsconfig.tsbuildinfo' /NFL /NDL /NJH /NJS
        if ($LASTEXITCODE -ge 8) { throw ("robocopy fail hua (code {0})" -f $LASTEXITCODE) }
        Write-Host 'App copy ho gaya.' -ForegroundColor Green
    } else {
        Write-Host 'App pehle se C:\CanteenPOS\app mein hai - copy wala step skip.' -ForegroundColor Green
    }

    # --- 4. Database + .env ---------------------------------------------
    $envFile = Join-Path $AppDir '.env'
    $dbUrl = $null

    if (Test-Path $envFile) {
        foreach ($raw in Get-Content $envFile) {
            if ($raw -match '^\s*DATABASE_URL\s*=\s*(.+)$') { $dbUrl = $Matches[1].Trim() }
        }
    }

    if ($dbUrl) {
        Write-Host '.env pehle se maujood hai - usi DATABASE_URL ko reuse karenge.' -ForegroundColor Green
        # Database sach mein jawab deta hai ya nahi, check kar lein
        # (yahan ErrorActionPreference thodi dair Continue hai - PS 5.1
        #  mein native command ki stderr redirection warna script gira
        #  sakti hai):
        $prevEAP = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        & $psql $dbUrl -t -A -c 'SELECT 1' 2>$null | Out-Null
        $psqlCheckCode = $LASTEXITCODE
        $ErrorActionPreference = $prevEAP
        if ($psqlCheckCode -ne 0) {
            throw '.env wala database connect nahi ho raha. PostgreSQL service check karein, ya .env delete karke script dobara chalain (naya password set ho jayega).'
        }
        Write-Host 'Database connection OK hai.' -ForegroundColor Green
    } else {
        Write-Host ''
        Write-Host '--- Database banana ---' -ForegroundColor Cyan
        Write-Host 'Pehle PostgreSQL ke superuser (postgres) ka woh password likhein'
        Write-Host 'jo 01 wale installer mein set kiya tha:'
        $pgPassword = Read-SecurePlain 'postgres (superuser) password'
        $env:PGPASSWORD = $pgPassword

        Write-Host ''
        Write-Host 'Ab APP ke database user ke liye NAYA password banain.'
        Write-Host 'Yehi password baad mein Secure Vault mein save karna hai.' -ForegroundColor Magenta
        $appPassword1 = Read-SecurePlain 'App DB password (naya)'
        $appPassword2 = Read-SecurePlain 'App DB password (dobara likhein)'
        if ($appPassword1 -ne $appPassword2) { throw 'Dono dafa password aik jaisa nahi likha gaya - script dobara chalain.' }
        if ($appPassword1.Length -lt 10) { throw 'Password kam az kam 10 characters ka rakhein - script dobara chalain.' }

        # Role (user) - hai to password update, nahi to naya:
        $sqlPass = $appPassword1.Replace("'", "''")
        $roleExists = & $psql -U postgres -h $DbHost -p $DbPort -t -A -c "SELECT 1 FROM pg_roles WHERE rolname = '$DbUser'"
        if ($LASTEXITCODE -ne 0) { throw 'postgres superuser se connect nahi hua - password check karein.' }
        if ($roleExists -match '1') {
            & $psql -U postgres -h $DbHost -p $DbPort -c "ALTER USER $DbUser WITH PASSWORD '$sqlPass'" | Out-Null
            Write-Host ("DB user '{0}' pehle se tha - password is run ke password par set kar diya." -f $DbUser) -ForegroundColor Yellow
        } else {
            & $psql -U postgres -h $DbHost -p $DbPort -c "CREATE USER $DbUser WITH PASSWORD '$sqlPass'" | Out-Null
            Write-Host ("DB user '{0}' ban gaya." -f $DbUser) -ForegroundColor Green
        }

        # Database - hai to theek, nahi to naya:
        $dbExists = & $psql -U postgres -h $DbHost -p $DbPort -t -A -c "SELECT 1 FROM pg_database WHERE datname = '$DbName'"
        if ($dbExists -match '1') {
            & $psql -U postgres -h $DbHost -p $DbPort -c "ALTER DATABASE $DbName OWNER TO $DbUser" | Out-Null
            Write-Host ("Database '{0}' pehle se hai - owner set kar diya." -f $DbName)
        } else {
            & $psql -U postgres -h $DbHost -p $DbPort -c "CREATE DATABASE $DbName OWNER $DbUser" | Out-Null
            Write-Host ("Database '{0}' ban gaya." -f $DbName) -ForegroundColor Green
        }
        Remove-Item Env:\PGPASSWORD -ErrorAction SilentlyContinue
        $pgPassword = $null

        # Connection string ke liye password ko URL-encode karna zaroori
        # hai (special characters tootein ge warna):
        $encoded = [System.Uri]::EscapeDataString($appPassword1)
        $dbUrl = "postgres://${DbUser}:${encoded}@${DbHost}:${DbPort}/${DbName}"
        $appPassword1 = $null; $appPassword2 = $null

        $envLines = @(
            '# Canteen POS - production settings (02-setup-server.ps1 ne banaya)',
            '# Is file ko kisi ke sath share NA karein - is mein DB password hai.',
            "DATABASE_URL=$dbUrl",
            "BACKUP_DIR=$BackupDir",
            '# COOKIE_SECURE=1          # sirf tab on karein jab HTTPS (Cloudflare Tunnel) live ho',
            '# PUBLIC_ORDER_BASE_URL=https://order.example.com   # table-QR cards ke liye, tunnel ke baad'
        )
        [IO.File]::WriteAllLines($envFile, $envLines)

        # .env ki hifazat: sirf SYSTEM, Administrators aur ye account:
        $me = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        & icacls $envFile /inheritance:r /grant:r 'SYSTEM:F' 'Administrators:F' ("{0}:F" -f $me) | Out-Null
        Write-Host '.env ban gaya aur us ki permissions band kar di hain.' -ForegroundColor Green
        Write-Host 'NOTE: App DB password abhi Secure Vault mein save kar lein.' -ForegroundColor Magenta
    }

    # --- 5. Dependencies + build ----------------------------------------
    Set-Location $AppDir
    $env:DATABASE_URL = $dbUrl
    Write-Host ''
    Write-Host '--- npm install (pehli dafa waqt lagega) ---' -ForegroundColor Cyan
    if (Test-Path (Join-Path $AppDir 'package-lock.json')) {
        & npm.cmd ci
    } else {
        & npm.cmd install
    }
    if ($LASTEXITCODE -ne 0) { throw 'npm install fail hua.' }

    Write-Host '--- npm run build ---' -ForegroundColor Cyan
    & npm.cmd run build
    if ($LASTEXITCODE -ne 0) { throw 'npm run build fail hua.' }

    # --- 6. Database schema + seed (app ke apne scripts) -----------------
    Write-Host '--- npm run db:setup (migrate + seed) ---' -ForegroundColor Cyan
    & npm.cmd run db:setup
    if ($LASTEXITCODE -ne 0) { throw 'db:setup fail hua - upar wali error dekhein.' }
    Write-Host 'Database schema + seed complete.' -ForegroundColor Green

    # --- 7. Helper files C:\CanteenPOS mein copy --------------------------
    foreach ($helper in @('run-server.ps1', '04-daily-backup.ps1', 'start-server.bat', 'stop-server.bat')) {
        $srcHelper = Join-Path $PSScriptRoot $helper
        if (Test-Path $srcHelper) { Copy-Item $srcHelper -Destination (Join-Path $Root $helper) -Force }
    }
    Write-Host 'Helper files (run-server / start / stop / backup) C:\CanteenPOS mein aa gaye.'

    # --- 8. Smoke test: server chala kar port check -----------------------
    Write-Host ''
    Write-Host ("--- Smoke test: server port {0} par ---" -f $Port) -ForegroundColor Cyan
    $launcher = Join-Path $Root 'run-server.ps1'
    $proc = Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$launcher`"" -PassThru -WindowStyle Hidden
    $ok = $false
    for ($i = 1; $i -le 45; $i++) {
        Start-Sleep -Seconds 2
        try {
            $resp = Invoke-WebRequest -Uri ("http://127.0.0.1:{0}/" -f $Port) -UseBasicParsing -TimeoutSec 3
            if ($resp.StatusCode -ge 200) { $ok = $true; break }
        } catch {
            if ($_.Exception.Response) { $ok = $true; break }  # koi bhi HTTP jawab = server zinda hai
        }
        if ($proc.HasExited) { break }
    }
    # Test server band karna (cleanup fail ho to bhi result na giraye):
    $prevEAP = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $listener = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($listener) { & taskkill /PID $listener.OwningProcess /T /F 2>$null | Out-Null }
    if (-not $proc.HasExited) { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue }
    $ErrorActionPreference = $prevEAP

    if ($ok) {
        Write-Host ("SMOKE TEST PASS - server http://127.0.0.1:{0} par jawab de raha hai." -f $Port) -ForegroundColor Green
    } else {
        throw ("Smoke test fail - server port {0} par nahi aya. Log dekhein: {1}" -f $Port, (Join-Path $LogDir 'server.log'))
    }

    Write-Host ''
    Write-Host 'STEP 2 COMPLETE. Ab 03-autostart-and-power.ps1 chalain.' -ForegroundColor Green
    Write-Host 'Phir PC restart karke dekhein ke server khud start hota hai ya nahi.'
}
catch {
    Write-Host ''
    Write-Host ("ERROR: {0}" -f $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Masla hal karke script dobara chalain - dobara chalana safe hai.'
}
Write-Host ''
Read-Host 'Band karne ke liye Enter dabain'
