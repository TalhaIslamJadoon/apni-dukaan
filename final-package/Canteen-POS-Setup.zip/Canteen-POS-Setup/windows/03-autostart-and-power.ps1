# =====================================================================
#  Canteen POS - Phase 2 - Script 03: Auto-Start + Power + Firewall
#  - Scheduled Task: PC on hote hi server khud start (SYSTEM account)
#  - Scheduled Task: roz raat 22:30 backup (na ho sakay to agle boot
#    par khud chal jata hai - StartWhenAvailable)
#  - Power: bijli (AC) lagi ho to PC kabhi sleep nahi hoga;
#    screen band ho sakti hai
#  - Firewall: port 3100 sirf LOCAL SUBNET (dukaan ka LAN) ke liye
#  Admin PowerShell mein chalain. Re-run safe hai (tasks -Force se
#  update ho jate hain). Linux par authored - Windows par untested.
# =====================================================================

$ErrorActionPreference = 'Stop'

$Port      = 3100
$Root      = 'C:\CanteenPOS'
$Launcher  = Join-Path $Root 'run-server.ps1'
$BackupPs1 = Join-Path $Root '04-daily-backup.ps1'
$PsExe     = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'

function Test-IsAdmin {
    $identity  = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-IsAdmin)) {
    Write-Host 'Admin rights chahiye - UAC prompt par Yes dabain...' -ForegroundColor Yellow
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

try {
    Write-Host ''
    Write-Host '===================================================' -ForegroundColor Cyan
    Write-Host ' STEP 3/3 - Auto-start + Power + Firewall' -ForegroundColor Cyan
    Write-Host '===================================================' -ForegroundColor Cyan

    # Helper files pack se C:\CanteenPOS mein le aain (agar 02 se na aye hon):
    foreach ($helper in @('run-server.ps1', '04-daily-backup.ps1')) {
        $dest = Join-Path $Root $helper
        $srcHelper = Join-Path $PSScriptRoot $helper
        if ((-not (Test-Path $dest)) -and (Test-Path $srcHelper)) {
            Copy-Item $srcHelper -Destination $dest -Force
        }
    }
    if (-not (Test-Path $Launcher))  { throw 'run-server.ps1 nahi mila - pehle 02-setup-server.ps1 chalain.' }
    if (-not (Test-Path $BackupPs1)) { throw '04-daily-backup.ps1 nahi mila - pack dobara copy karein.' }

    # --- 1. Server auto-start task (boot par) ---------------------------
    $serverAction  = New-ScheduledTaskAction -Execute $PsExe -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$Launcher`""
    $serverTrigger = New-ScheduledTaskTrigger -AtStartup
    $serverPrincipal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $serverSettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit (New-TimeSpan -Seconds 0)
    Register-ScheduledTask -TaskName 'CanteenPOS Server' -Action $serverAction -Trigger $serverTrigger -Principal $serverPrincipal -Settings $serverSettings -Description 'Canteen POS server - PC on hote hi khud start' -Force | Out-Null
    Write-Host "Scheduled Task 'CanteenPOS Server' ban gaya (boot par auto-start)." -ForegroundColor Green

    # --- 2. Daily backup task (22:30) ------------------------------------
    $backupAction  = New-ScheduledTaskAction -Execute $PsExe -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$BackupPs1`""
    $backupTrigger = New-ScheduledTaskTrigger -Daily -At '22:30'
    $backupSettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 10)
    Register-ScheduledTask -TaskName 'CanteenPOS Daily Backup' -Action $backupAction -Trigger $backupTrigger -Principal $serverPrincipal -Settings $backupSettings -Description 'Canteen POS database ka rozana backup (C:\CanteenPOS\Backups)' -Force | Out-Null
    Write-Host "Scheduled Task 'CanteenPOS Daily Backup' ban gaya (roz 22:30; PC band ho to agle boot par)." -ForegroundColor Green

    # --- 3. Power: AC par sleep band, screen band ho sakti hai ------------
    Write-Host 'Power settings badal rahe hain (sirf AC / bijli par)...'
    & powercfg /change standby-timeout-ac 0    # kabhi sleep nahi (AC)
    & powercfg /change hibernate-timeout-ac 0  # kabhi hibernate nahi (AC)
    & powercfg /change disk-timeout-ac 0       # disk band nahi (AC)
    & powercfg /change monitor-timeout-ac 10   # screen 10 minute mein band - ye theek hai
    Write-Host 'Power: AC par sleep OFF, screen 10 min mein OFF (ye normal hai).' -ForegroundColor Green
    Write-Host 'NOTE: Agar ye PC laptop hai to Settings > Power mein "lid band karne par" wala'
    Write-Host '      action "Do nothing" kar dein, warna dhakkan band = sleep ho sakta hai.' -ForegroundColor Yellow

    # --- 4. Firewall: port 3100 sirf local subnet ke liye ------------------
    $ruleName = 'Canteen POS (3100)'
    Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
    New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Action Allow -Protocol TCP -LocalPort $Port -RemoteAddress LocalSubnet -Profile Private | Out-Null
    Write-Host ("Firewall rule ban gaya: port {0} sirf local subnet + Private profile ke liye khula hai." -f $Port) -ForegroundColor Green
    Write-Host 'NOTE: Dukaan ke router wale network ka profile Windows mein "Private" hona'
    Write-Host '      chahiye (Settings > Network > Properties). Public ho to rule kaam nahi karega.' -ForegroundColor Yellow

    # --- 5. Is PC ke LAN addresses ------------------------------------------
    Write-Host ''
    Write-Host 'Is PC ke LAN addresses (counter devices par yehi likhna hoga):' -ForegroundColor Cyan
    $ips = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' }
    foreach ($ip in $ips) {
        Write-Host ("  http://{0}:{1}" -f $ip.IPAddress, $Port) -ForegroundColor Green
    }
    Write-Host 'In mein se router wale network ka address note kar lein - README mein'
    Write-Host 'IP FIX karne wala step zaroor karein taake ye address roz na badle.'

    Write-Host ''
    Write-Host 'STEP 3 COMPLETE. Ab PC restart karke test karein:' -ForegroundColor Green
    Write-Host '  1) Restart ke 1-2 minute baad dusri device se http://<upar wala IP>:3100 kholain'
    Write-Host '  2) Staff login (Owner PIN) se andar ja kar dekhein'
}
catch {
    Write-Host ''
    Write-Host ("ERROR: {0}" -f $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Masla hal karke script dobara chalain - dobara chalana safe hai.'
}
Write-Host ''
Read-Host 'Band karne ke liye Enter dabain'
