# =====================================================================
#  Canteen POS - Phase 2 - Script 01: Install Prerequisites (Windows)
#  Node.js LTS + PostgreSQL install/check karta hai (winget se).
#  Admin PowerShell mein chalain. Re-run karna safe hai (idempotent).
#  NOTE: Ye script Linux par author hui hai, Windows par abhi test
#  nahi hui - deployment day par pehli dafa sath mila kar chalayenge.
# =====================================================================

$ErrorActionPreference = 'Stop'

function Test-IsAdmin {
    $identity  = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Refresh-Path {
    $machine = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $user    = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = "$machine;$user"
}

function Find-Psql {
    $base = 'C:\Program Files\PostgreSQL'
    if (Test-Path $base) {
        $dirs = Get-ChildItem $base -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending
        foreach ($d in $dirs) {
            $candidate = Join-Path $d.FullName 'bin\psql.exe'
            if (Test-Path $candidate) { return $candidate }
        }
    }
    $cmd = Get-Command psql.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

# --- Khud ko Admin bana kar dobara chalana (agar admin nahi) ----------
if (-not (Test-IsAdmin)) {
    Write-Host 'Admin rights chahiye - UAC prompt par Yes dabain...' -ForegroundColor Yellow
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

try {
    Write-Host ''
    Write-Host '===================================================' -ForegroundColor Cyan
    Write-Host ' STEP 1/3 - Node.js + PostgreSQL install / check' -ForegroundColor Cyan
    Write-Host '===================================================' -ForegroundColor Cyan

    # --- Windows version check ---------------------------------------
    $os = Get-CimInstance Win32_OperatingSystem
    Write-Host ("Windows: {0} (Build {1})" -f $os.Caption, $os.BuildNumber)
    if ([int]$os.BuildNumber -ge 22000) {
        Write-Host 'Windows 11 detected - perfect, yehi side use karni hai.' -ForegroundColor Green
    } elseif ([int]$os.BuildNumber -ge 10240) {
        Write-Host 'Windows 10 detected - chalega, lekin Windows 11 wali side zyada behtar hai (10 ki support khatam ho chuki hai).' -ForegroundColor Yellow
    } else {
        throw 'Ye Windows bohat purana hai - Windows 10/11 chahiye.'
    }

    # --- winget check --------------------------------------------------
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if (-not $winget) {
        Write-Host ''
        Write-Host 'winget nahi mila. Pehle Microsoft Store se "App Installer" update/install karein,' -ForegroundColor Yellow
        Write-Host 'ya phir Node.js aur PostgreSQL in sites se haath se install karein:' -ForegroundColor Yellow
        Write-Host '  Node.js    : https://nodejs.org (LTS version)'
        Write-Host '  PostgreSQL : https://www.postgresql.org/download/windows/'
        throw 'winget missing - upar wali hidayat par amal karke script dobara chalain.'
    }

    # --- Node.js -------------------------------------------------------
    Refresh-Path
    $node = Get-Command node.exe -ErrorAction SilentlyContinue
    if ($node) {
        Write-Host ("Node.js pehle se hai: {0}" -f (& node --version)) -ForegroundColor Green
    } else {
        Write-Host 'Node.js install ho raha hai (winget, LTS)...' -ForegroundColor Yellow
        & winget install --id OpenJS.NodeJS.LTS -e --accept-source-agreements --accept-package-agreements
        Refresh-Path
        $node = Get-Command node.exe -ErrorAction SilentlyContinue
        if (-not $node) { throw 'Node.js install nahi hua - https://nodejs.org se LTS haath se install karke dobara chalain.' }
        Write-Host ("Node.js install ho gaya: {0}" -f (& node --version)) -ForegroundColor Green
    }

    # --- PostgreSQL ----------------------------------------------------
    $psql = Find-Psql
    if ($psql) {
        Write-Host ("PostgreSQL pehle se hai: {0}" -f $psql) -ForegroundColor Green
    } else {
        Write-Host ''
        Write-Host 'PostgreSQL install ho raha hai...' -ForegroundColor Yellow
        Write-Host 'AHEM: Installer darmiyan mein superuser (postgres) ka PASSWORD mangega.' -ForegroundColor Magenta
        Write-Host 'Wohi password likhein jo aap Secure Vault mein save karenge - bhoolna mat.' -ForegroundColor Magenta
        Write-Host ''
        $installed = $false
        foreach ($pkg in @('PostgreSQL.PostgreSQL.17', 'PostgreSQL.PostgreSQL.16')) {
            Write-Host ("Try: winget package {0}" -f $pkg)
            & winget install --id $pkg -e --accept-source-agreements --accept-package-agreements
            Refresh-Path
            $psql = Find-Psql
            if ($psql) { $installed = $true; break }
        }
        if (-not $installed) {
            throw 'PostgreSQL winget se install nahi hua - https://www.postgresql.org/download/windows/ se haath se install karein (port 5432 default rakhein), phir ye script dobara chalain.'
        }
        Write-Host ("PostgreSQL install ho gaya: {0}" -f $psql) -ForegroundColor Green
    }

    # --- PostgreSQL service: Automatic + Running -----------------------
    $svc = Get-Service -Name 'postgresql*' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($svc) {
        if ($svc.StartType -ne 'Automatic') {
            Set-Service -Name $svc.Name -StartupType Automatic
            Write-Host ("Service {0} ko Automatic kar diya." -f $svc.Name)
        }
        if ($svc.Status -ne 'Running') {
            Start-Service -Name $svc.Name
            Write-Host ("Service {0} start kar diya." -f $svc.Name) -ForegroundColor Green
        } else {
            Write-Host ("PostgreSQL service chal raha hai: {0}" -f $svc.Name) -ForegroundColor Green
        }
    } else {
        Write-Host 'PostgreSQL service nahi mila - install dobara check karein.' -ForegroundColor Yellow
    }

    # --- Versions ki report --------------------------------------------
    Write-Host ''
    Write-Host '--- Installed versions ---' -ForegroundColor Cyan
    Write-Host ("node : {0}" -f (& node --version))
    Write-Host ("npm  : {0}" -f (& npm --version))
    if ($psql) { Write-Host ("psql : {0}" -f (& $psql --version)) }

    Write-Host ''
    Write-Host 'STEP 1 COMPLETE. Ab 02-setup-server.ps1 chalain.' -ForegroundColor Green
}
catch {
    Write-Host ''
    Write-Host ("ERROR: {0}" -f $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Masla hal karke script dobara chalain - dobara chalana safe hai.'
}
Write-Host ''
Read-Host 'Band karne ke liye Enter dabain'
