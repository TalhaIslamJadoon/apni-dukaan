import { handler, ok, body } from "@/server/http";
import { q, one, ApiError } from "@/server/db";
import { hashCredential, customerLogin } from "@/server/auth";

export const dynamic = "force-dynamic";

// POST /api/v1/auth/customer/register — remote customers only (plan §1.3).
// Mobile is the unique login ID; student/staff ID stays optional (Udhaar).
export const POST = handler(async (req) => {
  const b = await body<{ name: string; mobile: string; password: string; placeType: string; placeDetail: string; studentId?: string }>(req);
  if (!b.name?.trim() || !b.mobile?.trim() || !b.password) throw new ApiError(400, "MISSING_FIELDS", "Naam, mobile aur password zaroori hain");
  if (!["Hostel Room", "Office", "Other"].includes(b.placeType)) throw new ApiError(400, "BAD_PLACE_TYPE", "Place type ghalat hai");
  const mobile = b.mobile.trim();
  const exists = await one("SELECT id FROM customers WHERE mobile = $1", [mobile]);
  if (exists) throw new ApiError(409, "MOBILE_EXISTS", "Is mobile par account pehle se hai — login karein");
  const hash = await hashCredential(b.password);
  await q(
    `INSERT INTO customers (full_name, mobile, password_hash, place_type, place_detail, external_student_staff_id)
     VALUES ($1,$2,$3,$4,$5,$6)`,
    [b.name.trim(), mobile, hash, b.placeType, b.placeDetail ?? "", b.studentId?.trim() || null]
  );
  const { principal, cookie } = await customerLogin(req, mobile, b.password);
  return ok({
    account: {
      name: principal.name, mobile: principal.mobile, placeType: principal.placeType,
      placeDetail: principal.placeDetail, ...(principal.externalId ? { studentId: principal.externalId } : {}),
    },
  }, 201, { "set-cookie": cookie });
});
