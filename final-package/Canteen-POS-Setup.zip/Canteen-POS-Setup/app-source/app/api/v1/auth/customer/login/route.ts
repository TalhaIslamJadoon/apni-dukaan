import { handler, ok, body } from "@/server/http";
import { ApiError } from "@/server/db";
import { customerLogin } from "@/server/auth";

export const dynamic = "force-dynamic";

// POST /api/v1/auth/customer/login { mobile, password }
export const POST = handler(async (req) => {
  const b = await body<{ mobile: string; password: string }>(req);
  if (!b.mobile || !b.password) throw new ApiError(400, "MISSING_FIELDS", "Mobile aur password zaroori hain");
  const { principal, cookie } = await customerLogin(req, b.mobile.trim(), b.password);
  return ok({
    account: {
      name: principal.name, mobile: principal.mobile, placeType: principal.placeType,
      placeDetail: principal.placeDetail, ...(principal.externalId ? { studentId: principal.externalId } : {}),
    },
  }, 200, { "set-cookie": cookie });
});
