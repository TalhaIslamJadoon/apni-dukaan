"use strict";
// Canteen POS — Windows Print Agent (plan §1.5)
// Server ki print queue se jobs claim karke asal printers par bhejta hai:
//   receipt / kitchen_ticket / table_card → ESC/POS (80mm)
//   barcode_label                          → TSPL / ZPL / ESC-POS native barcode
// Transports: file (PRINT_TO_FILE test) | tcp 9100 | windows spooler (RAW).
// Chalana:  node agent.js [--config path] [--once] [--to-file]
// Pairing:  pehle `node pair.js` chalayein (token config mein ajata hai).
const fs = require("node:fs");
const os = require("node:os");
const { loadConfig, resolvePrinter } = require("./lib/config");
const { Api } = require("./lib/api");
const { renderReceipt, renderKitchenTicket, renderTableCard } = require("./lib/escpos");
const { renderLabels } = require("./lib/labels");
const { send } = require("./lib/send");
const { discoverPrinters } = require("./lib/printers");

const argv = process.argv.slice(2);
const cfg = loadConfig(argv);
const api = new Api(cfg);
const once = argv.includes("--once");

const log = (...a) => console.log(`[${new Date().toISOString()}]`, ...a);

let settings = null; // shop names (receipt header) — bootstrap se, refresh hota rehta hai
async function refreshSettings() {
  const s = await api.shopNames();
  if (s) settings = s;
}

// Discovered printers — har heartbeat ke saath server ko jate hain (Owner ke
// Devices screen ke dropdowns ke liye). Discovery fail ho to purani list hi
// dobara bhej dete hain; agent is ki wajah se kabhi nahi rukta.
let discovered = [];
async function refreshPrinters() {
  try {
    discovered = await discoverPrinters(cfg);
  } catch (e) {
    log(`printer discovery ✗ ${e.message} (purani list hi bheji jayegi)`);
  }
  return discovered;
}

function render(job, printer) {
  const j = { ...job, __width: printer.paperWidthChars || 48 };
  switch (job.type) {
    case "receipt": return renderReceipt(j, settings);
    case "kitchen_ticket": return renderKitchenTicket(j, settings);
    case "table_card": return renderTableCard(j, settings);
    case "barcode_label": return renderLabels(j, printer.commandLanguage);
    default: throw new Error(`Unknown job type: ${job.type}`);
  }
}

async function processOne() {
  const job = await api.claimNext();
  if (!job) return false;
  const printer = resolvePrinter(cfg, job);
  log(`claim: ${job.type} job=${job.id.slice(0, 8)} bill=${job.payload?.billNo ?? "-"} → ${printer.transport}/${printer.commandLanguage} (${printer.source})`);
  try {
    const buf = render(job, printer);
    const sent = await send(buf, job, printer, cfg);
    await api.complete(job.id);
    log(`printed ✓ job=${job.id.slice(0, 8)} bytes=${sent.bytes} via ${sent.transport} ${sent.detail}`);
  } catch (e) {
    log(`FAILED ✗ job=${job.id.slice(0, 8)}: ${e.message}`);
    try { await api.fail(job.id, e.message); } catch (e2) { log(`fail-report bhi fail: ${e2.message}`); }
  }
  return true;
}

async function main() {
  if (!cfg.agentToken || cfg.agentToken === "PASTE_TOKEN_FROM_PAIRING") {
    console.error("✗ Agent token config mein nahi hai. Pehle pairing karein: node pair.js");
    process.exit(2);
  }
  log(`Print agent start — server=${cfg.serverUrl} name="${cfg.agentName}" machine=${os.hostname()} mode=${cfg.forceFile ? "PRINT_TO_FILE" : "live"}`);
  await refreshSettings();
  await refreshPrinters();
  log(`discovered printers=${discovered.length}${discovered.length ? ": " + discovered.map((p) => p.name).join(" | ") : ""}`);
  try {
    const hb = await api.heartbeat(discovered);
    log(`heartbeat ✓ agent=${hb.agent.displayName} assignedPrinters=${hb.printers.length}`);
    for (const p of hb.printers) log(`  printer: ${p.role} "${p.displayName}" ${p.connectionType} ${p.address ?? ""} ${p.commandLanguage ?? ""}`);
  } catch (e) {
    log(`heartbeat ✗ ${e.message} (server chal raha hai? token theek hai?) — polling phir bhi try hogi`);
  }
  const hbTimer = setInterval(async () => {
    await refreshPrinters();
    api.heartbeat(discovered).catch((e) => log(`heartbeat ✗ ${e.message}`));
    refreshSettings();
  }, cfg.heartbeatIntervalMs);

  let backoff = cfg.pollIntervalMs;
  let stopping = false;
  const stop = () => { stopping = true; };
  process.on("SIGINT", stop);
  process.on("SIGTERM", stop);

  while (!stopping) {
    try {
      const did = await processOne();
      backoff = cfg.pollIntervalMs;
      if (once) break;
      if (!did) await sleep(cfg.pollIntervalMs);
    } catch (e) {
      // claim hi fail (server down / network) — backoff ke saath retry
      log(`poll ✗ ${e.message} — ${Math.round(backoff / 1000)}s baad retry`);
      if (once) { clearInterval(hbTimer); throw e; }
      await sleep(backoff);
      backoff = Math.min(backoff * 2, 30000);
    }
  }
  clearInterval(hbTimer);
  log("Print agent band ho raha hai. Allah Hafiz.");
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

main().catch((e) => {
  console.error("✗ Agent ruk gaya:", e.message);
  process.exit(1);
});
