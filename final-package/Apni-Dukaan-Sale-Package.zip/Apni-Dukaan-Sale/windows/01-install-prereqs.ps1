# =====================================================================
#  Canteen POS - Phase 2 - Script 01: Install Prerequisites (Windows)
#  Node.js LTS + PostgreSQL install/check karta hai.
#  Admin PowerShell mein chalain. Re-run karna safe hai (idempotent).
#
#  ROUND 5 (18-Nov-2026) - asal NAYE PC ke Step-1 fail se seekha:
#  - Purana Node (v20.3.0) "pehle se hai" keh kar accept ho jata
#    tha. Ab VERSION FLOOR hai: Node v22 se purana ho to upgrade
#    lazmi hai (app Next.js 16 hai - use naya Node chahiye).
#  - PostgreSQL ke download ke kai tareeqay hain - winget,
#    GitHub mirror se binaries, EDB installer seedha, aur
#    EDB binaries zip (tartib Install-PostgreSQL mein hai).
#  - Database ka superuser password operator se KABHI nahi manga
#    jata aur yaad bhi nahi rakhna: script khud mazboot password
#    banata hai, unattended install mein wohi lagta hai, aur
#    step 2 ke liye woh password C:\CanteenPOS\pg-superuser.tmp
#    mein mehfooz hand-off hota hai (02 use parh kar file delete
#    kar deta hai; file na mile to 02 ki pg_hba trust-recovery
#    apna kaam karti hai - wohi purana fallback).
#  ROUND 6 (19-Nov-2026) - FIXED-9 ke asal naye-PC test se:
#  - EDB ka server (get.enterprisedb.com) is PC ke network ko
#    bilkul hi 403 deta hai - browser wali pehchan (User-Agent)
#    se bhi nahi mana. Is liye naya PEHLA download source
#    GitHub par PostgreSQL ke official binaries ka mirror hai
#    (theseus-rs/postgresql-binaries, version 17.12.0 mehfooz
#    pin ki hui, SHA-256 pehchan ke sath).
#  - Cluster Program Files ke andar banane par initdb
#    "Permission denied" se fail hua tha. Ab khud-banayi
#    service wale tareeqay mein cluster C:\CanteenPOS\
#    pgdata-initial mein banta hai (permissions script khud
#    set karta hai); binaries Program Files mein hi rehte
#    hain taake step 2 ko wohi purani jagah sab mile. Step 2
#    baad mein service ko asal drive par le jata hai.
#  - HARD GATE: pehle sirf psql.exe ka milna "COMPLETE" ke
#    liye kaafi tha - cluster na bana ho to bhi step 1 pass
#    chhap jata tha. Ab COMPLETE tab hi hai jab psql +
#    service + cluster (PG_VERSION) + service Running -
#    chaaron asal mein check ho jayen.
#  - Node upgrade ke baad is session mein purana npm (9.8.1)
#    aa raha tha. Ab node ke apne folder se npm liya jata
#    hai aur wohi folder session ke PATH mein sab se pehle
#    rakha jata hai.
#  NOTE: GitHub-mirror wale tareeqay ka pehla asal-PC test
#  agle install par hoga - fail ho to install-log.txt ki
#  tafseel bhejein.
#  ROUND 7 (19-Nov-2026) - FIXED-10 ke asal test se:
#  - FIXED-9 ki adhoori koshish ki bachi hui program files
#    (sirf binaries - na service, na cluster) dekh kar
#    step 1 install SKIP kar deta tha, phir naya hard gate
#    use wahin rok deta tha. Ab faisla psql ke milne par
#    nahi, ASAL TAYYARI (Test-PgReady) par hota hai:
#    tayyar hai to kuch nahi hota; program files mukammal
#    hain lekin service/cluster adhoora hai to REPAIR
#    (wohi files se cluster + service + naya master
#    password + hand-off file); warna ROUND 6 wala purana
#    download silsila. Gate waisa hi sakht hai.
# =====================================================================

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$failed = $false

$script:NodeFloor = [version]'22.0.0'
$script:BrowserUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
$script:PgVersions = @(
    [pscustomobject]@{ Major = 17; Ver = '17.12-1' },
    [pscustomobject]@{ Major = 16; Ver = '16.16-1' }
)
# ROUND 6: GitHub par PostgreSQL ke official binaries ka mirror
# (theseus-rs/postgresql-binaries) - EDB ka server jin networks
# ko 403 deta hai wahan ye kaam ayega. Version + SHA-256 pehchan
# yahan mehfooz hai (18-Nov-2026 ko tasdeeq ki gayi: file
# 49,403,508 bytes, SHA-256 neeche wali).
$script:PgMirror = [pscustomobject]@{
    Major   = 17
    Ver     = '17.12.0'
    ZipName = 'postgresql-17.12.0-x86_64-pc-windows-msvc.zip'
    Url     = 'https://github.com/theseus-rs/postgresql-binaries/releases/download/17.12.0/postgresql-17.12.0-x86_64-pc-windows-msvc.zip'
    Sha256  = 'e45909100dd4d7309981054d5625e70612150999d106741d1c01a5443be918bf'
}
# Khud-banayi service wale tareeqay mein pehla cluster is jagah
# banta hai (Program Files ke andar KABHI nahi). Step 2 baad
# mein service ko apni chuni hui drive par le jata hai.
$script:InitialDataDir = 'C:\CanteenPOS\pgdata-initial'
$script:HandoffDir  = 'C:\CanteenPOS'
$script:HandoffFile = 'C:\CanteenPOS\pg-superuser.tmp'
$script:PgHandoffPassword = $null

function Test-IsAdmin {
    $identity  = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Refresh-Path {
    $machine = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $user    = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = "$machine;$user"
}

function Find-Psql {
    $base = 'C:\Program Files\PostgreSQL'
    if (Test-Path $base) {
        $dirs = Get-ChildItem $base -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending
        foreach ($d in $dirs) {
            $candidate = Join-Path $d.FullName 'bin\psql.exe'
            if (Test-Path $candidate) { return $candidate }
        }
    }
    $cmd = Get-Command psql.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

function Sync-NodePath {
    # Registry wala PATH dobara parh kar node ke apne folder ko
    # is session ke PATH mein sab se pehle rakhein - warna
    # purani install ka npm beech mein aa jata hai (asal PC par
    # node v26 ke sath purana npm 9.8.1 aa raha tha).
    Refresh-Path
    $cmd = Get-Command node.exe -ErrorAction SilentlyContinue
    if ($cmd) {
        $dir = Split-Path $cmd.Source -Parent
        $env:Path = "$dir;$env:Path"
    }
}

function Get-PgServiceDataDir {
    param([string]$PathName)
    # Service ki command line mein -D ke baad wala data folder.
    if (-not $PathName) { return $null }
    if ($PathName -match '-D\s+"([^"]+)"') { return $Matches[1] }
    if ($PathName -match '-D\s+(\S+)') { return $Matches[1] }
    return $null
}

function Test-PgReady {
    param([switch]$Quiet, [switch]$AllowStopped)
    # HARD GATE (ROUND 6): Step 1 tab hi COMPLETE hai jab ye
    # cheezein asal mein mojood hon - (1) psql program, (2)
    # postgresql service registered, (3) service jis cluster
    # ki taraf ishara karti hai wahan PG_VERSION file, (4)
    # service chal rahi ho. Pehle sirf psql ka hona kaafi
    # samjha jata tha - cluster na bana ho to bhi COMPLETE
    # chhap jata tha aur step 2 beech mein ruk jata tha.
    # ROUND 7: -Quiet par ye sirf khamosh faisla deta hai
    # (screen par kuch nahi chhapta) - main flow is se pehle
    # hi tay karta hai ke repair/download chahiye ya nahi.
    # -AllowStopped par dhacha pura ho lekin service band
    # ho to bhi tayyar mana jata hai - band service ko main
    # flow khud start kar deta hai, us par repair ya
    # download chalana ghalat hoga.
    $psql = Find-Psql
    if (-not $psql) { if (-not $Quiet) { Write-Host 'GATE: psql.exe nahi mila.' -ForegroundColor Yellow }; return $false }
    $svc = Get-Service -Name 'postgresql-x64-*' -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $svc) {
        $svc = Get-Service -Name 'postgresql*' -ErrorAction SilentlyContinue | Select-Object -First 1
    }
    if (-not $svc) { if (-not $Quiet) { Write-Host 'GATE: PostgreSQL service registered nahi hai.' -ForegroundColor Yellow }; return $false }
    $dataDir = $null
    try {
        $cim = Get-CimInstance Win32_Service -Filter ("Name = '{0}'" -f $svc.Name) -ErrorAction Stop
        $dataDir = Get-PgServiceDataDir $cim.PathName
    } catch { }
    $candidates = @()
    if ($dataDir) { $candidates += $dataDir }
    $candidates += $script:InitialDataDir
    $pfBase = 'C:\Program Files\PostgreSQL'
    if (Test-Path $pfBase) {
        Get-ChildItem $pfBase -Directory -ErrorAction SilentlyContinue | ForEach-Object { $candidates += (Join-Path $_.FullName 'data') }
    }
    $clusterOk = $false
    foreach ($c in $candidates) {
        if ($c -and (Test-Path (Join-Path $c 'PG_VERSION'))) { $clusterOk = $true; $dataDir = $c; break }
    }
    if (-not $clusterOk) { if (-not $Quiet) { Write-Host 'GATE: database cluster (PG_VERSION wali jagah) nahi mila.' -ForegroundColor Yellow }; return $false }
    $svcNow = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
    if (-not $svcNow -or ($svcNow.Status -ne 'Running')) {
        if ($AllowStopped -and $svcNow) {
            # Dhacha pura hai, sirf service band hai - main
            # flow use start kar dega, repair ki zaroorat nahi.
            return $true
        }
        $haal = if ($svcNow) { $svcNow.Status } else { 'nahi mili' }
        if (-not $Quiet) { Write-Host ("GATE: PostgreSQL service chal nahi rahi (haal: {0})." -f $haal) -ForegroundColor Yellow }
        return $false
    }
    if (-not $Quiet) { Write-Host ("PostgreSQL bilkul tayyar hai: service {0}, cluster {1}" -f $svc.Name, $dataDir) -ForegroundColor Green }
    return $true
}

function Get-NodeVersion {
    $cmd = Get-Command node.exe -ErrorAction SilentlyContinue
    if (-not $cmd) { return $null }
    $prevEAP = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $raw = & node --version 2>$null
    $ErrorActionPreference = $prevEAP
    if (-not $raw) { return $null }
    $txt = "$raw".Trim().TrimStart('v')
    try { return [version]$txt } catch { return $null }
}

function New-SafePassword {
    # Sirf letters + digits - command line, config file, har jagah
    # baghair quoting ke jhanjhat ke chal jata hai.
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789'
    $bytes = New-Object byte[] 28
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    $sb = New-Object System.Text.StringBuilder
    foreach ($b in $bytes) { [void]$sb.Append($alphabet[$b % $alphabet.Length]) }
    return $sb.ToString()
}

function Invoke-Download {
    param([string]$Url, [string]$Dest, [long]$MinBytes = 1048576)
    # Browser wali pehchan (User-Agent) ke sath download - kuch
    # servers (EDB waghera) aam download programs ko 403 de dete
    # hain, browser wali pehchan par file de dete hain.
    for ($try = 1; $try -le 3; $try++) {
        try {
            Write-Host ("Download ho raha hai (koshish {0}/3)..." -f $try)
            Invoke-WebRequest -Uri $Url -OutFile $Dest -UseBasicParsing -UserAgent $script:BrowserUA -TimeoutSec 1200
            if ((Test-Path $Dest) -and ((Get-Item $Dest).Length -ge $MinBytes)) { return $true }
            Write-Host 'Download adhoora lag raha hai - dobara koshish hogi.' -ForegroundColor Yellow
        } catch {
            Write-Host ("Download fail hua: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
        }
        Start-Sleep -Seconds 5
    }
    return $false
}

function Save-PgHandoff {
    # Step 1 ne PostgreSQL khud lagaya ho to us ka banaya hua
    # master password step 2 ke liye ek mehfooz file mein chhor
    # dein - 02 use parh kar file delete kar dega. File ki
    # permissions .env ki tarah band kar di jati hain.
    if (-not $script:PgHandoffPassword) { return }
    try {
        if (-not (Test-Path $script:HandoffDir)) { New-Item -ItemType Directory -Path $script:HandoffDir -Force | Out-Null }
        [IO.File]::WriteAllText($script:HandoffFile, $script:PgHandoffPassword)
        $me = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        & icacls $script:HandoffFile /inheritance:r /grant:r 'SYSTEM:F' 'Administrators:F' ("{0}:F" -f $me) | Out-Null
        Write-Host 'Database ka master password step 2 ke liye mehfooz kar diya hai - kisi ko yaad nahi rakhna.'
    } catch {
        Write-Host 'Note: master password ki hand-off file nahi bani - step 2 apna purana tareeqa (recovery) khud istemal kar lega.' -ForegroundColor Yellow
    }
}

function Install-NodeLts {
    # Plan A: winget. Na chale to Plan B: nodejs.org se official MSI.
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        $hadNode = [bool](Get-Command node.exe -ErrorAction SilentlyContinue)
        if ($hadNode) {
            Write-Host 'Node.js upgrade ho raha hai (winget)...' -ForegroundColor Yellow
            & winget upgrade --id OpenJS.NodeJS.LTS -e --accept-source-agreements --accept-package-agreements
            Refresh-Path
            $v = Get-NodeVersion
            if ($v -and ($v -ge $script:NodeFloor)) { return $true }
            Write-Host 'winget upgrade se kaam nahi bana - install wala tareeqa try ho raha hai...' -ForegroundColor Yellow
            & winget install --id OpenJS.NodeJS.LTS -e --force --accept-source-agreements --accept-package-agreements
        } else {
            Write-Host 'Node.js install ho raha hai (winget, LTS)...' -ForegroundColor Yellow
            & winget install --id OpenJS.NodeJS.LTS -e --accept-source-agreements --accept-package-agreements
        }
        Refresh-Path
        $v = Get-NodeVersion
        if ($v -and ($v -ge $script:NodeFloor)) { return $true }
        Write-Host 'winget wala tareeqa nahi chala - ab seedha nodejs.org se download hoga.' -ForegroundColor Yellow
    } else {
        Write-Host 'winget nahi mila - Node.js seedha nodejs.org se download hoga.' -ForegroundColor Yellow
    }

    # --- Plan B: nodejs.org se official MSI -------------------------
    $ver = $null
    try {
        $idxRaw = (Invoke-WebRequest -Uri 'https://nodejs.org/dist/index.json' -UseBasicParsing -UserAgent $script:BrowserUA -TimeoutSec 60).Content
        $idx = $idxRaw | ConvertFrom-Json
        $lts = $idx | Where-Object { $_.lts } | Select-Object -First 1
        if ($lts) { $ver = [string]$lts.version }
    } catch {
        Write-Host 'Node ki latest LTS list nahi mili - ek mehfooz LTS version istemal hoga.' -ForegroundColor Yellow
    }
    if (-not $ver) { $ver = 'v24.11.0' }
    $msiName = "node-$ver-x64.msi"
    $msiPath = Join-Path $env:TEMP $msiName
    $msiUrl  = "https://nodejs.org/dist/$ver/$msiName"
    Write-Host ("Node.js {0} download ho raha hai..." -f $ver) -ForegroundColor Yellow
    if (Invoke-Download $msiUrl $msiPath 10485760) {
        $proc = Start-Process msiexec.exe -ArgumentList "/i `"$msiPath`" /qn /norestart" -Wait -PassThru
        Refresh-Path
        $v = Get-NodeVersion
        if ($v -and ($v -ge $script:NodeFloor)) { return $true }
        Write-Host ("Node MSI ka exit code: {0}" -f $proc.ExitCode) -ForegroundColor Yellow
    }
    return $false
}

function Install-PgBinariesTree {
    param([string]$SrcRoot, [int]$Major, [switch]$FreshCluster)
    # Download ki hui program files (binaries) ko asal jagah
    # rakh kar, cluster bana kar, service register karna.
    # Binaries C:\Program Files\PostgreSQL\<major> mein hi
    # rehte hain taake step 2 ko wohi purani jagah psql mile.
    # Cluster Program Files ke andar KABHI nahi banta - wahan
    # ki permissions ki wajah se initdb "Permission denied"
    # par fail hota hai (18-Nov-2026 ko asal PC par yehi hua
    # tha). Cluster hamari apni jagah C:\CanteenPOS\
    # pgdata-initial mein banta hai; step 2 baad mein service
    # ko asal drive par le jata hai (us ka purana tareeqa).
    $target  = "C:\Program Files\PostgreSQL\$Major"
    $binDir  = Join-Path $target 'bin'
    $dataDir = $script:InitialDataDir
    if (-not (Test-Path $target)) { New-Item -ItemType Directory -Path $target -Force | Out-Null }
    # Repair wale rastay (ROUND 7) mein program files pehle
    # se asal jagah par hi hoti hain - wahan copy ka sawal
    # hi nahi, aur robocopy ko ek hi jagah do dafa dena
    # bhi theek nahi.
    $srcFull = [IO.Path]::GetFullPath($SrcRoot).TrimEnd('\')
    $tgtFull = [IO.Path]::GetFullPath($target).TrimEnd('\')
    if ($srcFull -ine $tgtFull) {
        & robocopy $SrcRoot $target /E /NFL /NDL /NJH /NJS | Out-Null
        if ($LASTEXITCODE -ge 8) { Write-Host 'Program files copy nahi hui.' -ForegroundColor Yellow; return $false }
    }
    if (-not (Test-Path (Join-Path $binDir 'postgres.exe'))) {
        Write-Host 'Program files copy ke baad bhi postgres.exe nahi mila.' -ForegroundColor Yellow
        return $false
    }
    if ($FreshCluster -or (-not (Test-Path (Join-Path $dataDir 'PG_VERSION')))) {
        if (Test-Path $dataDir) {
            # Aadha bana hua purana cluster ho to saaf kar
            # dein - ye sirf hamari initial wali jagah hai,
            # asal data step 2 apni drive par banata hai.
            # Repair (ROUND 7) mein -FreshCluster ke sath ye
            # har dafa saaf hota hai taake naya master
            # password asal cluster se lazmi mile.
            Remove-Item $dataDir -Recurse -Force -ErrorAction SilentlyContinue
        }
        New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
        # Permissions pehle se khud set karte hain: service
        # wala account (NetworkService), SYSTEM, aur ye
        # chalane wala user - teeno ko poora haq.
        $me = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        & icacls $dataDir /grant:r 'NT AUTHORITY\NetworkService:(OI)(CI)F' 'SYSTEM:(OI)(CI)F' ("{0}:(OI)(CI)F" -f $me) | Out-Null
        $pwFile = Join-Path $env:TEMP ("pgpw-{0}.txt" -f [guid]::NewGuid().ToString('N'))
        try {
            [IO.File]::WriteAllText($pwFile, $script:PgHandoffPassword)
            & (Join-Path $binDir 'initdb.exe') -D $dataDir -U postgres "--pwfile=$pwFile" --auth=scram-sha-256 -E UTF8
            if ($LASTEXITCODE -ne 0) { Write-Host 'Database cluster (initdb) nahi bana.' -ForegroundColor Yellow; return $false }
        } finally {
            Remove-Item $pwFile -Force -ErrorAction SilentlyContinue
        }
        # initdb apni marzi ke permissions bhi lagata hai -
        # service wale account ko dobara poora haq dein warna
        # service start nahi hogi:
        & icacls $dataDir /grant 'NT AUTHORITY\NetworkService:(OI)(CI)F' /T /Q | Out-Null
    }
    $svcName = "postgresql-x64-$Major"
    if (-not (Get-Service -Name $svcName -ErrorAction SilentlyContinue)) {
        & (Join-Path $binDir 'pg_ctl.exe') register -N $svcName -D $dataDir -U 'NT AUTHORITY\NetworkService' -S auto
        if ($LASTEXITCODE -ne 0) { Write-Host 'PostgreSQL service register nahi hui.' -ForegroundColor Yellow; return $false }
    }
    Write-Host ("PostgreSQL {0} program files se tayyar ho gaya (service: {1})." -f $Major, $svcName) -ForegroundColor Green
    return [bool](Find-Psql)
}

function Find-PgBinariesMajor {
    # Program Files mein kisi version ki MUKAMMAL program
    # files mojood hain? (psql + initdb + pg_ctl + postgres
    # - chaaron) Hon to download ki zaroorat nahi, sirf
    # service/cluster ki repair chahiye (ROUND 7).
    $base = 'C:\Program Files\PostgreSQL'
    if (-not (Test-Path $base)) { return $null }
    $dirs = Get-ChildItem $base -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending
    foreach ($d in $dirs) {
        if ($d.Name -notmatch '^\d+$') { continue }
        $bin = Join-Path $d.FullName 'bin'
        if ((Test-Path (Join-Path $bin 'psql.exe')) -and
            (Test-Path (Join-Path $bin 'initdb.exe')) -and
            (Test-Path (Join-Path $bin 'pg_ctl.exe')) -and
            (Test-Path (Join-Path $bin 'postgres.exe'))) {
            return [int]$d.Name
        }
    }
    return $null
}

function Repair-PostgreSQL {
    param([int]$Major)
    # ROUND 7: program files pehle se hain lekin service ya
    # cluster adhoora hai - masalan pichli adhoori koshish
    # (FIXED-9) ki bachi hui EDB files, jinhen dekh kar sirf
    # psql wali purani soch install skip kar deti thi aur
    # gate step 1 ko rok deta tha. Download dobara nahi
    # hoga: wohi files se cluster + service bana kar, naya
    # master password laga kar, hand-off file step 2 ke
    # liye chhor dete hain - bilkul nayi khud-banayi
    # install ki tarah (02 wohi hand-off parhta hai, aur
    # us ki pg_hba recovery har surat mein maujood hai).
    Write-Host ("PostgreSQL ki program files pehle se hain (v{0}) lekin service nahi bani thi - repair ho raha hai..." -f $Major) -ForegroundColor Yellow
    $script:PgHandoffPassword = New-SafePassword
    $target  = "C:\Program Files\PostgreSQL\$Major"
    $binDir  = Join-Path $target 'bin'
    $svcName = "postgresql-x64-$Major"
    # Isi naam ki purani service agar aisi jagah ki taraf
    # ishara karti hai jahan cluster hi nahi, to use pehle
    # hata dein - warna nayi registration nahi banegi.
    $old = Get-Service -Name $svcName -ErrorAction SilentlyContinue
    if ($old) {
        $oldDir = $null
        try {
            $cim = Get-CimInstance Win32_Service -Filter ("Name = '{0}'" -f $svcName) -ErrorAction Stop
            $oldDir = Get-PgServiceDataDir $cim.PathName
        } catch { }
        if (-not ($oldDir -and (Test-Path (Join-Path $oldDir 'PG_VERSION')))) {
            if ($old.Status -eq 'Running') { Stop-Service -Name $svcName -Force -ErrorAction SilentlyContinue }
            & (Join-Path $binDir 'pg_ctl.exe') unregister -N $svcName
            if (Get-Service -Name $svcName -ErrorAction SilentlyContinue) {
                & sc.exe delete $svcName | Out-Null
            }
            Write-Host ("Purani adhoori service ({0}) hata di." -f $svcName)
        }
    }
    if (-not (Install-PgBinariesTree $target $Major -FreshCluster)) { return $false }
    Save-PgHandoff
    return $true
}

function Install-PgFromGitHubMirror {
    # Plan B (ROUND 6): EDB ka server kuch networks ko bilkul
    # hi 403 de deta hai - wahan se koi download nahi hota.
    # GitHub par PostgreSQL ke official binaries ka mehfooz
    # mirror hai (theseus-rs/postgresql-binaries) - wohi
    # files, sirf jagah doosri. Version aur file ki pehchan
    # (SHA-256) script mein mehfooz likhi hai; download ke
    # baad pehchan mila kar dekhi jati hai, na mile to file
    # istemal hi nahi hoti.
    $m = $script:PgMirror
    Write-Host ("PostgreSQL {0} GitHub wale mehfooz source se download ho raha hai..." -f $m.Ver) -ForegroundColor Yellow
    $zipPath = Join-Path $env:TEMP $m.ZipName
    if (-not (Invoke-Download $m.Url $zipPath 41943040)) { return $false }
    try {
        $hash = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash
        if ($hash -ine $m.Sha256) {
            Write-Host 'Download ki hui file ki pehchan (SHA-256) nahi mili - file mehfooz nahi, aage nahi barhenge.' -ForegroundColor Yellow
            return $false
        }
        Write-Host 'File ki pehchan (SHA-256) mil gayi - file asal hai.'
    } catch {
        Write-Host ("Pehchan check nahi ho saki: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
        return $false
    }
    $extractDir = Join-Path $env:TEMP ("pggh-{0}" -f $m.Major)
    if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force -ErrorAction SilentlyContinue }
    try {
        Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force
    } catch {
        Write-Host ("Zip kholna fail hua: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
        return $false
    }
    $srcRoot = $null
    $hit = Get-ChildItem $extractDir -Recurse -Filter 'postgres.exe' -ErrorAction SilentlyContinue | Where-Object { $_.Directory.Name -eq 'bin' } | Select-Object -First 1
    if ($hit) { $srcRoot = Split-Path $hit.Directory.FullName -Parent }
    if (-not $srcRoot) {
        Write-Host 'Zip ke andar PostgreSQL ki files nahi mili.' -ForegroundColor Yellow
        return $false
    }
    return Install-PgBinariesTree $srcRoot $m.Major
}

function Install-PgFromBinaries {
    param($Pg)
    # Plan D: EDB ki sirf-program-files wali zip (aakhri
    # tareeqa). Files rakhna / cluster / service ka kaam
    # Install-PgBinariesTree karta hai - cluster wahan bhi
    # C:\CanteenPOS\pgdata-initial mein hi banta hai.
    $major = $Pg.Major
    Write-Host ("Aakhri tareeqa: PostgreSQL {0} ki program files (EDB zip) seedha rakh kar service banayi jayegi..." -f $major) -ForegroundColor Yellow
    $zipName = "postgresql-$($Pg.Ver)-windows-x64-binaries.zip"
    $zipPath = Join-Path $env:TEMP $zipName
    if (-not (Invoke-Download "https://get.enterprisedb.com/postgresql/$zipName" $zipPath 10485760)) { return $false }
    $extractDir = Join-Path $env:TEMP ("pgbin-{0}" -f $major)
    if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force -ErrorAction SilentlyContinue }
    try {
        Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force
    } catch {
        Write-Host ("Zip kholna fail hua: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
        return $false
    }
    $srcRoot = Join-Path $extractDir 'pgsql'
    if (-not (Test-Path (Join-Path $srcRoot 'bin\postgres.exe'))) { $srcRoot = $extractDir }
    if (-not (Test-Path (Join-Path $srcRoot 'bin\postgres.exe'))) {
        Write-Host 'Zip ke andar PostgreSQL ki files nahi mili.' -ForegroundColor Yellow
        return $false
    }
    return Install-PgBinariesTree $srcRoot $major
}

function Install-PostgreSQL {
    # Password script KHUD banata hai - operator se kabhi nahi
    # manga jata, aur use yaad bhi nahi rakhna.
    $script:PgHandoffPassword = New-SafePassword
    $pw = $script:PgHandoffPassword

    # --- Plan A: winget (17, phir 16) -------------------------------
    # --override se installer ko unattended switches bhej dete
    # hain taake password wali window hi na aye aur wohi password
    # lage jo script ne banaya hai.
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        foreach ($pkg in @('PostgreSQL.PostgreSQL.17', 'PostgreSQL.PostgreSQL.16')) {
            Write-Host ("Try: winget package {0}" -f $pkg)
            & winget install --id $pkg -e --accept-source-agreements --accept-package-agreements --override "--mode unattended --unattendedmodeui none --serverport 5432 --superpassword $pw"
            Refresh-Path
            if (Find-Psql) { Save-PgHandoff; return $true }
        }
        Write-Host 'winget wala tareeqa nahi chala - ab seedha download wala tareeqa chalega.' -ForegroundColor Yellow
    } else {
        Write-Host 'winget nahi mila - PostgreSQL seedha download hoga.' -ForegroundColor Yellow
    }

    # --- Plan B: GitHub mirror se binaries (ROUND 6) ----------------
    # EDB ka server is network ko 403 deta hai to ye pehla
    # download wala tareeqa hai - GitHub se wohi official
    # binaries milte hain, pehchan (SHA-256) bhi check hoti hai.
    if (Install-PgFromGitHubMirror) { Save-PgHandoff; return $true }
    Write-Host 'GitHub wala tareeqa bhi nahi chala - ab EDB ka installer seedha try hoga.' -ForegroundColor Yellow

    # --- Plan C: EDB installer seedha download + unattended ---------
    foreach ($pg in $script:PgVersions) {
        $exeName = "postgresql-$($pg.Ver)-windows-x64.exe"
        $exePath = Join-Path $env:TEMP $exeName
        Write-Host ("PostgreSQL {0} ka installer download ho raha hai..." -f $pg.Major) -ForegroundColor Yellow
        if (Invoke-Download "https://get.enterprisedb.com/postgresql/$exeName" $exePath 52428800) {
            Write-Host 'Installer chal raha hai (khamoshi se - koi window nahi ayegi)...'
            $proc = Start-Process $exePath -ArgumentList @('--mode', 'unattended', '--unattendedmodeui', 'none', '--serverport', '5432', '--superpassword', $pw) -Wait -PassThru
            Refresh-Path
            if (Find-Psql) { Save-PgHandoff; return $true }
            Write-Host ("Installer ka exit code: {0} - aage wala tareeqa try hoga." -f $proc.ExitCode) -ForegroundColor Yellow
        }
    }

    # --- Plan D: EDB binaries zip (aakhri tareeqa) ------------------
    foreach ($pg in $script:PgVersions) {
        if (Install-PgFromBinaries $pg) { Save-PgHandoff; return $true }
    }
    return $false
}

# --- Khud ko Admin bana kar dobara chalana (agar admin nahi) ----------
if (-not (Test-IsAdmin)) {
    Write-Host 'Admin rights chahiye - UAC prompt par Yes dabain...' -ForegroundColor Yellow
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

try {
    Write-Host ''
    Write-Host '===================================================' -ForegroundColor Cyan
    Write-Host ' STEP 1/3 - Node.js + PostgreSQL install / check' -ForegroundColor Cyan
    Write-Host '===================================================' -ForegroundColor Cyan

    # --- Windows version check ---------------------------------------
    $os = Get-CimInstance Win32_OperatingSystem
    Write-Host ("Windows: {0} (Build {1})" -f $os.Caption, $os.BuildNumber)
    if ([int]$os.BuildNumber -ge 22000) {
        Write-Host 'Windows 11 detected - perfect, yehi side use karni hai.' -ForegroundColor Green
    } elseif ([int]$os.BuildNumber -ge 10240) {
        Write-Host 'Windows 10 detected - chalega, lekin Windows 11 wali side zyada behtar hai (10 ki support khatam ho chuki hai).' -ForegroundColor Yellow
    } else {
        throw 'Ye Windows bohat purana hai - Windows 10/11 chahiye.'
    }

    # --- Node.js (version floor ke sath) -------------------------------
    Refresh-Path
    $nodeVer = Get-NodeVersion
    if ($nodeVer -and ($nodeVer -ge $script:NodeFloor)) {
        Write-Host ("Node.js pehle se hai: v{0}" -f $nodeVer) -ForegroundColor Green
    } else {
        if ($nodeVer) {
            Write-Host ("Node.js purana hai (v{0}) - is system ke liye v22 ya naya chahiye. Naya LTS lag raha hai..." -f $nodeVer) -ForegroundColor Yellow
        } else {
            Write-Host 'Node.js nahi mila - LTS version lag raha hai...' -ForegroundColor Yellow
        }
        if (-not (Install-NodeLts)) {
            throw 'Node.js install/upgrade nahi hua - internet check karke script dobara chalain, ya https://nodejs.org se LTS haath se install karke dobara chalain.'
        }
        $nodeVer = Get-NodeVersion
        Write-Host ("Node.js tayyar hai: v{0}" -f $nodeVer) -ForegroundColor Green
    }

    # Node aur npm ek hi install se ayen - session PATH durust karein:
    Sync-NodePath

    # --- PostgreSQL ----------------------------------------------------
    # ROUND 7: faisla psql ke milne par nahi, ASAL TAYYARI
    # par hota hai (psql + service + cluster - Test-PgReady).
    # Sirf program files ka hona kaafi nahi: pichli adhoori
    # koshish ki bachi hui files par install skip ho jata
    # tha aur phir gate step 1 ko rok deta tha.
    if (Test-PgReady -Quiet -AllowStopped) {
        $psql = Find-Psql
        Write-Host ("PostgreSQL pehle se hai: {0}" -f $psql) -ForegroundColor Green
    } else {
        $repairMajor = Find-PgBinariesMajor
        if ($repairMajor) {
            # Program files mukammal hain - download ki
            # zaroorat nahi, sirf service/cluster ki repair.
            if (-not (Repair-PostgreSQL $repairMajor)) {
                throw 'PostgreSQL ki repair nahi ho saki - internet check karke script dobara chalain. Phir bhi na ho to install-log.txt ki tafseel bhejein.'
            }
            $psql = Find-Psql
            Write-Host ("PostgreSQL repair ho gaya: {0}" -f $psql) -ForegroundColor Green
        } else {
            Write-Host ''
            Write-Host 'PostgreSQL install ho raha hai - ye khud bakhud hoga, aap ko koi password nahi likhna (system khud bana leta hai).' -ForegroundColor Yellow
            if (-not (Install-PostgreSQL)) {
                throw 'PostgreSQL install nahi hua - internet check karke script dobara chalain. Phir bhi na ho to https://www.postgresql.org/download/windows/ se haath se install karein (port 5432 default rakhein), phir ye script dobara chalain.'
            }
            $psql = Find-Psql
            Write-Host ("PostgreSQL install ho gaya: {0}" -f $psql) -ForegroundColor Green
        }
    }

    # --- PostgreSQL service: Automatic + Running -----------------------
    $svc = Get-Service -Name 'postgresql*' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($svc) {
        if ($svc.StartType -ne 'Automatic') {
            Set-Service -Name $svc.Name -StartupType Automatic
            Write-Host ("Service {0} ko Automatic kar diya." -f $svc.Name)
        }
        if ($svc.Status -ne 'Running') {
            try {
                Start-Service -Name $svc.Name -ErrorAction Stop
                (Get-Service -Name $svc.Name).WaitForStatus([System.ServiceProcess.ServiceControllerStatus]::Running, [TimeSpan]::FromSeconds(30))
                Write-Host ("Service {0} start kar diya." -f $svc.Name) -ForegroundColor Green
            } catch {
                Write-Host ("Service {0} start nahi hui: {1}" -f $svc.Name, $_.Exception.Message) -ForegroundColor Yellow
            }
        } else {
            Write-Host ("PostgreSQL service chal raha hai: {0}" -f $svc.Name) -ForegroundColor Green
        }
    } else {
        Write-Host 'PostgreSQL service nahi mila.' -ForegroundColor Yellow
    }

    # --- HARD GATE: sab cheezein asal mein check karein ----------------
    # psql + service + cluster (PG_VERSION) + service Running -
    # ek bhi adhoori ho to Step 1 yahin FAIL hoga, taake step 2
    # ko kabhi kharab haalat na mile.
    if (-not (Test-PgReady)) {
        throw 'PostgreSQL tayyar nahi hua (program files, service ya database cluster mein se kuch adhoora hai) - internet check karke script dobara chalain. Phir bhi na ho to install-log.txt ki tafseel bhejein.'
    }

    # --- Versions ki report (node aur npm USI ek install se) -----------
    Write-Host ''
    Write-Host '--- Installed versions ---' -ForegroundColor Cyan
    $nodeExe = (Get-Command node.exe -ErrorAction SilentlyContinue).Source
    if ($nodeExe) {
        $nodeDir = Split-Path $nodeExe -Parent
        Write-Host ("node : {0}  ({1})" -f (& $nodeExe --version), $nodeDir)
        $npmCmd = Join-Path $nodeDir 'npm.cmd'
        if (Test-Path $npmCmd) {
            Write-Host ("npm  : {0}" -f (& $npmCmd --version))
        } else {
            Write-Host ("npm  : {0}" -f (& npm --version))
        }
    }
    if ($psql) { Write-Host ("psql : {0}" -f (& $psql --version)) }

    Write-Host ''
    Write-Host 'STEP 1 COMPLETE. Ab 02-setup-server.ps1 chalain.' -ForegroundColor Green
}
catch {
    $failed = $true
    Write-Host ''
    Write-Host ("ERROR: {0}" -f $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Masla hal karke script dobara chalain - dobara chalana safe hai.'
}
Write-Host ''
if ($env:CANTEENPOS_AUTO -ne '1') { Read-Host 'Band karne ke liye Enter dabain' }
if ($failed) { exit 1 }
