# Apni Dukaan — Windows Server Deployment Runbook

Dukaan ki **Windows 11 PC hi main server** hai (Talha ka faisla, 14 Nov 2026).
PC subah dukaan khulne par ON, raat ko chutti ke baad OFF — bas yehi routine hai.
Saara data (bills, stock, udhaar) isi PC ke database mein rehta hai.

> **Honest note:** Ye pack Linux par baith kar likha gaya hai aur code ko
> static review kiya gaya hai, lekin **Windows par abhi chala kar test nahi
> hua**. Deployment wale din pehli dafa ye scripts sath mila kar chalayenge —
> har script dobara chalana safe hai (idempotent), aur error aye to wahi
> ruk kar wajah batati hai.

---

## System ka naqsha

| Cheez | Detail |
|---|---|
| Server PC | Dukaan ki Windows PC (Windows 11 wali side boot karein) |
| Port | **3100** (har jagah yehi hai) |
| App folder | `C:\CanteenPOS\app` |
| Settings + DB password wali file | `C:\CanteenPOS\app\.env` (share NA karein) |
| Database files | Setup mein operator ki pasand ki jagah (masalan `D:\CanteenPOS-Data`) — asal jagah `.env` ki `PGDATA` line mein likhi hoti hai |
| Backups | Database wali drive par `CanteenPOS-Backups` (`.env` ki `BACKUP_DIR` line) |
| Logs | `C:\CanteenPOS\Logs\server.log` |
| Database | PostgreSQL — database `canteen_pos`, user `canteen_pos_app` (passwords script khud banata hai, `.env` mein rehte hain) |
| Start/Stop (staff) | `C:\CanteenPOS\start-server.bat` / `stop-server.bat` |

Devices (counter PC/tablet, kitchen screen, owner ka phone) browser mein
ye address kholti hain: **`http://<server-pc-ka-IP>:3100`**

---

## Deployment se pehle — Pre-flight checklist

1. **Windows 11 wali side boot karein** (PC mein Windows 10 aur 11 dono
   hain — 11 wali use hogi; Windows 10 ki support khatam ho chuki hai).
2. **Admin account** se login karein (scripts admin mangti hain).
3. PC ko **dukaan ke router** se connect karein (Wi-Fi ya cable; cable
   zyada pakka hai). Windows mein is network ka profile **Private** rakhein
   (Settings → Network & Internet → Properties → Private).
4. **PC ka LAN IP fix karein** — ye sab se ahem step hai. Agar IP roz badle
   ga to counter devices roz confuse hongi. Do tareeqay:
   - **Router mein DHCP reservation (behtareen):** router ke admin page
     (aam tor par `192.168.0.1` ya `192.168.1.1`) → DHCP → is PC ki MAC
     address ke liye ek IP reserve kar dein (masalan `192.168.1.50`).
   - **Ya PC par static IP:** Settings → Network → apna connection →
     IP assignment → Manual → router wale range ka khali IP, gateway =
     router ka IP, DNS = `8.8.8.8`.
   Jo IP fix karein use yahan likh lein: `http://______________:3100`
5. **UPS** laga ho to behtar — bijli jane par database mehfooz rehta hai.
6. Deployment USB/folder mein ye layout ho:
   - `app-source\` — app ki poori project files (**node_modules ke baghair**)
   - `INSTALL.bat` (sab se asaan one-click wala), `01-install-prereqs.ps1`,
     `02-setup-server.ps1`, `03-autostart-and-power.ps1`,
     `04-daily-backup.ps1`, `run-server.ps1`, `start-server.bat`,
     `stop-server.bat`, ye README

---

## Script order — ek ke baad ek

> **Sab se asaan tareeqa (recommended): `INSTALL.bat` par double-click
> karein.** Wo khud admin ki ijazat mangega, database ki jagah ka ek
> sawal (D drive ho to 1 ya 2 dabana hai) poochega, aur teeno scripts
> tarteeb se chala dega. Screen par sirf asaan si batain ayengi —
> saari technical tafseel `windows\install-log.txt` mein jati hai;
> kuch ruk jaye to bas wohi file bhejni hai. Neeche wali tafseel
> sirf us waqt chahiye jab scripts alag alag chalane hon.

Har script par **right-click → Run with PowerShell** (ya admin PowerShell
se chalain). Script khud UAC prompt le ayegi agar admin na ho.

### 1️⃣ `01-install-prereqs.ps1` — Node.js + PostgreSQL
- Windows version check, phir winget se **Node.js LTS** aur **PostgreSQL**
  install (pehle se hon to skip).
- PostgreSQL installer darmiyan mein **superuser (postgres) ka password**
  mangega — **woh password soch kar likhein aur foran Secure Vault mein
  save karein.** Ye pack ke kisi file mein nahi hai, aur bhool jane par
  database ka kaam ruk sakta hai.
- Aakhir mein teeno versions print hongi (node / npm / psql).

### 2️⃣ `02-setup-server.ps1` — App + Database setup
- `C:\CanteenPOS` layout banata hai, `app-source` se app copy karta hai.
- **Database ki jagah operator khud chunta hai** (C: par majboori
  nahi): D drive ho to script sirf ek sawal poochti hai —
  `Database kahan rakhein? [1] D drive (behtar hai)  [2] C drive` —
  aur database `D:\CanteenPOS-Data` ya `C:\CanteenPOS-Data` mein
  banta hai. D drive na ho to C par khud ban jata hai, koi sawal
  nahi. (INSTALL.bat se chalain to ye sawal wahan pehle hi ho jata
  hai.) PostgreSQL ki Windows service usi folder par set ho jati
  hai; jagah `.env` mein `PGDATA` ke naam se likh jati hai aur
  dobara chalane par wohi jagah reuse hoti hai.
- **Database ke passwords koi nahi mangta** — script khud mazboot
  random passwords bana kar sirf `.env` mein rakhti hai
  (`DATABASE_URL`, `PGDATA`, `BACKUP_DIR`, `PG_SUPERUSER_PASSWORD`),
  aur `.env` ki permissions band kar deti hai (sirf SYSTEM /
  Administrators / aap ka account parh sakta hai). Staff PINs hi
  asal lock hain.
- Database `canteen_pos` + user `canteen_pos_app` banata hai.
- `npm install` → `npm run build` → **`npm run db:setup`** (ye app ke
  apne scripts hain: pehle schema/migrate, phir seed — menu, catalogue,
  demo staff PINs waghera database mein chale jate hain).
- Aakhir mein **smoke test**: server chala kar check karta hai ke port
  3100 jawab deta hai ya nahi, phir test server band kar deta hai.
- Dobara chalane par: `.env` mil jaye to wohi password reuse hota hai,
  database dobara nahi banta, seed dobara lagne se data duplicate nahi
  hota (seed idempotent hai).

### 3️⃣ `03-autostart-and-power.ps1` — Auto-start + Power + Firewall
- **Scheduled Task `CanteenPOS Server`** — PC boot hote hi server khud
  start (SYSTEM account, login ka intezar nahi).
- **Scheduled Task `CanteenPOS Daily Backup`** — roz 22:30 backup; PC
  band ho to agle boot par khud chal jata hai.
- **Power:** bijli (AC) par PC **kabhi sleep/hibernate nahi** hoga;
  screen 10 minute mein band ho sakti hai (ye theek hai, server chalta
  rehta hai). Laptop hai to "lid band karne par" wala action bhi
  **Do nothing** kar dein (script screen par yaad dilayegi).
- **Firewall:** port 3100 sirf **local subnet** (dukaan ka LAN) aur
  Private profile ke liye khulta hai — internet se koi andar nahi aa
  sakta is rule se.
- **Desktop shortcut:** sab users ke Desktop par **'Apni Dukaan'**
  ka nishan ban jata hai — double-click se default browser mein
  `http://localhost:3100` khulta hai, address type nahi karna parta.
- **Print Agent auto-start:** agent pehle se paired ho to logon par
  khud start hone ki setting lag jati hai; paired na ho to pairing
  ke waqt `pair.js` khud ye setting laga deta hai.
- Aakhir mein is PC ke LAN addresses print honge — note kar lein.

**Is ke baad zaroor test karein:** PC restart karein → 1–2 minute baad
dusri device se `http://<IP>:3100` kholain → Owner PIN se login karke
dekhein.

---

## Roz ka routine (staff ke liye)

| Waqt | Kya karna hai |
|---|---|
| Subah dukaan khule | Bas **PC ON** kar dein. Server 1–2 minute mein khud start ho jata hai. Kuch chalana nahi. |
| Counter / Kitchen | Apni device ke browser mein `http://<server-IP>:3100` kholain, apna naam + PIN. |
| Raat ko chutti | Bas **PC shutdown** kar dein. `stop-server.bat` roz dabane ki zaroorat NAHI. |
| Server kabhi ruk jaye | `C:\CanteenPOS\start-server.bat` double-click — server start karke is PC + LAN ka address dikha dega. |
| Server haath se band karna ho | `C:\CanteenPOS\stop-server.bat` (yaad rahe: agle boot par khud phir start ho jayega — ye sirf abhi ke liye hai). |

PC band hone par online customers ko kya dikhega? Is ke liye neeche
"Public ordering" wala hissa dekhein — Closed popup wahan se ayega.

---

## Public ordering — Cloudflare Tunnel (deployment ka alag step)

Dukaan ke andar ke devices LAN par chalte hain. **Hostel/ghar se online
order** ke liye server ko ek public address chahiye:

1. PC par **cloudflared** install karein (Cloudflare ka official tool).
2. Ek **Cloudflare Tunnel** banain jo public hostname ko
   `http://localhost:3100` par bhejay. (Domain Talha deployment ke waqt
   final karega.)
3. Tunnel live hote hi `C:\CanteenPOS\app\.env` mein do changes:
   - `COOKIE_SECURE=1` wali line ke aage se `#` hata dein (HTTPS par
     login cookies ke liye zaroori hai).
   - `PUBLIC_ORDER_BASE_URL=https://<aap-ka-public-address>` set karein —
   table-QR cards isi address se bante hain, is ke baad **QR cards
   dobara print** karne honge.
   Phir server restart karein (PC restart ya stop/start .bat).
4. **Closed popup gateway:** jab PC band ho to tunnel wala address khud
   kuch nahi dikha sakta (server hi band hai) — is liye public address
   par ek chhoti si **hamesha-online gateway page** (Cloudflare Pages)
   rahegi jo server ko check karti hai: server ON → customer ordering
   par chala jata hai; server OFF → **"Shop band hai — order ke liye is
   number par rabta karein"** wala popup (number Dashboard ki
   Shop Settings se badla ja sakta hai; app ke andar wala Shop
   Open/Closed switch bhi yehi popup dikhata hai jab dukaan waqt se
   pehle band ho).

> Ye tunnel + gateway wala hissa deployment day par domain final hone
> ke baad configure hoga — pack ke scripts is ke baghair bhi poori
> dukaan (LAN) chala dete hain.

---

## Backups

- Jagah: **database wali drive par `CanteenPOS-Backups`** (masalan
  `D:\CanteenPOS-Backups`) — asal jagah `.env` ki `BACKUP_DIR` line
  mein hai; files `canteen-pos-YYYY-MM-DD_HHMM.dump`.
- Schedule: roz **22:30** (Task Scheduler), PC band ho to agle boot par.
- Sirf **aakhri 14** backups rehte hain; nateeja usi folder ki
  `backup.log` mein.
- App ke andar Dashboard se bhi manual backup ho sakta hai —
  wohi `BACKUP_DIR` use hota hai jo `.env` mein diya hai.
- **Owner ki zimmedari:** haftay mein ek dafa backup folder ki copy
  USB ya apne Google Drive par rakh lein — PC kharab ho to yehi kaam
  ayegi. (Sirf PC ke andar wala backup PC ke sath hi ja sakta hai.)
- **Restore (kabhi zaroorat pari to):** naye PC par scripts 01–02
  chalane ke baad, admin PowerShell mein:
  `pg_restore -U postgres -h 127.0.0.1 -d canteen_pos --clean "<BACKUP_DIR>\<file>.dump"`
  (ye purana data replace karta hai — pehle confirm karke chalain.)

## Database ki jagah baad mein badalna

1. Server band karein aur PostgreSQL service bhi band karein (`services.msc`).
2. Database folder (`.env` ki `PGDATA` wali jagah) **poora copy** karke nayi drive/folder mein rakh dein.
3. `C:\CanteenPOS\app\.env` mein `PGDATA=` ki line nayi jagah se badal dein (chaahein to `BACKUP_DIR=` bhi).
4. `02-setup-server.ps1` dobara chalain — service nayi jagah se jud jayegi, data waisa ka waisa milega; sab theek ho to purana folder delete kar dein.

---

## Troubleshooting

| Masla | Hal |
|---|---|
| Counter device par page nahi khulta | Pehle server PC par `http://localhost:3100` kholain. Wahan khule to masla network ka hai: device usi router par hai? PC ka IP wahi hai jo fix kiya tha? Network profile Private hai? |
| "Port already in use" / server start nahi hota | Purana server pehle se chal raha hoga — `stop-server.bat` chalain, phir `start-server.bat`. Phir bhi na ho to `C:\CanteenPOS\Logs\server.log` ki aakhri lines dekhein. |
| PostgreSQL service band hai | `Win + R` → `services.msc` → **postgresql-x64-…** → Start. (Script 01 use Automatic kar deta hai; band mile to PC par kisi ne roka hoga.) Setup dobara chalana ho to 02 khud service start kar deta hai. |
| PC ka IP badal gaya | Devices purane IP par atki hongi. `start-server.bat` naya address dikha deta hai, lekin asal hal pre-flight wala **IP fix/reservation** hai — wo kar dein to ye masla dobara nahi ayega. |
| Login ke baad foran logout / cookie masla | LAN par (http) normal hai. Agar Tunnel (https) live hai to `.env` mein `COOKIE_SECURE=1` on hona chahiye — change ke baad server restart lazmi hai. |
| `.env` delete ho gaya / password bhool gaya | 02 dobara chalain — wo superuser password se app user ka password **naya set** kar dega aur nayi `.env` bana dega. Naya password foran Secure Vault mein update karein. |
| Backup fail ho raha hai | Backup folder (`.env` ki `BACKUP_DIR` wali jagah) ki `backup.log` dekhein — aam wajah: PostgreSQL service band, ya disk full. |
| Kuch bhi samajh na aye | `Logs\server.log` + `Backups\backup.log` ki aakhri 20–30 lines hi asal kahani batati hain — wahi pehle dekhein. |

---

## Credentials — pakka usool

- Is pack ki **kisi file mein koi asal password nahi hai** aur na hoga.
- Asal system ke database passwords **script 02 khud banati hai** —
  koi type nahi karta, koi yaad nahi rakhta. Woh sirf
  `C:\CanteenPOS\app\.env` mein rehte hain (permissions band hain) —
  `.env` ko WhatsApp/email par kabhi na bhejein.
- Script 01 ke installer mein jo superuser password likha jata hai
  wo sirf installer ke apne default database ke liye hota hai —
  asal system use istemal nahi karta (02 apna alag database apni
  pasand ki jagah banata hai). Phir bhi use kahin likh lein to
  behtar hai.
- Asal lock **staff PINs** hain — wahi sambhal kar rakhein.
- Demo staff PINs (Owner 1234 waghera) seed se ate hain — **go-live
  wale din Dashboard → Staff Access se asal staff aur asal PIN
  bana kar demo PINs badal dein.**

## Deployment day par confirm hone wali cheezein

- winget ke PostgreSQL package ka bartao (installer ka password prompt
  aur service ka naam) — pehli dafa dekh kar confirm hoga.
- Router ka model/IP aur DHCP reservation ka menu — jagah ke hisaab se.
- Domain + Cloudflare Tunnel + gateway page (public ordering ke liye).
- Printer (receipt + label) ke models — print agent un ke hisaab se
  baad mein lagega; LAN server is pack se chal jata hai.
