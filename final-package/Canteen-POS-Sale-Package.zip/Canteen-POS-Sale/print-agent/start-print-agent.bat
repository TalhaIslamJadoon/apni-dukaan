@echo off
REM Canteen POS Print Agent — double-click launcher (server PC).
REM Pehle pairing lazmi hai: node pair.js (README parhein).
cd /d %~dp0
title Canteen POS Print Agent
echo Print agent start ho raha hai... band karne ke liye Ctrl+C ya window band karein.
node agent.js
pause
