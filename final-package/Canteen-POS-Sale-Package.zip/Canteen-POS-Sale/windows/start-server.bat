@echo off
REM ============================================================
REM  Canteen POS - Server START (staff ke liye, double-click)
REM  Server pehle se chal raha ho to sirf address dikhata hai.
REM  Asal launcher: C:\CanteenPOS\run-server.ps1
REM ============================================================
setlocal
set PORT=3100
title Canteen POS - Server Start

echo.
echo  Canteen POS server check ho raha hai...

powershell -NoProfile -Command "if (Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }"
if %errorlevel%==0 (
    echo  Server pehle se CHAL raha hai.
    goto :showaddr
)

echo  Server start ho raha hai - nayi window khulegi, use BAND na karein...
start "Canteen POS Server - is window ko band na karein" powershell -NoProfile -ExecutionPolicy Bypass -File "C:\CanteenPOS\run-server.ps1"

echo  Server ke tayyar hone ka intezar...
set /a tries=0
:waitloop
set /a tries+=1
timeout /t 2 /nobreak >nul
powershell -NoProfile -Command "if (Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }"
if %errorlevel%==0 goto :ready
if %tries% lss 45 goto :waitloop
echo.
echo  Server 90 second mein start nahi hua.
echo  Log dekhein: C:\CanteenPOS\Logs\server.log
goto :end

:ready
echo  Server TAYYAR hai.

:showaddr
echo.
echo  ============================================================
echo   Is PC par:        http://localhost:%PORT%
echo   Counter / Kitchen ki devices par ye address kholain:
powershell -NoProfile -Command "Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | ForEach-Object { '    http://' + $_.IPAddress + ':%PORT%' }"
echo  ============================================================
echo.
start "" "http://localhost:%PORT%"

:end
echo.
pause
endlocal
